import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA, ErrorHandler } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { APP_ROUTES } from './app.routes';
import { OnlyLoggedInUserGuard } from '@core/guards/loggedin-user.guard';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { GlobalErrorHandler } from '@core/services/global-error-handler';
import { LoginModule } from '@appRoot/login';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { AppService } from '@appRoot/app.service';
import { AppIdleService } from '@appRoot/app-idle.service';
import { NgIdleModule } from '@ng-idle/core';
import { DatePipe } from '@angular/common';
import { UnifiedloginComponent } from '@appRoot/unified-login/unified-login.component';

@NgModule({
  declarations: [AppComponent, UnifiedloginComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgxSpinnerModule,
    NgIdleModule.forRoot(),
    BaseControlModule.forRoot(),
    NgbModule,
    LoginModule.forRoot(),

    RouterModule.forRoot(APP_ROUTES, {
      useHash: true
    })
  ],
  providers: [
    OnlyLoggedInUserGuard,
    AppService,
    AppIdleService,
    DatePipe,
    { provide: ErrorHandler, useClass: GlobalErrorHandler }
  ],
  entryComponents: [],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule {}
