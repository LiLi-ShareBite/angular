export type IHomeApp = {
  id: string;
  description: string | null;
  iconAsBase64: string | null;
  url: string;
};

export class CurrentUserAppsModel {
  constructor(public apps: IHomeApp[]) {}
}
