export interface IUnifiedloginProps {
  menuOptions?: IUnifiedLoginComponentOptionProp[];
}

export interface IUnifiedLoginComponentOptionProp {
  menuName: string;
  menuIcon: string;
  menuURL: string;
}
