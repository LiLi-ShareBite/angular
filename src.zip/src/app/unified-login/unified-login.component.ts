import * as React from 'react';
import * as ReactDOM from 'react-dom';
import * as uuid from 'uuid';

import {
  Component,
  Input,
  OnInit,
  OnDestroy,
  OnChanges,
  AfterViewInit
} from '@angular/core';
import Unifiedlogin from 'db-unified-login';
import {
  IUnifiedloginProps,
  IUnifiedLoginComponentOptionProp
} from './unified-login.model';

@Component({
  selector: 'dbcp-unified-login',
  template: `
    <span [id]="rootDomID"></span>
  `
})
export class UnifiedloginComponent
  implements OnInit, OnDestroy, OnChanges, AfterViewInit {
  @Input() public menuOptions?: IUnifiedLoginComponentOptionProp[];

  public rootDomID: string;

  public ngOnInit() {
    this.rootDomID = uuid.v1();
  }

  public ngOnChanges() {
    this.render();
  }

  public ngAfterViewInit() {
    this.render();
  }

  public ngOnDestroy() {
    // Uncomment if Angular 4 issue that ngOnDestroy is called AFTER DOM node removal is resolved
    ReactDOM.unmountComponentAtNode(this.getRootDomNode());
  }

  protected getRootDomNode() {
    const node = document.getElementById(this.rootDomID);
    return node;
  }

  protected getProps(): IUnifiedloginProps {
    const { menuOptions } = this;
    return { menuOptions };
  }

  protected render() {
    if (this.isMounted()) {
      ReactDOM.render(
        React.createElement(Unifiedlogin, this.getProps()),
        this.getRootDomNode()
      );
    }
  }

  private isMounted(): boolean {
    return !!this.rootDomID;
  }
}
