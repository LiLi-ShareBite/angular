import { Component, OnInit, ElementRef } from '@angular/core';
import { LoginService } from '@appRoot/login/login.service';
import { Router, NavigationStart } from '@angular/router';

import {
  UserAppModel,
  USER_ROLE
} from '@appRoot/features/user-management/user.model';
import { AppService } from '@appRoot/app.service';
import { LOGIN_RESULT } from '@appRoot/login/login.model';
import { environment } from 'environments/environment';
import { IHomeApp, CurrentUserAppsModel } from './app.model';
import { IUnifiedLoginComponentOptionProp } from './unified-login/unified-login.model';

@Component({
  selector: 'dbcp-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public currentUser: UserAppModel = null;
  public isUserSessionStatus;
  public USER_ROLE: typeof USER_ROLE = USER_ROLE;
  public unifiedLoginmenuOptions: IUnifiedLoginComponentOptionProp[] = [];
  private returnUrl: string;
  private ssoAppUrl: string = '';

  constructor(
    private loginService: LoginService,
    private element: ElementRef,
    private appService: AppService,
    private router: Router
  ) {}

  public async ngOnInit() {
    this.appService.spinner.show();
    this.appService.getAppVersion();
    this.returnUrl = this.loginService.getReturnUrl();
    this.isUserSessionStatus = null;

    this.appService.currentUserSubject.subscribe(
      (user: UserAppModel) => {
        this.appService.spinner.show();

        this.setCurrentUser(user);
        this.appService.spinner.hide();
      },
      () => {
        this.setCurrentUser(null);
        this.appService.spinner.hide();
      }
    );

    const ssoApp: IHomeApp = await this.appService.getHomeApp();
    this.ssoAppUrl = `https://${ssoApp.url}/#/`;

    this.isUserSessionStatus = sessionStorage.getItem('isUserSessionStatus');
    try {
      const userSessionStatus: boolean = await this.appService.getUserSessionStatus();
      if (userSessionStatus) {
        const currentUser: UserAppModel = await this.appService.getCurrentUser();

        try {
          await this.appService.checkIfUserHasPermission();
        } catch (err) {
          this.onUserSettings();
        }

        this.loginService.userLoginStatusSubject.next(LOGIN_RESULT.SUCCEEDED);
        localStorage.setItem(
          'dbcpUserLoginStatus',
          LOGIN_RESULT.SUCCEEDED.toString()
        );

        this.setCurrentUser(currentUser);
        this.appService.spinner.hide();
        this.loginService.redirectLoggedInUserByRole(
          currentUser,
          this.returnUrl
        );
        this.getCurrentUserApps();
      }
    } catch (e) {
      this.setCurrentUser(null);
      this.isUserSessionStatus = 'failure';
      this.appService.spinner.hide();
    }

    this.router.events.subscribe((navigationStart: NavigationStart) => {
      if (navigationStart instanceof NavigationStart) {
        this.hideSideBar();
      }
    });
  }

  public logout() {
    this.appService.spinner.show();
    this.loginService.logout();
  }

  public onUserSettings() {
    window.location.href = `${this.ssoAppUrl}settings`;
  }

  public toggleSideBar() {
    const sideBarElem = this.element.nativeElement.querySelector(
      '#layout-sidebar'
    );
    if (sideBarElem) {
      sideBarElem.classList.toggle('show-sidebar');
    }
  }

  public hideSideBar() {
    const sideBarElem = this.element.nativeElement.querySelector(
      '#layout-sidebar'
    );
    if (sideBarElem) {
      sideBarElem.classList.remove('show-sidebar');
    }
  }

  public getUserSessionStatus() {
    this.appService.getUserSessionStatus().then(
      (value: any) => {
        this.isUserSessionStatus = sessionStorage.getItem(
          'isUserSessionStatus'
        );
      },
      () => {
        this.isUserSessionStatus = 'failure';
      }
    );
  }

  public getCurrentUserApps() {
    this.appService
      .getCurrentUserApps()
      .then((response: CurrentUserAppsModel) => {
        response.apps.forEach((app: IHomeApp) => {
          const option: IUnifiedLoginComponentOptionProp = {
            menuName: app.description,
            menuIcon: 'data:image/png;base64, ' + app.iconAsBase64,
            menuURL: 'https://' + app.url
          };

          this.unifiedLoginmenuOptions.push(option);
        });
      });
  }

  private setCurrentUser(user) {
    setTimeout(() => {
      this.currentUser = user;
    }, 0);
  }
}
