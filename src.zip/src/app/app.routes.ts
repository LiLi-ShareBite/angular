import { Routes } from '@angular/router';
import { OnlyLoggedInUserGuard } from '@core/guards/loggedin-user.guard';

export const APP_ROUTES: Routes = [
  {
    path: 'login',
    loadChildren: () => import('./login').then((m) => m.LoginModule),
    pathMatch: 'full',
    canActivate: [OnlyLoggedInUserGuard]
  },
  {
    path: '',
    loadChildren: () => import('./features/').then((m) => m.MainModule),
    canActivate: [OnlyLoggedInUserGuard]
  },
  { path: '**', redirectTo: '' }
];
