import {
  CompanyModel,
  LocationModel
} from '@core/components/main-filters/main-filters.model';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { IDbcpAlert } from '@core/components/alert/alert.model';

export enum RESOLVED_OUTCOME {
  SUCCESS,
  FAILED,
  NA,
  IN_PROGRESS,
  CLOSED
}

export class ResolvedResultModel {
  constructor(
    public outcome: RESOLVED_OUTCOME,
    public exceptionId?: string,
    public alert?: IDbcpAlert
  ) {}
}

export enum USER_ROLE {
  SYSTEM_ADMIN,
  ADMIN,
  MANAGER,
  USER,
  KNOWLEDGE_WORKER,
  OPERATIONS_ADMIN,
  KNOWLEDGE_WORKER_ADMIN
}

export class UserAppModel {
  public static parseObjArrToModel(objArr: UserAppModel[]) {
    return objArr.map(
      (obj) =>
        new UserAppModel(
          obj.userId,
          obj.firstName,
          obj.lastName,
          obj.emailAddress,
          obj.phoneNumber,
          obj.detail
        )
    );
  }

  public static parseObjToModel(obj: IPaginatedResponseModel) {
    return {
      totalUserCount: obj.totalUserCount,
      users: obj.users.map((user) => {
        const model = new UserAppModel(
          user.userId,
          user.firstName,
          user.lastName,
          user.emailAddress,
          user.phoneNumber,
          user.detail
        );
        return model;
      })
    };
  }

  public get company() {
    if (!this.detail.company) {
      return null;
    }
    return this.detail.company.name;
  }

  public get location() {
    return this.detail.sites ? this.detail.sites[0].name : '';
  }

  public get role() {
    return LocalizePipe.Instance.transform(USER_ROLE[this.detail.role]);
  }

  constructor(
    public userId: number,
    public firstName: string,
    public lastName: string,
    public emailAddress: string,
    public phoneNumber: string,
    public detail: UserDetailAppModel,
    public password: string = null
  ) {}
}

export interface IPaginatedResponseModel {
  totalUserCount: number;
  users: UserAppModel[];
}

export class UserDetailAppModel {
  constructor(
    public role: USER_ROLE,
    public company: CompanyModel,
    public sites: LocationModel[]
  ) {}
}

export class UserRoleModel {
  constructor(public role: number, public name: string) {}
}

export interface IUsersListRequestModel {
  companyId: number;
  siteIds: number[];
  offset: number;
  pageSize: number;
  searchString: string;
  sortColumns: SortColumnInstructions[];
}

export class TableSortColumns {
  constructor(
    public field: string,
    public header: string,
    public columnID: USER_SORT_COLUMN_CATEGORY
  ) {}
}

export class SortColumnInstructions {
  constructor(public userSortColumn: number, public isAscending: boolean) {}
}

export enum USER_SORT_COLUMN_CATEGORY {
  FIRSTNAME = 0,
  LASTNAME = 1,
  EMAILADDRESS = 2,
  PHONE = 3
}

export enum USER_WARNING_MSG {
  USER_ERR_MSG_OPERATION_NOT_COMPLETE = 635,
  USER_ERR_MSG_EMAIL_EXISTS = 637,
  USER_ERR_MSG_COMPANY_ID_NOT_MATCH = 638,
  USER_ERR_MSG_SITES_NOT_CORRECT = 639,
  USER_ERR_MSG_EMAIL_INVALID = 640,
  USER_ERR_MSG_FIRST_NAME_MISSING = 641,
  USER_ERR_MSG_LAST_NAME_MISSING = 642,
  USER_ERR_MSG_ID_NOT_EXIST = 644,
  USER_ERR_MSG_ACCOUNT_NOT_EDITED = 645,
  USER_ERR_MSG_NAME_WITH_INVALID_CHAR = 657,
  USER_ERR_MSG_NAME_WITH_INVALID_LEADING_CHAR = 658,
  USER_ERR_MSG_NAME_WITH_INVALID_TRAILING_CHAR = 659
}
