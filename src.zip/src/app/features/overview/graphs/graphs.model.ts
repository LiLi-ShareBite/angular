export interface IBacthExceptionReportRequestModel {
  companyId: number;
  siteIds: number[];
  dateCreatedFilter: {
    utcStartDate: Date;
    utcEndDate: Date;
  };
  timeAggregationType: number;
}

export class UploadedBatchesReportModel {
  public static parseObjArrToModel(objArr: UploadedBatchesReportModel[]) {
    return objArr.map((obj) => {
      const model = new UploadedBatchesReportModel(
        obj.dateCreated,
        obj.locationId,
        obj.location,
        obj.count
      );
      return model;
    });
  }
  constructor(
    public dateCreated: Date,
    public locationId: number,
    public location: string,
    public count: number
  ) {}
}

export class UploadedExceptionsReportModel {
  public static parseObjArrToModel(objArr: UploadedExceptionsReportModel[]) {
    return objArr.map((obj) => {
      const model = new UploadedExceptionsReportModel(
        obj.dateCreated,
        obj.locationId,
        obj.location,
        obj.totalCount,
        obj.unresolvedCount,
        obj.resolvedCount,
        obj.duplicateBatchCount,
        obj.wrongInformationCount,
        obj.missingInformationCount,
        obj.poorImageQuality,
        obj.otherExceptionTypeCount
      );
      return model;
    });
  }
  constructor(
    public dateCreated: Date,
    public locationId: number,
    public location: string,
    public totalCount: number,
    public unresolvedCount: number,
    public resolvedCount: number,
    public duplicateBatchCount: number,
    public wrongInformationCount: number,
    public missingInformationCount: number,
    public poorImageQuality: number,
    public otherExceptionTypeCount: number
  ) {}
}

export interface IExceptTypeBgColor {
  type: string;
  color: string;
}
export const exceptTypeBgColor: IExceptTypeBgColor[] = [
  { type: 'wrongInformationCount', color: '#FDB81E' },
  { type: 'missingInformationCount', color: '#205493' },
  { type: 'poorImageQuality', color: '#E31C3D' },
  { type: 'duplicateBatchCount', color: '#6332D0' }
];
