import { ApiService } from '@apiService';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import {
  IBacthExceptionReportRequestModel,
  UploadedBatchesReportModel,
  UploadedExceptionsReportModel
} from './graphs.model';

const POST_OVERVIEW_UPLOADED_BATCHES_REPORT_API =
  '/api/dbcp/report/batches-uploaded';
const POST_OVERVIEW_REPORT_UPLOADED_EXCEPTIONS_REPORT_API =
  'api/dbcp/report/exceptions-uploaded';

@Injectable()
export class GraphsService extends ApiService {
  public getUploadedBatchesReport(data: IBacthExceptionReportRequestModel) {
    return new Promise((resolve, reject) => {
      this.post(POST_OVERVIEW_UPLOADED_BATCHES_REPORT_API, data)
        .pipe(
          map((response: UploadedBatchesReportModel[]) =>
            UploadedBatchesReportModel.parseObjArrToModel(response)
          )
        )
        .subscribe(
          (batchReportArrObj: UploadedBatchesReportModel[]) => {
            resolve(batchReportArrObj);
          },
          () => {
            reject();
          },
          () => {}
        );
    });
  }

  public getUploadedExceptionsReport(data: IBacthExceptionReportRequestModel) {
    return new Promise((resolve, reject) => {
      this.post(POST_OVERVIEW_REPORT_UPLOADED_EXCEPTIONS_REPORT_API, data)
        .pipe(
          map((response: UploadedExceptionsReportModel[]) =>
            UploadedExceptionsReportModel.parseObjArrToModel(response)
          )
        )
        .subscribe(
          (exceptionReportArrObj: UploadedExceptionsReportModel[]) => {
            resolve(exceptionReportArrObj);
          },
          () => {
            reject();
          },
          () => {}
        );
    });
  }
}
