import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { GraphsComponent } from './graphs.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxSpinnerService } from 'ngx-spinner';
import { RouterTestingModule } from '@angular/router/testing';
import { GraphsService } from '@appRoot/features/overview/graphs/graphs.service';
import { DatePipe } from '@angular/common';

describe('Component: GraphsComponent', () => {
  let component: GraphsComponent;
  let fixture: ComponentFixture<GraphsComponent>;
  let dElem: DebugElement;
  let elem: HTMLElement;
  let datePipe: DatePipe;
  let testBedGraphsService: GraphsService;

  datePipe = new DatePipe('en-US');

  beforeEach(() => {
    datePipe = new DatePipe('en-US');
  });

  it('Convert UTC time as expected.', () => {
    expect(datePipe.transform('2020-2-2 12:00:00', 'MM/dd/yyyy')).toBe(
      '02/02/2020'
    );
  });

  beforeEach(async(() => {
    class GraphsServiceStub {
      public getUploadedBatchesReport() {}
      public getUploadedExceptionsReport() {}
    }

    TestBed.configureTestingModule({
      declarations: [GraphsComponent, LocalizePipe],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [
        AppService,
        MainService,
        { provide: GraphsService, useClass: GraphsServiceStub },
        NgxSpinnerService,
        DatePipe
      ],
      schemas: [NO_ERRORS_SCHEMA]
    });
    fixture = TestBed.createComponent(GraphsComponent);
    component = fixture.componentInstance;

    testBedGraphsService = TestBed.get(GraphsService);

    dElem = fixture.debugElement;
    elem = dElem.nativeElement;
  }));

  it('Graphs component should create', () => {
    expect(component).toBeTruthy();
  });

  it('Graphs service should be created', () => {
    expect(testBedGraphsService).toBeTruthy();
  });
});
