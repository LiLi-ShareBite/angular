import { Component, OnInit, Input, OnChanges } from '@angular/core';
import {
  IBacthExceptionReportRequestModel,
  UploadedBatchesReportModel,
  UploadedExceptionsReportModel,
  IExceptTypeBgColor,
  exceptTypeBgColor
} from '@appRoot/features/overview/graphs/graphs.model';
import { IMainFiltersModel } from '@core/components/main-filters/main-filters.model';
import { AppService } from '@appRoot/app.service';
import { GraphsService } from '@appRoot/features/overview/graphs/graphs.service';
import { DatePipe } from '@angular/common';
import { LocalizePipe } from '@core/pipes/localize.pipe';

@Component({
  selector: 'dbcp-graphs',
  templateUrl: './graphs.component.html',
  styleUrls: ['./graphs.component.scss']
})
export class GraphsComponent implements OnInit, OnChanges {
  public bacthExceptionReportRequest: IBacthExceptionReportRequestModel;
  public uploadedBatchesReport: UploadedBatchesReportModel[];
  public uploadedExceptionsReport: UploadedExceptionsReportModel[];

  public lineData: any;
  public lineOptions: any;
  public arrLineLocations: string[];
  public arrColorTbl: string[];
  public arrLineDateCreated: Date[];

  public barData: any;
  public barOptions: any;
  public arrBarLocations: string[];
  public exceptTypeBgColor: IExceptTypeBgColor[] = exceptTypeBgColor;
  public arrBarDateCreated: Date[];

  @Input()
  public mainFilters: IMainFiltersModel[];

  private batchExceptionFilter: IBacthExceptionReportRequestModel = {
    companyId: null,
    siteIds: [],
    dateCreatedFilter: null,
    timeAggregationType: null
  };

  private toggleMissingInfo: boolean = false;
  private toggleWrongInfo: boolean = false;
  private togglePoorImageQuality: boolean = false;
  private toggleDuplicateBatch: boolean = false;

  constructor(
    private appService: AppService,
    private graphsService: GraphsService,
    public datepipe: DatePipe
  ) {}

  public ngOnInit() {
    this.lineOptions = {
      scales: {
        yAxes: [
          {
            ticks: {
              beginAtZero: true
            },
            gridLines: {
              borderDash: [8, 4]
            }
          }
        ]
      }
    };
    // Initial stacked bar
    this.barData = {
      labels: '',
      datasets: [
        {
          label: '',
          data: [],
          backgroundColor: '#FFFFFF',
          borderColor: '#FFFFFF'
        }
      ]
    };
    this.barOptions = {
      scales: {
        yAxes: [
          {
            stacked: true,
            ticks: {
              beginAtZero: true
            },
            gridLines: {
              borderDash: [8, 4]
            }
          }
        ],
        xAxes: [
          {
            stacked: true,
            ticks: {
              beginAtZero: true
            }
          }
        ]
      },
      legend: {
        display: false
      },
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 0
      },
      hover: {
        animationDuration: 0
      },
      responsiveAnimationDuration: 0
    };
  }

  public ngOnChanges() {
    this.lineData = [];
    this.getUploadedBatchesReport(this.mainFilters);
    this.barData = [];
    this.toggleMissingInfo = false;
    this.toggleWrongInfo = false;
    this.togglePoorImageQuality = false;
    this.toggleDuplicateBatch = false;
    this.getUploadedExceptionsReport(this.mainFilters);
  }

  public getUploadedBatchesReport(filters) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      if (filters) {
        this.getBatchExceptionFilter(filters);
        this.graphsService
          .getUploadedBatchesReport(this.batchExceptionFilter)
          .then(
            (response: UploadedBatchesReportModel[]) => {
              this.uploadedBatchesReport = response;
              this.arrLineLocations = [
                ...new Set(
                  this.uploadedBatchesReport.map(
                    (item: UploadedBatchesReportModel) => item.location
                  )
                )
              ];
              if (this.arrLineLocations.length > 0) {
                // Initial lineData
                this.lineData = {
                  labels: '',
                  datasets: [
                    {
                      label: '',
                      data: [],
                      fill: false,
                      borderColor: '#FFFFFF'
                    }
                  ]
                };
                // total dateCreated
                this.arrLineDateCreated = [
                  ...new Set(
                    this.uploadedBatchesReport.map(
                      (item: UploadedBatchesReportModel) => item.dateCreated
                    )
                  )
                ];
                // format date
                this.lineData.labels = [
                  ...new Set(
                    this.uploadedBatchesReport.map(
                      (item: UploadedBatchesReportModel) =>
                        this.datepipe.transform(item.dateCreated, 'yyyy-MM-dd')
                    )
                  )
                ];
                // Handle single/multiple location(s) API JSON
                if (this.arrLineLocations.length === 1) {
                  this.setOneLocationLineChart(this.uploadedBatchesReport);
                } else {
                  this.arrLineLocations.forEach((value, index) => {
                    this.setMultiLocationsLineChart(
                      this.uploadedBatchesReport,
                      index
                    );
                  });
                }
              }
              this.appService.spinner.hide();
              resolve();
            },
            (error) => {
              reject();
            }
          );
      }
    });
  }

  public getUploadedExceptionsReport(filters) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      if (filters) {
        this.getBatchExceptionFilter(filters);
        this.graphsService
          .getUploadedExceptionsReport(this.batchExceptionFilter)
          .then(
            (response: UploadedExceptionsReportModel[]) => {
              this.uploadedExceptionsReport = response;
              // total locations
              this.arrBarLocations = [
                ...new Set(
                  this.uploadedExceptionsReport.map(
                    (item: UploadedExceptionsReportModel) => item.location
                  )
                )
              ];
              // total dateCreated
              this.arrBarDateCreated = [
                ...new Set(
                  this.uploadedExceptionsReport.map(
                    (item: UploadedExceptionsReportModel) => item.dateCreated
                  )
                )
              ];
              // format display date
              this.barData.labels = [
                ...new Set(
                  this.uploadedExceptionsReport.map((item) =>
                    this.datepipe.transform(item.dateCreated, 'yyyy-MM-dd')
                  )
                )
              ];
              if (this.arrBarLocations.length > 0) {
                this.arrBarLocations.forEach((value, index) => {
                  // initial data value with '0'; avoid barData schema error
                  const missingInfoCount = new Array(
                    this.arrBarDateCreated.length
                  );
                  missingInfoCount.fill(0);
                  const wrongInfoCount = new Array(
                    this.arrBarDateCreated.length
                  );
                  wrongInfoCount.fill(0);
                  const poorImageQualityCount = new Array(
                    this.arrBarDateCreated.length
                  );
                  poorImageQualityCount.fill(0);
                  const duplicateBatchCount = new Array(
                    this.arrBarDateCreated.length
                  );
                  duplicateBatchCount.fill(0);
                  // generate bar chart per location, dateCreated and exception type
                  this.setBarChart(
                    this.uploadedExceptionsReport.filter(
                      (item) => item.location === this.arrBarLocations[index]
                    ),
                    index,
                    this.toggleMissingInfo,
                    missingInfoCount,
                    this.toggleWrongInfo,
                    wrongInfoCount,
                    this.togglePoorImageQuality,
                    poorImageQualityCount,
                    this.toggleDuplicateBatch,
                    duplicateBatchCount
                  );
                });
              }
              this.appService.spinner.hide();
              resolve();
            },
            (error) => {
              reject();
            }
          );
      }
    });
  }

  public hideStackedData() {
    // show or hide selected exception type
    this.arrBarLocations.forEach((value, index) => {
      // initial data value with '0'; avoid barData schema error
      const missingInfoCount = new Array(this.arrBarDateCreated.length);
      missingInfoCount.fill(0);
      const wrongInfoCount = new Array(this.arrBarDateCreated.length);
      wrongInfoCount.fill(0);
      const poorImageQualityCount = new Array(this.arrBarDateCreated.length);
      poorImageQualityCount.fill(0);
      const duplicateBatchCount = new Array(this.arrBarDateCreated.length);
      duplicateBatchCount.fill(0);

      // generate bar chart per location, dateCreated and exception type
      this.setBarChart(
        this.uploadedExceptionsReport.filter(
          (item) => item.location === this.arrBarLocations[index]
        ),
        index,
        this.toggleMissingInfo,
        missingInfoCount,
        this.toggleWrongInfo,
        wrongInfoCount,
        this.togglePoorImageQuality,
        poorImageQualityCount,
        this.toggleDuplicateBatch,
        duplicateBatchCount
      );
    });
  }

  private getBatchExceptionFilter(filters?: IMainFiltersModel) {
    if (filters) {
      this.batchExceptionFilter.companyId = filters.company
        ? filters.company.id
        : null;
      this.batchExceptionFilter.siteIds = filters.locations.length
        ? filters.locations.map((item) => item.id)
        : [];

      if (filters.timeFrame) {
        this.batchExceptionFilter.dateCreatedFilter = {
          utcStartDate: filters.timeFrame.startDt,
          utcEndDate: filters.timeFrame.endDt
        };
      } else {
        this.batchExceptionFilter.dateCreatedFilter = null;
      }
    }
    this.batchExceptionFilter.timeAggregationType = 0; // X-axis displays data points by daily
    if (
      this.getDatesDiff(
        this.batchExceptionFilter.dateCreatedFilter.utcStartDate,
        this.batchExceptionFilter.dateCreatedFilter.utcEndDate
      ) >= 32
    ) {
      this.batchExceptionFilter.timeAggregationType = 1; // X-axis displays data points by weekly
    }
    // Generate color table
    this.getRandomColor(filters.locations.length);
  }

  private getDatesDiff(utcStartDate, utcEndDate) {
    const daysDiff =
      (utcEndDate.getTime() - utcStartDate.getTime()) / (1000 * 3600 * 24);
    return daysDiff;
  }

  private setOneLocationLineChart(uploadedBatchesReport) {
    const arryCount = uploadedBatchesReport.map((item) => item.count);
    const newDataset = {
      label: this.arrLineLocations, // one location
      data: arryCount,
      fill: false,
      borderColor: this.arrColorTbl[0]
    };
    this.lineData.datasets.push(newDataset);
  }

  private setMultiLocationsLineChart(uploadedBatchesReport, index) {
    // Initial with 0 in dataset
    const arrCount = new Array(this.lineData.labels.length);
    arrCount.fill(0);
    // get uploaded batches report per each location
    const uploadedBatchesReportPerLocation = uploadedBatchesReport.filter(
      (item: UploadedBatchesReportModel) =>
        item.location === this.arrLineLocations[index]
    );
    // get DateCreated per each location
    const arrDateCreatedPerLocation = [
      ...new Set(
        uploadedBatchesReport
          .filter(
            (item: UploadedBatchesReportModel) =>
              item.location === this.arrLineLocations[index]
          )
          .map((item: UploadedBatchesReportModel) => item.dateCreated)
      )
    ];
    // create real dataset values per location (some location could have same or less total dateCreated)
    let dateCreatedIndex = 0;
    this.arrLineDateCreated.forEach((value, i) => {
      if (
        this.arrLineDateCreated[i] ===
        arrDateCreatedPerLocation[dateCreatedIndex]
      ) {
        arrCount[i] = uploadedBatchesReportPerLocation[dateCreatedIndex].count;
        dateCreatedIndex++;
      }
    });
    const newDataset = {
      label: uploadedBatchesReport[index].location,
      data: arrCount,
      fill: false,
      borderColor: this.arrColorTbl[index]
    };
    this.lineData.datasets.push(newDataset);
  }

  private setBarChart(
    uploadedExceptionsReport,
    index,
    toggleMissingInfo,
    missingInfoCount,
    toggleWrongInfo,
    wrongInfoCount,
    togglePoorImageQuality,
    poorImageQualityCount,
    toggleDuplicateBatch,
    duplicateBatchCount
  ) {
    // get DateCreated per each location
    const arrDateCreatedPerLocation = [
      ...new Set(
        this.uploadedExceptionsReport
          .filter(
            (item: UploadedExceptionsReportModel) =>
              item.location === this.arrBarLocations[index]
          )
          .map((item: UploadedExceptionsReportModel) => item.dateCreated)
      )
    ];
    // create real dataset values of 4 exception type per location (some location could have same or less total dateCreated)
    let misInfoIndex = 0;
    let wrgInfoIndex = 0;
    let prImgIndex = 0;
    let dpBthIndex = 0;

    this.arrBarDateCreated.forEach((value, i) => {
      if (!toggleMissingInfo) {
        if (
          this.arrBarDateCreated[i] === arrDateCreatedPerLocation[misInfoIndex]
        ) {
          missingInfoCount[i] =
            uploadedExceptionsReport[misInfoIndex].missingInformationCount;
          misInfoIndex++;
        }
      }
      if (!toggleWrongInfo) {
        if (
          this.arrBarDateCreated[i] === arrDateCreatedPerLocation[wrgInfoIndex]
        ) {
          wrongInfoCount[i] =
            uploadedExceptionsReport[wrgInfoIndex].wrongInformationCount;
          wrgInfoIndex++;
        }
      }
      if (!togglePoorImageQuality) {
        if (
          this.arrBarDateCreated[i] === arrDateCreatedPerLocation[prImgIndex]
        ) {
          poorImageQualityCount[i] =
            uploadedExceptionsReport[prImgIndex].poorImageQuality;
          prImgIndex++;
        }
      }
      if (!toggleDuplicateBatch) {
        if (
          this.arrBarDateCreated[i] === arrDateCreatedPerLocation[dpBthIndex]
        ) {
          duplicateBatchCount[i] =
            uploadedExceptionsReport[dpBthIndex].duplicateBatchCount;
          dpBthIndex++;
        }
      }
    });

    if (index === 0) {
      // Initial first location stack bar with qualified data format
      this.setOneLocationBarChart(
        uploadedExceptionsReport,
        missingInfoCount,
        wrongInfoCount,
        poorImageQualityCount,
        duplicateBatchCount
      );
    } else {
      // Add remain location stack bar
      this.setMultiLocationsBarChart(
        uploadedExceptionsReport,
        missingInfoCount,
        wrongInfoCount,
        poorImageQualityCount,
        duplicateBatchCount
      );
    }
  }

  private setOneLocationBarChart(
    uploadedExceptionsReport,
    missingInfoCount,
    wrongInfoCount,
    poorImageQualityCount,
    duplicateBatchCount
  ) {
    this.barData = {
      labels: '',
      datasets: [
        {
          label:
            uploadedExceptionsReport[0].location +
            ': ' +
            LocalizePipe.Instance.transform(
              'GRAPH_EXCEPTION_MISSING_INFORMATION_COUNT'
            ),
          data: missingInfoCount,
          fill: false,
          backgroundColor: this.exceptTypeBgColor[1].color,
          stack: uploadedExceptionsReport[0].location
        },
        {
          label:
            uploadedExceptionsReport[0].location +
            ': ' +
            LocalizePipe.Instance.transform(
              'GRAPH_EXCEPTION_WRONG_INFORMATION_COUNT'
            ),
          data: wrongInfoCount,
          fill: false,
          backgroundColor: this.exceptTypeBgColor[0].color,
          stack: uploadedExceptionsReport[0].location
        },
        {
          label:
            uploadedExceptionsReport[0].location +
            ': ' +
            LocalizePipe.Instance.transform(
              'GRAPH_EXCEPTION_POOR_IMAGE_QUALITY'
            ),
          data: poorImageQualityCount,
          fill: false,
          backgroundColor: this.exceptTypeBgColor[2].color,
          stack: uploadedExceptionsReport[0].location
        },
        {
          label:
            uploadedExceptionsReport[0].location +
            ': ' +
            LocalizePipe.Instance.transform(
              'GRAPH_EXCEPTION_DUPLICATE_BATCH_COUNT'
            ),
          data: duplicateBatchCount,
          fill: false,
          backgroundColor: this.exceptTypeBgColor[3].color,
          stack: uploadedExceptionsReport[0].location
        }
      ]
    };
    this.barData.labels = [
      ...new Set(
        this.uploadedExceptionsReport.map((item) =>
          this.datepipe.transform(item.dateCreated, 'yyyy-MM-dd')
        )
      )
    ];
  }

  private setMultiLocationsBarChart(
    uploadedExceptionsReport,
    missingInfoCount,
    wrongInfoCount,
    poorImageQualityCount,
    duplicateBatchCount
  ) {
    const missingInfoCountDataset = {
      label:
        uploadedExceptionsReport[0].location +
        ': ' +
        LocalizePipe.Instance.transform(
          'GRAPH_EXCEPTION_MISSING_INFORMATION_COUNT'
        ),
      data: missingInfoCount,
      fill: false,
      backgroundColor: this.exceptTypeBgColor[1].color,
      stack: uploadedExceptionsReport[0].location
    };
    this.barData.datasets.push(missingInfoCountDataset);
    const wrongInfoCountDataset = {
      label:
        uploadedExceptionsReport[0].location +
        ': ' +
        LocalizePipe.Instance.transform(
          'GRAPH_EXCEPTION_WRONG_INFORMATION_COUNT'
        ),
      data: wrongInfoCount,
      fill: false,
      backgroundColor: this.exceptTypeBgColor[0].color,
      stack: uploadedExceptionsReport[0].location
    };
    this.barData.datasets.push(wrongInfoCountDataset);
    const poorImageQualityCountDataset = {
      label:
        uploadedExceptionsReport[0].location +
        ': ' +
        LocalizePipe.Instance.transform('GRAPH_EXCEPTION_POOR_IMAGE_QUALITY'),
      data: poorImageQualityCount,
      fill: false,
      backgroundColor: this.exceptTypeBgColor[2].color,
      stack: uploadedExceptionsReport[0].location
    };
    this.barData.datasets.push(poorImageQualityCountDataset);
    const duplicateBatchCountDataset = {
      label:
        uploadedExceptionsReport[0].location +
        ': ' +
        LocalizePipe.Instance.transform(
          'GRAPH_EXCEPTION_DUPLICATE_BATCH_COUNT'
        ),
      data: duplicateBatchCount,
      fill: false,
      backgroundColor: this.exceptTypeBgColor[3].color,
      stack: uploadedExceptionsReport[0].location
    };
    this.barData.datasets.push(duplicateBatchCountDataset);
  }

  private getRandomColor(locations) {
    let i = 0;
    let color = '#';
    const colorTbl = [];
    do {
      color = '#' + Math.floor(Math.random() * 16777215).toString(16);
      if (i === locations) {
        break;
      } else {
        colorTbl.push(color);
      }
      i++;
    } while (color !== '#FFFFFF');

    this.arrColorTbl = colorTbl;
  }
}
