import { ApiService } from '@apiService';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import {
  OverviewSummaryModel,
  IOverviewSummaryRequestModel,
  OverviewSettingsModel
} from './overview.model';

const POST_OVERVIEW_SUMMARY_API = 'api/dbcp/batch-count-overview';
const POST_OVERVIEW_SETTINGS_API = 'api/dbcp/batch-count-overview-settings';

@Injectable()
export class OverviewService extends ApiService {
  public getOverviewSummary(data: IOverviewSummaryRequestModel) {
    return this.post(POST_OVERVIEW_SUMMARY_API, data).pipe(
      map((response: OverviewSummaryModel) =>
        OverviewSummaryModel.parseResponseToModel(response)
      )
    );
  }

  public getOverviewSettings(data: IOverviewSummaryRequestModel) {
    return this.post(POST_OVERVIEW_SETTINGS_API, data).pipe(
      map((response: OverviewSettingsModel) =>
        OverviewSettingsModel.parseResponseToModel(response)
      )
    );
  }
}
