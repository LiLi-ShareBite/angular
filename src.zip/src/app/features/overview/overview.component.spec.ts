import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { OverviewComponent } from './overview.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxSpinnerService } from 'ngx-spinner';
import { RouterTestingModule } from '@angular/router/testing';
import { OverviewService } from '@appRoot/features/overview/overview.service';

export class CompanyModel {
  constructor(
    public id: number,
    public name: string,
    public description: string
  ) {}
}

export class LocationModel {
  constructor(
    public id: number,
    public name: string,
    public description: string
  ) {}
}

export interface ITimeFrameOption {
  id: number;
  value: string;
}

describe('Component: OverviewComponent', () => {
  let component: OverviewComponent;
  let fixture: ComponentFixture<OverviewComponent>;
  let dElem: DebugElement;
  let elem: HTMLElement;
  let testBedOverviewService: OverviewService;

  beforeEach(async(() => {
    class OverviewServiceStub {
      public getOverviewSummary() {}
      public getOverviewSettings() {}
    }

    TestBed.configureTestingModule({
      declarations: [OverviewComponent, LocalizePipe],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [
        AppService,
        MainService,
        { provide: OverviewService, useClass: OverviewServiceStub },
        NgxSpinnerService
      ],
      schemas: [NO_ERRORS_SCHEMA]
    });
    fixture = TestBed.createComponent(OverviewComponent);
    component = fixture.componentInstance;

    testBedOverviewService = TestBed.get(OverviewService);

    dElem = fixture.debugElement;
    elem = dElem.nativeElement;
  }));

  it('Overview component should create', () => {
    expect(component).toBeTruthy();
  });

  it('Overview service should be created', () => {
    expect(testBedOverviewService).toBeTruthy();
  });

  it('should adjust icon direction down after click', () => {
    component.displayDownIcon = false;
    component.onCloseClick();
    expect(component.displayDownIcon).toBeTruthy();
  });

  it('should adjust icon direction up after click', () => {
    component.displayDownIcon = true;
    component.upsideDown();
    expect(component.displayDownIcon).toBeFalsy();
  });

  it('should hide mobile batch detail', () => {
    component.displayMode = true;
    component.hideMobileBatchDetail();
    expect(component.displayMode).toBeFalsy();
  });

  it('Overview data should be valid after service call with mock filter values', () => {
    fixture.whenStable().then(() => {
      fixture.detectChanges();
    });
    expect(elem.textContent).toBeDefined(component.getOverviewSummary);
  });
});
