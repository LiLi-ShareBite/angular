export class OverviewSummaryModel {
  public static parseResponseToModel(data: OverviewSummaryModel) {
    return new OverviewSummaryModel(
      data.batchesUploaded,
      data.batchesInProcess,
      data.batchesDelivered,
      data.batchesWithException,
      data.batchesInProcessSubstatus
    );
  }

  constructor(
    public batchesUploaded: number,
    public batchesInProcess: number,
    public batchesDelivered: number,
    public batchesWithException: number,
    public batchesInProcessSubstatus: BatchesInProcessSubstatusAppModel
  ) {}
}

export class BatchesInProcessSubstatusAppModel {
  constructor(
    public inProcessScan: number,
    public inProcessPrep: number,
    public inProcessSection: number,
    public InProcessIndex: number,
    public inProcessQC: number
  ) {}
}

export interface IOverviewSummaryRequestModel {
  companyId: number;
  siteIds: number[];
  dateCreatedFilter: {
    utcStartDate: Date;
    utcEndDate: Date;
  };
}

export class OverviewSettingsModel {
  public static parseResponseToModel(data: OverviewSettingsModel) {
    return new OverviewSettingsModel(data.batchCaptureType);
  }

  constructor(public batchCaptureType: number) {}
}

export interface IBacthExceptionReportRequestModel {
  companyId: number;
  siteIds: number[];
  dateCreatedFilter: {
    utcStartDate: Date;
    utcEndDate: Date;
  };
  timeAggregationType: number;
}

export class UploadedBatchesReportModel {
  public static parseObjArrToModel(objArr: UploadedBatchesReportModel[]) {
    return objArr.map((obj) => {
      const model = new UploadedBatchesReportModel(
        obj.dateCreated,
        obj.locationId,
        obj.location,
        obj.count
      );
      return model;
    });
  }
  constructor(
    public dateCreated: Date,
    public locationId: number,
    public location: string,
    public count: number
  ) {}
}

export class UploadedExceptionsReportModel {
  public static parseObjArrToModel(objArr: UploadedExceptionsReportModel[]) {
    return objArr.map((obj) => {
      const model = new UploadedExceptionsReportModel(
        obj.dateCreated,
        obj.locationId,
        obj.location,
        obj.totalCount,
        obj.unresolvedCount,
        obj.resolvedCount
      );
      return model;
    });
  }
  constructor(
    public dateCreated: Date,
    public locationId: number,
    public location: string,
    public totalCount: number,
    public unresolvedCount: number,
    public resolvedCount: number
  ) {}
}
