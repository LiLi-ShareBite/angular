import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OverviewService } from '@appRoot/features/overview/overview.service';
import {
  OverviewSummaryModel,
  OverviewSettingsModel,
  IOverviewSummaryRequestModel
} from '@appRoot/features/overview/overview.model';
import {
  BATCH_CATEGORY,
  CUSTOMER_CAPTURE_TYPE
} from '@appRoot/features/batch-list/batch.model';
import { IMainFiltersModel } from '@core/components/main-filters/main-filters.model';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
// import { GraphsComponent } from '@appRoot/features/overview/graphs/graphs.component';

@Component({
  selector: '[dbcp-overview]',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss']
})
export class OverviewComponent implements OnInit {
  public overviewSummaryModel: OverviewSummaryModel;
  public overviewSettingsModel: OverviewSettingsModel;

  public BATCH_CATEGORY: typeof BATCH_CATEGORY = BATCH_CATEGORY;
  public CUSTOMER_CAPTURE_TYPE: typeof CUSTOMER_CAPTURE_TYPE = CUSTOMER_CAPTURE_TYPE;

  public displayMode: boolean = false;
  public displayDownIcon: boolean = true;
  public mainFilters: IMainFiltersModel;

  private overviewSummaryFilter: IOverviewSummaryRequestModel = {
    companyId: null,
    siteIds: [],
    dateCreatedFilter: null
  };

  constructor(
    private appService: AppService,
    private mainService: MainService,
    private overviewService: OverviewService,
    private router: Router
  ) {}

  public ngOnInit() {}

  public onSelectBatchType(category: number) {
    this.router.navigate(['/batch-list', category, 0]);
  }

  public onSelectException() {
    this.router.navigate(['/batch-summary']);
  }

  public onMainFiltersValues(filters: IMainFiltersModel) {
    this.getOverviewSettings(filters);
    this.getOverviewSummary(filters);
    this.mainFilters = filters;
  }

  public onMainFiltersError(msg: string) {
    // Display error message.
    this.mainService.errorAlertSubject$.next();
  }

  public getOverviewSummary(filters) {
    this.appService.spinner.show();
    this.getMainFilters(filters);
    this.overviewService
      .getOverviewSummary(this.overviewSummaryFilter)
      .subscribe(
        (summary: OverviewSummaryModel) => {
          this.overviewSummaryModel = summary;
        },
        () => {
          this.mainService.errorAlertSubject$.next();
        },
        () => {
          this.appService.spinner.hide();
        }
      );
  }

  public getOverviewSettings(filters) {
    this.appService.spinner.show();
    this.getMainFilters(filters);
    this.overviewService
      .getOverviewSettings(this.overviewSummaryFilter)
      .subscribe(
        (settings: OverviewSettingsModel) => {
          this.overviewSettingsModel = settings;
        },
        () => {
          this.mainService.errorAlertSubject$.next();
        },
        () => {
          this.appService.spinner.hide();
        }
      );
  }

  public upsideDown() {
    this.displayDownIcon = false;
  }

  public onCloseClick() {
    this.displayDownIcon = true;
  }

  public hideMobileBatchDetail() {
    this.displayMode = false;
  }

  public displayMobileBatchDetail($event) {
    this.displayMode = true;
  }

  private getMainFilters(filters?: IMainFiltersModel) {
    if (filters) {
      this.overviewSummaryFilter.companyId = filters.company
        ? filters.company.id
        : null;
      this.overviewSummaryFilter.siteIds = filters.locations.length
        ? filters.locations.map((item) => item.id)
        : [];

      if (filters.timeFrame) {
        this.overviewSummaryFilter.dateCreatedFilter = {
          utcStartDate: filters.timeFrame.startDt,
          utcEndDate: filters.timeFrame.endDt
        };
      } else {
        this.overviewSummaryFilter.dateCreatedFilter = null;
      }
    }
  }
}
