import { Component, OnInit, ViewChild } from '@angular/core';
import { MainService } from '@appRoot/features/main.service';
import { AppService } from '@appRoot/app.service';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { IMainFiltersModel } from '@core/components/main-filters/main-filters.model';
import {
  BatchSummaryModel,
  IBatchSummaryRequestModel,
  IPaginatedResponseModel
} from './batch-summary.model';
import { Table } from 'primeng/components/table/table';
import { BatchSummaryService } from '@appRoot/features/batch-summary/batch-summary.service';
import { LazyLoadEvent } from 'primeng/components/common/lazyloadevent';
import { IDynamicPaginationOption } from '@core/components/dynamic-pagination/dynamic-pagination.model';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: '[dbcp-batch-summary]',
  templateUrl: './batch-summary.component.html',
  styleUrls: ['./batch-summary.component.scss']
})
export class BatchSummaryComponent implements OnInit {
  public batches: BatchSummaryModel[];
  public batchesTbCols: any[];
  public totalBatchCount: number;
  public first: number = 1;
  public rowCount: number = 10;
  public activePageSizeOptions: number = 10;

  @ViewChild('batchListDt', { static: false })
  public batchListDt: Table;

  private batchSummaryListRequestFilter: IBatchSummaryRequestModel = {
    companyId: null,
    siteIds: [],
    dateCreatedFilter: null,
    offset: null,
    pageSize: null
  };

  constructor(
    private mainService: MainService,
    private appService: AppService,
    private batchSummaryService: BatchSummaryService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  public ngOnInit() {
    this.batchesTbCols = [
      {
        field: 'batchId',
        header: LocalizePipe.Instance.transform(
          'BATCH_SUMMARY_LIST_HEADER_TITLE_BATCH_NAME'
        )
      },
      {
        field: 'status',
        header: LocalizePipe.Instance.transform(
          'BATCH_SUMMARY_LIST_HEADER_TITLE_STATUS'
        )
      },
      {
        field: 'slaHours',
        header: LocalizePipe.Instance.transform(
          'BATCH_SUMMARY_LIST_HEADER_TITLE_SLA'
        )
      },
      {
        field: 'dateReceived',
        header: LocalizePipe.Instance.transform(
          'BATCH_SUMMARY_LIST_HEADER_TITLE_DATE_RECEIVED'
        )
      },
      {
        field: 'unresolvedCount',
        header: LocalizePipe.Instance.transform(
          'BATCH_SUMMARY_LIST_HEADER_TITLE_EXCEPTIONS'
        )
      }
    ];
  }

  public async onMainFiltersValues(filters: IMainFiltersModel) {
    await this.getBatchList(filters);
    this.adjustPageSize(10);
    this.first = 0;
  }

  public onMainFiltersError(msg: string) {
    // Display error message.
    this.batches = [];
    this.mainService.errorAlertSubject$.next();
  }

  public onBatchSelect(event: any) {
    if (event && event.data && event.data.batchId) {
      this.router.navigate([event.data.batchId, 'exceptions'], {
        relativeTo: this.route
      });
    } else {
      // TODO:: DISPLAY SOME ERROR MESSAGE
    }
  }

  public getBatchStyle(field: string, slaHours: string) {
    const sla: number = +slaHours;
    let color: string = '#F52C2C';
    if (sla >= 48) {
      color = '#24C61D';
    } else if (sla >= 24) {
      color = '#F0981F';
    } else {
      color = '#F52C2C';
    }

    switch (field) {
      case 'batchId':
        return {
          'border-color': color
        };
      case 'slaHours':
        return {
          'background-color': color
        };
    }
  }

  public loadMoreBatches(event: LazyLoadEvent) {
    if (
      this.batchSummaryListRequestFilter.companyId === null ||
      event.first === 1
    ) {
      return;
    }
    this.getBatchesPerPage(event.first, event.rows, event);
  }

  public onDyPaginationValue(pageSizeModel: IDynamicPaginationOption) {
    this.adjustPageSize(pageSizeModel.pageSize);
  }

  private getBatchList(filters?: IMainFiltersModel) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      this.batches = [];

      if (filters) {
        this.batchSummaryListRequestFilter.companyId = filters.company
          ? filters.company.id
          : null;
        this.batchSummaryListRequestFilter.siteIds = filters.locations.length
          ? filters.locations.map((item) => item.id)
          : [];

        if (filters.timeFrame) {
          this.batchSummaryListRequestFilter.dateCreatedFilter = {
            utcStartDate: filters.timeFrame.startDt,
            utcEndDate: filters.timeFrame.endDt
          };
        } else {
          this.batchSummaryListRequestFilter.dateCreatedFilter = null;
        }
      }

      this.batchSummaryListRequestFilter.offset = 0;
      this.batchSummaryListRequestFilter.pageSize = 10;
      this.batchSummaryService
        .getBatchSummary(this.batchSummaryListRequestFilter)
        .then((response: IPaginatedResponseModel) => {
          this.batches = response.summary;
          this.totalBatchCount = response.count;
          this.appService.spinner.hide();

          resolve();
        })
        .catch((e) => {
          this.appService.spinner.hide();
          console.log('There was an error');
          console.log(e);
        });
    });
  }

  private getBatchesPerPage(
    offset: number,
    pageSize: number,
    event?: LazyLoadEvent
  ) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      this.batches = [];

      this.batchSummaryListRequestFilter.offset = offset;
      this.batchSummaryListRequestFilter.pageSize = pageSize;

      this.batchSummaryService
        .getBatchSummary(this.batchSummaryListRequestFilter)
        .then((response: IPaginatedResponseModel) => {
          this.batches = response.summary;
          this.totalBatchCount = response.count;
          this.appService.spinner.hide();
          resolve();
        })
        .catch((e) => {
          this.appService.spinner.hide();
          console.log('There was an error');
          console.log(e);
        });
    });
  }
  private adjustPageSize(pageSize: number) {
    if (pageSize === this.activePageSizeOptions) {
      return;
    }
    if (pageSize === 0) {
      this.rowCount = this.totalBatchCount;
    } else {
      this.rowCount = pageSize;
    }
    this.activePageSizeOptions = pageSize;
    this.getBatchesPerPage(0, pageSize);
  }
}
