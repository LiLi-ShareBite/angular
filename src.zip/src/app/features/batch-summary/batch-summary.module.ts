import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { BatchSummaryComponent } from '@appRoot/features/batch-summary/batch-summary.component';
import { BATCH_SUMMARY_ROUTES } from '@appRoot/features/batch-summary/batch-summary.routes';
import { TableModule } from 'primeng/table';
import { BatchSummaryService } from '@appRoot/features/batch-summary/batch-summary.service';

@NgModule({
  declarations: [BatchSummaryComponent],
  exports: [BatchSummaryComponent],
  imports: [
    CommonModule,
    BaseControlModule,
    TableModule,
    RouterModule.forChild(BATCH_SUMMARY_ROUTES)
  ],
  providers: [BatchSummaryService],
  entryComponents: [],
  bootstrap: [BatchSummaryComponent]
})
export class BatchSummaryModule {}
