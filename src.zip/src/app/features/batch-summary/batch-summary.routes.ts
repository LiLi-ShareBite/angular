import { Routes } from '@angular/router';
import { BatchSummaryComponent } from '@appRoot/features/batch-summary/batch-summary.component';
import { RouterWrapperComponent } from '@core/components/router-wrapper/router-wrapper.component';

export const BATCH_SUMMARY_ROUTES: Routes = [
  {
    path: '',
    component: RouterWrapperComponent,
    children: [
      {
        path: '',
        component: BatchSummaryComponent
      },
      {
        path: ':batchId/exceptions',
        loadChildren: () => import('./exception').then((m) => m.ExceptionModule)
      }
    ]
  },
  {
    path: '',
    redirectTo: '/overview',
    pathMatch: 'full'
  }
];
