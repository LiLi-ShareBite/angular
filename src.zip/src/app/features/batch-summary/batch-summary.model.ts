import * as moment from 'moment';

export class BatchSummaryModel {
  public static parseObjToModel(obj: IPaginatedResponseModel) {
    return {
      count: obj.count,
      summary: obj.summary.map((batch) => {
        const model = new BatchSummaryModel(
          batch.batchId,
          batch.batchName,
          batch.status,
          batch.slaMinutes,
          batch.dateReceived
            ? moment(batch.dateReceived).format('MM/DD/YYYY HH:mm a')
            : '',
          batch.unresolvedCount
        );

        model.slaHours = batch.slaMinutes
          ? Math.floor(batch.slaMinutes / 60)
          : 0;

        return model;
      })
    };
  }

  private slaHours: number;
  constructor(
    public batchId: number,
    public batchName: string,
    public status: string,
    public slaMinutes: number,
    public dateReceived: string,
    public unresolvedCount: number
  ) {}
}

export interface IBatchSummaryRequestModel {
  companyId: number;
  siteIds: number[];
  dateCreatedFilter: {
    utcStartDate: Date;
    utcEndDate: Date;
  };
  offset: number;
  pageSize: number;
}

export interface IPaginatedResponseModel {
  count: number;
  summary: BatchSummaryModel[];
}
