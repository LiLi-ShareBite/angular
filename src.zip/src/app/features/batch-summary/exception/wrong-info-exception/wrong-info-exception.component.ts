import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import {
  DbcpSuccessAlert,
  DbcpErrorAlert
} from '@core/components/alert/alert.model';
import {
  ExceptionResolvedResultModel,
  RESOLVED_OUTCOME,
  ExceptionModel
} from '@appRoot/features/batch-summary/exception/exception.model';
import { Subscription } from 'rxjs';
import { AppService } from '@appRoot/app.service';
import { ExceptionService } from '@appRoot/features/batch-summary/exception/exception.service';

@Component({
  selector: 'dbcp-wrong-info-exception',
  templateUrl: './wrong-info-exception.component.html',
  styleUrls: ['./wrong-info-exception.component.scss']
})
export class WrongInformationExceptionComponent implements OnInit, OnDestroy {
  @Input()
  public exception: ExceptionModel | null;
  public userInput: string = '';
  public exceptionResolvedResult: ExceptionResolvedResultModel;
  private resultSubscription: Subscription;

  constructor(
    private appService: AppService,
    private exceptionService: ExceptionService
  ) {}

  public ngOnInit() {
    this.exceptionResolvedResult = new ExceptionResolvedResultModel(
      RESOLVED_OUTCOME.NA,
      this.exception.exceptionId
    );
    this.resultSubscription = this.exceptionService.$exceptionResolvedResult.subscribe(
      (result) => {
        this.exceptionResolvedResult = result;
      }
    );
  }

  public onSubmit() {
    this.appService.spinner.show();
    this.exceptionService.$exceptionResolvedResult.next(
      new ExceptionResolvedResultModel(
        RESOLVED_OUTCOME.IN_PROGRESS,
        this.exception.exceptionId
      )
    );

    this.exceptionService
      .resolveInformationException(this.exception.exceptionId, this.userInput)
      .subscribe(
        () => {
          this.appService.spinner.hide();
          this.exceptionService.$exceptionResolvedResult.next(
            new ExceptionResolvedResultModel(
              RESOLVED_OUTCOME.SUCCESS,
              this.exception.exceptionId,
              new DbcpSuccessAlert('Information successfully updated')
            )
          );
        },
        (error) => {
          this.appService.spinner.hide();
          if (error.status === 917) {
            this.exceptionService.showExceptionClosedMsg(
              this.exception.exceptionId,
              error
            );
          } else {
            this.exceptionService.$exceptionResolvedResult.next(
              new ExceptionResolvedResultModel(
                RESOLVED_OUTCOME.FAILED,
                this.exception.exceptionId,
                new DbcpErrorAlert(
                  'We are unable to complete your request. Please try again.'
                )
              )
            );
          }
        }
      );
  }

  public onDiscard() {
    this.exceptionService.onDiscard(this.exception.exceptionId, this.exception);
  }

  public ngOnDestroy() {
    if (this.resultSubscription) {
      this.resultSubscription.unsubscribe();
    }
  }
}
