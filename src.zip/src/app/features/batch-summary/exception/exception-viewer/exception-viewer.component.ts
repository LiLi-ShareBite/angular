import {
  Component,
  OnInit,
  OnDestroy,
  Renderer2,
  ViewChild,
  ElementRef
} from '@angular/core';
import { AppService } from '@appRoot/app.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { ExceptionService } from '@appRoot/features/batch-summary/exception/exception.service';
import {
  ISelectedExceptionModel,
  ExceptionResolvedResultModel,
  RESOLVED_OUTCOME,
  ExceptionModel
} from '@appRoot/features/batch-summary/exception/exception.model';
import { DeviceDetectorService } from 'ngx-device-detector';
import { MainService } from '@appRoot/features/main.service';

@Component({
  selector: 'dbcp-exception-viewer',
  templateUrl: './exception-viewer.component.html',
  styleUrls: ['./exception-viewer.component.scss']
})
export class ExceptionViewerComponent implements OnInit, OnDestroy {
  public batchId: string;
  public exceptionViewMessage: string;
  public exceptionDocumentPreviewMessage: string;
  public exceptionResolvedResult: ExceptionResolvedResultModel;
  public selectedException: ExceptionModel | null;
  public exceptionDocumentURL: string;

  @ViewChild('exceptionDocumentFrame', { read: ElementRef, static: false })
  public exceptionDocumentFrame: ElementRef;
  private selectedExceptionSubscription: Subscription;
  private selectedExceptionSummary: ISelectedExceptionModel | null = null;
  private exceptionResultSubscription: Subscription;

  constructor(
    private appService: AppService,
    private route: ActivatedRoute,
    private deviceDetector: DeviceDetectorService,
    private exceptionService: ExceptionService,
    private renderer: Renderer2,
    private mainService: MainService
  ) {
    this.batchId = this.route.snapshot.paramMap.get('batchId');
    this.exceptionDocumentPreviewMessage = 'Preparing to load preview.';
    this.exceptionViewMessage =
      'Preparing to load details of the selected exception.';

    this.selectedExceptionSubscription = this.exceptionService.$selectedException.subscribe(
      (result: ISelectedExceptionModel | null) => {
        this.selectedExceptionSummary = result;

        if (this.selectedExceptionSummary) {
          this.getExceptionDetails(
            +this.selectedExceptionSummary.exception.exceptionId
          );
          this.loadExceptionDocument(
            +this.selectedExceptionSummary.exception.exceptionId
          );
        }
      }
    );

    this.exceptionResultSubscription = this.exceptionService.$exceptionResolvedResult.subscribe(
      (result) => {
        this.exceptionResolvedResult = result;
        if (result.outcome === RESOLVED_OUTCOME.IN_PROGRESS) {
          this.toggleExceptionDocumentFrame(true);
        } else {
          this.toggleExceptionDocumentFrame(false);
        }
      }
    );
  }

  public async ngOnInit() {}

  public toggleExceptionDocumentFrame = (status: boolean) => {
    if (
      this.deviceDetector.browser.toLowerCase().trim() === 'ie' &&
      this.deviceDetector.browser_version.toLowerCase().trim() === '11.0'
    ) {
      if (status) {
        this.renderer.addClass(
          this.exceptionDocumentFrame.nativeElement,
          'invisible'
        );
      } else {
        this.renderer.removeClass(
          this.exceptionDocumentFrame.nativeElement,
          'invisible'
        );
      }
    }
  };

  public ngOnDestroy() {
    if (this.selectedExceptionSubscription) {
      this.selectedExceptionSubscription.unsubscribe();
    }

    if (this.exceptionResultSubscription) {
      this.exceptionResultSubscription.unsubscribe();
    }
  }

  private getExceptionDetails = (exceptionId: number) => {
    this.appService.spinner.show();
    this.selectedException = null;
    this.exceptionService.getExceptionDetails(exceptionId).subscribe(
      (e: ExceptionModel) => {
        this.selectedException = JSON.parse(JSON.stringify(e));

        this.appService.spinner.hide();
      },
      (error) => {
        this.appService.spinner.hide();

        if (error.status === 917) {
          this.exceptionService.showExceptionClosedMsg(
            exceptionId.toString(),
            error
          );
          this.exceptionViewMessage =
            'Exception details are no longer available. Please select a different exception from the list.';
        } else if (error.status !== 400) {
          this.exceptionViewMessage =
            'Unable to retrieve details of the selected exception.';
          // Display error message.
          this.mainService.errorAlertSubject$.next();
        }

        // throw error;
      }
    );
  };

  private loadExceptionDocument = (exceptionId: number) => {
    this.appService.spinner.show();
    this.exceptionDocumentPreviewMessage = 'Loading...';
    this.exceptionService.getExceptionDocument(exceptionId).subscribe(
      (response: any) => {
        if (response) {
          let url: any = new Blob([response], {
            type: 'application/pdf'
          });

          url = URL.createObjectURL(url);
          this.exceptionDocumentURL = `${url}#view=FitH&toolbar=0`;
        } else {
          this.exceptionDocumentURL = '';
        }

        this.appService.spinner.hide();
      },
      (error) => {
        this.exceptionDocumentPreviewMessage =
          'Unable to retrieve the preview.';
        this.appService.spinner.hide();
      }
    );
  };
}
