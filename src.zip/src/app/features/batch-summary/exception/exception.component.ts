import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  BreadCrumbService,
  IBreadCrumbItem
} from '@core/components/bread-crumb/bread-crumb.service';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import {
  IBatchExceptionsListResponseModel,
  ISelectedExceptionModel,
  RESOLVED_OUTCOME,
  ExceptionResolvedResultModel,
  IBatchExceptionSummaryModel
} from '@appRoot/features/batch-summary/exception/exception.model';
import { ExceptionService } from '@appRoot/features/batch-summary/exception/exception.service';
import { AppService } from '@appRoot/app.service';
import { Subscription } from 'rxjs';
import { MainService } from '@appRoot/features/main.service';
import { ModalsService } from '@appRoot/-modals/modals.service';

@Component({
  selector: '[dbcp-batch-summary-exception]',
  templateUrl: './exception.component.html',
  styleUrls: ['./exception.component.scss']
})
export class ExceptionComponent implements OnInit, OnDestroy {
  public header: string;
  public batchId: string;
  public EXCEPTION_RESOLVED_OUTCOME: typeof RESOLVED_OUTCOME = RESOLVED_OUTCOME;
  public batchExceptionsList: IBatchExceptionSummaryModel[];
  public selectedException: ISelectedExceptionModel | null = null;
  public exceptionResolvedResult: ExceptionResolvedResultModel;
  private breadCrumb: IBreadCrumbItem[];
  private selectedExceptionSubscription: Subscription;
  private exceptionResultSubscription: Subscription;

  constructor(
    private route: ActivatedRoute,
    private breadCrumbService: BreadCrumbService,
    private exceptionService: ExceptionService,
    private appService: AppService,
    private mainService: MainService,
    private modalsService: ModalsService
  ) {
    this.batchId = this.route.snapshot.paramMap.get('batchId');
    this.batchExceptionsList = [];
  }

  public async ngOnInit() {
    this.selectedExceptionSubscription = this.exceptionService.$selectedException.subscribe(
      (result: ISelectedExceptionModel | null) => {
        this.selectedException = result;
      }
    );

    this.exceptionResultSubscription = this.exceptionService.$exceptionResolvedResult.subscribe(
      (result) => {
        this.exceptionResolvedResult = result;

        if (
          this.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.SUCCESS ||
          this.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.CLOSED
        ) {
          this.onExceptionResultUpdate(result);
        }
      }
    );

    this.header = LocalizePipe.Instance.transform(
      'BATCH_SUMMARY_EXCPETIONS_TITLE',
      this.batchId
    );

    this.setBreadCrumbNavigation();

    this.getExceptionsList();
  }

  public ngOnDestroy() {
    if (this.selectedExceptionSubscription) {
      this.selectedExceptionSubscription.unsubscribe();
    }

    if (this.exceptionResultSubscription) {
      this.exceptionResultSubscription.unsubscribe();
    }

    setTimeout(() => {
      this.breadCrumbService.setBreadCrumb([]);
    }, 0);
  }

  public onNextExceptionClick = (e: MouseEvent) => {
    e.preventDefault();
    this.mainService.errorAlertSubject$.next(null);

    if (!this.batchExceptionsList && this.selectedException) {
      return;
    }

    if (this.selectedException.index === this.batchExceptionsList.length - 1) {
      return;
    }

    if (
      this.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.SUCCESS ||
      this.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.CLOSED
    ) {
      this.onNextExceptionSelect();
    } else {
      this.modalsService
        .openConfirmModal(
          'Exception not resolved',
          'The exception is not resolved. Are you sure you want to leave this page?'
        )
        .then(
          () => {
            this.onNextExceptionSelect();
          },
          () => {
            return;
          }
        );
    }
  };

  public onNextExceptionSelect = () => {
    let index: number = 0;

    if (!this.selectedException) {
      index = this.selectedException.index + 1;
    }

    for (let i = index; i < this.batchExceptionsList.length; i++) {
      if (this.batchExceptionsList[i].resolvedOutcome) {
        if (
          this.batchExceptionsList[i].resolvedOutcome !==
          this.EXCEPTION_RESOLVED_OUTCOME.CLOSED
        ) {
          this.exceptionService.$selectedException.next({
            exception: this.batchExceptionsList[i],
            index
          });

          break;
        }
      } else {
        this.exceptionService.$selectedException.next({
          exception: this.batchExceptionsList[i],
          index
        });

        break;
      }
    }
  };

  private getExceptionsList = () => {
    this.appService.spinner.show();
    this.exceptionService.getBatchExceptionsList(+this.batchId).subscribe(
      (response: IBatchExceptionsListResponseModel) => {
        this.batchExceptionsList = response.summary;
        if (this.batchExceptionsList && this.batchExceptionsList.length) {
          this.exceptionService.$selectedException.next({
            exception: this.batchExceptionsList[0],
            index: 0
          });
        }
        this.appService.spinner.hide();
      },
      (error: any) => {
        // TODO: Display error message
        this.batchExceptionsList = null;
        this.exceptionService.$selectedException.next(null);
        this.appService.spinner.hide();
      }
    );
  };

  private setBreadCrumbNavigation = () => {
    this.breadCrumb = [
      {
        label: LocalizePipe.Instance.transform(
          'BATCH_SUMMARY_EXCPETIONS_BREADCRUMB_ITEM1_TEXT'
        ),
        enabled: true,
        url: `/batch-summary`
      },
      {
        label: `${LocalizePipe.Instance.transform(
          'BATCH_SUMMARY_EXCPETIONS_BREADCRUMB_ITEM2_TEXT',
          this.batchId
        )}`,
        enabled: false
      }
    ];

    setTimeout(() => {
      this.breadCrumbService.setBreadCrumb(this.breadCrumb);
    }, 0);
  };

  private onExceptionResultUpdate = (result: ExceptionResolvedResultModel) => {
    if (result.outcome === this.EXCEPTION_RESOLVED_OUTCOME.SUCCESS) {
      this.updateSelectedExceptionOnSuccessResultUpdate();
    } else {
      if (
        result.exceptionId &&
        this.batchExceptionsList &&
        this.batchExceptionsList.length > 0
      ) {
        const selectedException:
          | IBatchExceptionSummaryModel
          | undefined = this.batchExceptionsList.find(
          (exception: IBatchExceptionSummaryModel) =>
            exception.exceptionId === +result.exceptionId
        );

        if (selectedException) {
          selectedException.resolvedOutcome = result.outcome;
          this.batchExceptionsList = [...this.batchExceptionsList];
        }
      }
    }
  };

  private updateSelectedExceptionOnSuccessResultUpdate = () => {
    // If either the exception list does not exists or there are no exceptions in the list.
    if (!this.batchExceptionsList || !this.batchExceptionsList.length) {
      this.exceptionService.$selectedException.next(null);
      return;
    }

    const resolvedExceptionIndex: number = this.selectedException.index;
    const batchList: IBatchExceptionSummaryModel[] = [
      ...this.batchExceptionsList
    ];

    // Remove the current successfull resolved exception
    batchList.splice(resolvedExceptionIndex, 1);
    this.batchExceptionsList = [...batchList];
    this.exceptionService.$selectedException.next(null);

    // If exception list is empty.
    if (batchList.length === 0) {
      return;
    }

    // If the list has only 1 unresolved exception left.
    if (this.batchExceptionsList.length === 1) {
      this.exceptionService.$selectedException.next({
        exception: this.batchExceptionsList[0],
        index: 0
      });

      return;
    }

    // If the resolved exception was the last item in the list.
    if (resolvedExceptionIndex === this.batchExceptionsList.length) {
      this.exceptionService.$selectedException.next({
        exception: this.batchExceptionsList[
          this.batchExceptionsList.length - 1
        ],
        index: this.batchExceptionsList.length - 1
      });

      return;
    }

    this.exceptionService.$selectedException.next({
      exception: this.batchExceptionsList[resolvedExceptionIndex],
      index: resolvedExceptionIndex
    });

    return;
  };
}
