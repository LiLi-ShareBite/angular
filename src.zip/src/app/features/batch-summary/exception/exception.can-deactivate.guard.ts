import {
  CanDeactivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { Observable } from 'rxjs';
import { RESOLVED_OUTCOME } from '@appRoot/features/batch-summary/exception/exception.model';
import { Injectable } from '@angular/core';
import { AppService } from '@appRoot/app.service';
import { ExceptionComponent } from '@appRoot/features/batch-summary/exception/exception.component';

@Injectable()
export class ExceptionCanDeactivateGuard implements CanDeactivate<any> {
  private userTimeoutStatus: boolean = false;

  constructor(
    private modalsService: ModalsService,
    private appService: AppService
  ) {
    this.appService.onUserTimeoutStatus$.subscribe((status: boolean) => {
      this.userTimeoutStatus = status;
    });
  }

  public canDeactivate(
    component: ExceptionComponent,
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    if (this.userTimeoutStatus) {
      return true;
    }

    if (
      !component ||
      component.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.SUCCESS ||
      component.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.CLOSED
    ) {
      return true;
    }

    // Display popup
    return this.modalsService
      .openConfirmModal(
        'Exception not resolved',
        'The exception is not resolved. Are you sure you want to leave this page?'
      )
      .then(
        () => {
          return true;
        },
        () => {
          return false;
        }
      );
  }
}
