import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import {
  ExceptionResolvedResultModel,
  RESOLVED_OUTCOME,
  ExceptionModel
} from '@appRoot/features/batch-summary/exception/exception.model';
import { Subscription } from 'rxjs';
import { ExceptionService } from '@appRoot/features/batch-summary/exception/exception.service';

@Component({
  selector: 'dbcp-image-quality-exception',
  templateUrl: './image-quality-exception.component.html',
  styleUrls: ['./image-quality-exception.component.scss']
})
export class ImageQualityExceptionComponent implements OnInit, OnDestroy {
  @Input()
  public exception: ExceptionModel | null;
  public resolveStep: number;
  public exceptionResolvedResult: ExceptionResolvedResultModel;
  private resultSubscription: Subscription;

  constructor(private exceptionService: ExceptionService) {}

  public ngOnInit() {
    this.resolveStep = 0;

    this.exceptionResolvedResult = new ExceptionResolvedResultModel(
      RESOLVED_OUTCOME.NA,
      this.exception.exceptionId
    );
    this.resultSubscription = this.exceptionService.$exceptionResolvedResult.subscribe(
      (result) => {
        this.exceptionResolvedResult = result;
      }
    );
  }

  public onReplace() {
    this.resolveStep = 1;
  }

  public onDiscard() {
    this.exceptionService.onDiscard(this.exception.exceptionId, this.exception);
  }

  public ngOnDestroy() {
    if (this.resultSubscription) {
      this.resultSubscription.unsubscribe();
    }
  }
}
