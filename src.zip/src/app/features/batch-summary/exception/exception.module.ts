import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { ExceptionComponent } from '@appRoot/features/batch-summary/exception/exception.component';
import { BATCH_SUMMARY_EXCEPTION_ROUTES } from '@appRoot/features/batch-summary/exception/exception.routes';
import { ButtonModule } from 'primeng/button';
import { ExceptionService } from '@appRoot/features/batch-summary/exception/exception.service';
import { ExceptionListComponent } from '@appRoot/features/batch-summary/exception/exception-list/exception-list.component';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { ModalsModule } from '@appRoot/-modals';
import { ExceptionViewerComponent } from '@appRoot/features/batch-summary/exception/exception-viewer/exception-viewer.component';
import { AccordionModule } from 'primeng/accordion';
import { RescanConfirmComponent } from '@appRoot/features/batch-summary/exception/+replace-document/rescan-confirm/rescan-confirm.component';
import { MissingInformationExceptionComponent } from '@appRoot/features/batch-summary/exception/missing-info-exception/missing-info-exception.component';
import { WrongInformationExceptionComponent } from '@appRoot/features/batch-summary/exception/wrong-info-exception/wrong-info-exception.component';
import { ImageQualityExceptionComponent } from '@appRoot/features/batch-summary/exception/image-quality-exception/image-quality-exception.component';
import { DuplicateBatchExceptionComponent } from '@appRoot/features/batch-summary/exception/duplicate-batch-exception/duplicate-batch-exception.component';
import { ReplaceDocumentComponent } from '@appRoot/features/batch-summary/exception/+replace-document/replace-document.component';
import { RadioButtonModule } from 'primeng/radiobutton';
import { FileUploadModule } from 'primeng/fileupload';
import { ExceptionCanDeactivateGuard } from '@appRoot/features/batch-summary/exception/exception.can-deactivate.guard';

@NgModule({
  declarations: [
    ExceptionComponent,
    ExceptionListComponent,
    ExceptionViewerComponent,
    MissingInformationExceptionComponent,
    WrongInformationExceptionComponent,
    ImageQualityExceptionComponent,
    DuplicateBatchExceptionComponent,
    ReplaceDocumentComponent,
    RescanConfirmComponent
  ],
  exports: [],
  imports: [
    CommonModule,
    BaseControlModule,
    FormsModule,
    ModalsModule,
    AccordionModule,
    ButtonModule,
    RadioButtonModule,
    FileUploadModule,
    RouterModule.forChild(BATCH_SUMMARY_EXCEPTION_ROUTES),
    DeviceDetectorModule.forRoot()
  ],
  providers: [ExceptionService, ExceptionCanDeactivateGuard],
  entryComponents: [RescanConfirmComponent],
  bootstrap: [ExceptionComponent]
})
export class ExceptionModule {}
