import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { AppService } from '@appRoot/app.service';
import {
  IBatchExceptionSummaryModel,
  ISelectedExceptionModel,
  ExceptionResolvedResultModel,
  RESOLVED_OUTCOME
} from '@appRoot/features/batch-summary/exception/exception.model';
import { Subscription } from 'rxjs';
import { ExceptionService } from '@appRoot/features/batch-summary/exception/exception.service';
import { MainService } from '@appRoot/features/main.service';
import { ModalsService } from '@appRoot/-modals/modals.service';

@Component({
  selector: 'dbcp-batch-exception-list',
  templateUrl: './exception-list.component.html',
  styleUrls: ['./exception-list.component.scss']
})
export class ExceptionListComponent implements OnInit, OnDestroy {
  @Input()
  public exceptionLst: IBatchExceptionSummaryModel[];
  public selectedException: ISelectedExceptionModel | null = null;
  public exceptionResolvedResult: ExceptionResolvedResultModel;
  private EXCEPTION_RESOLVED_OUTCOME: typeof RESOLVED_OUTCOME = RESOLVED_OUTCOME;
  private selectedExceptionSubscription: Subscription;
  private exceptionResultSubscription: Subscription;

  constructor(
    private appService: AppService,
    private exceptionService: ExceptionService,
    private mainService: MainService,
    private modalsService: ModalsService
  ) {}

  public async ngOnInit() {
    this.selectedExceptionSubscription = this.exceptionService.$selectedException.subscribe(
      (result: ISelectedExceptionModel | null) => {
        this.selectedException = result;

        if (this.selectedException) {
          this.exceptionService.$exceptionResolvedResult.next({
            outcome: RESOLVED_OUTCOME.NA,
            exceptionId: this.selectedException.exception.exceptionId.toString()
          });
        }
      }
    );

    this.exceptionResultSubscription = this.exceptionService.$exceptionResolvedResult.subscribe(
      (result) => {
        this.exceptionResolvedResult = result;
      }
    );
  }

  public ngOnDestroy() {
    if (this.selectedExceptionSubscription) {
      this.selectedExceptionSubscription.unsubscribe();
    }
    if (this.exceptionResultSubscription) {
      this.exceptionResultSubscription.unsubscribe();
    }
  }

  public onExceptionSelectClick = async (index: number) => {
    if (
      this.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.SUCCESS ||
      this.exceptionResolvedResult.outcome === RESOLVED_OUTCOME.CLOSED
    ) {
      this.onExceptionSelect(index);
    } else {
      this.modalsService
        .openConfirmModal(
          'Exception not resolved',
          'The exception is not resolved. Are you sure you want to leave this page?'
        )
        .then(
          () => {
            this.onExceptionSelect(index);
          },
          () => {
            return;
          }
        );
    }
  };

  private onExceptionSelect = async (index: number) => {
    this.appService.spinner.show();
    this.mainService.errorAlertSubject$.next(null);
    let exception: IBatchExceptionSummaryModel | null = null;

    try {
      exception = this.exceptionLst[index];
    } catch (e) {
      exception = null;
    }

    if (exception) {
      this.exceptionService.$exceptionResolvedResult.next({
        outcome: exception.resolvedOutcome,
        exceptionId: exception.exceptionId.toString()
      });

      if (
        exception.resolvedOutcome &&
        exception.resolvedOutcome !== this.EXCEPTION_RESOLVED_OUTCOME.NA
      ) {
        this.exceptionService.$selectedException.next(null);
        this.appService.spinner.hide();
        return;
      }

      this.exceptionService.$selectedException.next({
        exception,
        index
      });

      this.appService.spinner.hide();
    } else {
      this.exceptionService.$selectedException.next(null);
      this.exceptionService.$exceptionResolvedResult.next({
        outcome: RESOLVED_OUTCOME.NA
      });
      this.appService.spinner.hide();
    }
  };
}
