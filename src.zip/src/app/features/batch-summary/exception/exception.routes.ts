import { Routes } from '@angular/router';
import { ExceptionComponent } from '@appRoot/features/batch-summary/exception/exception.component';
import { ExceptionCanDeactivateGuard } from '@appRoot/features/batch-summary/exception/exception.can-deactivate.guard';

export const BATCH_SUMMARY_EXCEPTION_ROUTES: Routes = [
  {
    path: '',
    component: ExceptionComponent,
    canDeactivate: [ExceptionCanDeactivateGuard]
  }
];
