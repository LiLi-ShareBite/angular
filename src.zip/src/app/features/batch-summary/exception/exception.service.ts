import { Injectable } from '@angular/core';
import { ApiService } from '@apiService';
import { HttpClient } from '@angular/common/http';
import * as util from 'util';

import { map } from 'rxjs/operators';
import {
  IBatchExceptionsListResponseModel,
  ParseBatchExceptionsListResponseModel,
  ISelectedExceptionModel,
  ExceptionResolvedResultModel,
  ExceptionModel,
  RESOLVED_OUTCOME,
  EXCEPTION_WARNING_MSG
} from '@appRoot/features/batch-summary/exception/exception.model';
import { Observable, BehaviorSubject } from 'rxjs';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { AppService } from '@appRoot/app.service';
import { DbcpSuccessAlert } from '@core/components/alert/alert.model';

const POST_BATCH_UNRESOLVED_EXCEPTIONS_LIST_API =
  'api/dbcp/exceptions/unresolved';
const GET_EXCEPTION_DETAILS_API = 'api/dbcp/exception-details/%s';
const GET_EXCEPTION_DOCUMENT_API = 'api/dbcp/exception-document/%s';
const POST_RESOLVE_EXCEPTION_UPLOAD_DOCUMENT_API =
  'api/dbcp/resolve-exception/upload-rescan/%s';
const POST_RESOLVE_EXCEPTION_RESCAN_OFFLINE_API =
  'api/dbcp/resolve-exception/rescan-offline/%s';
const GET_COVER_SHEET_DOCUMENT = 'api/dbcp/exception-cover-sheet/%s';
const POST_RESOLVE_EXCEPTION_DISCARD_API =
  'api/dbcp/resolve-exception/discard/%s';
const POST_RESOLVE_EXCEPTION_FIX_INFORMATION_API =
  'api/dbcp/resolve-exception/fix-information';

@Injectable()
export class ExceptionService extends ApiService {
  public $selectedException = new BehaviorSubject<ISelectedExceptionModel | null>(
    null
  );
  public $exceptionResolvedResult = new BehaviorSubject<
    ExceptionResolvedResultModel
  >({
    outcome: RESOLVED_OUTCOME.NA
  });
  public exceptionMsg: string;

  constructor(
    private httpClient: HttpClient,
    private modalsService: ModalsService,
    private appService: AppService
  ) {
    super(httpClient);
  }

  public getBatchExceptionsList(
    batchId: number
  ): Observable<IBatchExceptionsListResponseModel> {
    return this.post(POST_BATCH_UNRESOLVED_EXCEPTIONS_LIST_API, {
      batchId,
      pageSize: 0,
      offSet: 0
    }).pipe(
      map((response: IBatchExceptionsListResponseModel) =>
        ParseBatchExceptionsListResponseModel(response)
      )
    );
  }

  public getExceptionDetails(exceptionId: number): Observable<ExceptionModel> {
    return this.get(util.format(GET_EXCEPTION_DETAILS_API, exceptionId)).pipe(
      map((response: ExceptionModel) =>
        ExceptionModel.parseResponseToModel(exceptionId, response)
      )
    );
  }

  public showExceptionClosedMsg(exceptionId: string, error: any) {
    if (error.status === 917) {
      this.$exceptionResolvedResult.next(
        new ExceptionResolvedResultModel(RESOLVED_OUTCOME.CLOSED, exceptionId)
      );
    } else {
      this.$exceptionResolvedResult.next(
        new ExceptionResolvedResultModel(RESOLVED_OUTCOME.FAILED, exceptionId)
      );
    }

    const messageModal = this.modalsService.openMessageModal({
      windowClass: 'sm'
    });

    if (error.error.stringVariables.length !== 0) {
      this.exceptionMsg = LocalizePipe.Instance.transform(
        `${EXCEPTION_WARNING_MSG[error.error.stringKey]}`,
        ...error.error.stringVariables // Response stringVariables in array format
      );
    } else {
      this.exceptionMsg = LocalizePipe.Instance.transform(
        `${EXCEPTION_WARNING_MSG[error.error.stringKey]}`
      );
    }

    // Handle undefined case for no matching stringKey
    if (!this.exceptionMsg) {
      this.exceptionMsg = LocalizePipe.Instance.transform(
        'EXCEPTION_FILE_ERROR_OTHER'
      );
    }

    messageModal.componentInstance.header = LocalizePipe.Instance.transform(
      'EXCEPTION_MODAL_HEADER'
    );

    messageModal.componentInstance.message = `<div class="d-flex justify-content-start align-items-center">
                                                        <i class="fas fa-2x fa-info-circle mr-2 align-self-start"></i>
                                                        <span>${this.exceptionMsg}</span>

                                                      </div>`;

    messageModal.componentInstance.cancelBtnText = LocalizePipe.Instance.transform(
      'MODAL_CONFIRMATION_CLOSE'
    );
  }

  public getExceptionDocument(exceptionId: number) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };
    return this.get(
      util.format(GET_EXCEPTION_DOCUMENT_API, exceptionId),
      null,
      httpOptions
    );
  }

  public uploadExceptionDocument(exceptionId: string, fileToUpload: any) {
    const formData = new FormData();
    formData.append('file', fileToUpload);
    return this.post(
      util.format(POST_RESOLVE_EXCEPTION_UPLOAD_DOCUMENT_API, exceptionId),
      formData
    );
  }

  public rescanExceptionDocument(exceptionId: string) {
    return this.post(
      util.format(POST_RESOLVE_EXCEPTION_RESCAN_OFFLINE_API, exceptionId)
    );
  }

  public getCoverSheetDocument(exceptionId: number) {
    const httpOptions = {
      responseType: 'blob' as 'json'
    };
    return this.get(
      util.format(GET_COVER_SHEET_DOCUMENT, exceptionId),
      null,
      httpOptions
    );
  }

  public onDiscard(exceptionId: string, exception: ExceptionModel) {
    this.$exceptionResolvedResult.next(
      new ExceptionResolvedResultModel(
        RESOLVED_OUTCOME.IN_PROGRESS,
        exceptionId
      )
    );
    const discardMessage =
      `<p>` +
      LocalizePipe.Instance.transform('EXCEPTION_DISCARD_MESSAGE') +
      `</p>` +
      `<p><strong>` +
      LocalizePipe.Instance.transform('EXCEPTION_MODAL_MESSAGE_BATCH_ID') +
      ` </strong>${exception.batchId}</p>
                                <p class="word-break"><strong>` +
      LocalizePipe.Instance.transform('EXCEPTION_MODAL_MESSAGE_BATCH_NAME') +
      ` </strong>${exception.batchName}</p>
                                <p class="word-break"><strong>` +
      LocalizePipe.Instance.transform('EXCEPTION_MODAL_MESSAGE_DETAILS') +
      ` </strong>${exception.fieldsWithExceptionStr.join('. ')}</p>`;
    this.modalsService
      .openConfirmModal(
        LocalizePipe.Instance.transform('EXCEPTION_MODAL_DISCARD_EXCEPTION'),
        discardMessage
      )
      .then(
        () => {
          // Dicard the image;
          this.appService.spinner.show();
          this.discardException(exceptionId).subscribe(
            () => {
              this.appService.spinner.hide();
              this.$exceptionResolvedResult.next(
                new ExceptionResolvedResultModel(
                  RESOLVED_OUTCOME.SUCCESS,
                  exceptionId,
                  new DbcpSuccessAlert(
                    LocalizePipe.Instance.transform(
                      'EXCEPTION_MODAL_SUCCESS_DISCARDED'
                    )
                  )
                )
              );
            },
            (error) => {
              this.appService.spinner.hide();
            },
            () => {}
          );
        },
        () => {
          // Do Nothing;
          this.$exceptionResolvedResult.next(
            new ExceptionResolvedResultModel(RESOLVED_OUTCOME.NA, exceptionId)
          );
        }
      );
  }

  public discardException(exceptionId: string) {
    return this.post(
      util.format(POST_RESOLVE_EXCEPTION_DISCARD_API, exceptionId)
    );
  }

  public resolveInformationException(
    exceptionId: string,
    correctionDetails: string
  ) {
    return this.post(POST_RESOLVE_EXCEPTION_FIX_INFORMATION_API, {
      exceptionId,
      correctionDetails
    });
  }
}
