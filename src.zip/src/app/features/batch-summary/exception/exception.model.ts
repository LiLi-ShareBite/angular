import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { IDbcpAlert } from '@core/components/alert/alert.model';

export type IBatchExceptionsListResponseModel = {
  count: number;
  summary: IBatchExceptionSummaryModel[];
};

export type IBatchExceptionSummaryModel = {
  order: number;
  exceptionId: number;
  exceptionType: string;
  thumbnailAsBase64: string | SafeUrl;
  exceptionTypeCd: ERROR_TYPE;
  resolvedOutcome?: RESOLVED_OUTCOME;
};

export type ISelectedExceptionModel = {
  exception: IBatchExceptionSummaryModel;
  index: number;
};

export class ExceptionResolvedResultModel {
  constructor(
    public outcome: RESOLVED_OUTCOME,
    public exceptionId?: string,
    public alert?: IDbcpAlert
  ) {}
}

export enum RESOLVED_OUTCOME {
  SUCCESS,
  FAILED,
  NA,
  IN_PROGRESS,
  CLOSED
}

export class ExceptionModel {
  public static parseResponseToModel(
    exceptionId: number,
    data: ExceptionModel
  ) {
    const errorTypeObj = {
      1: 'Wrong Information',
      2: 'Poor Image Quality',
      3: 'Duplicate Batch',
      4: 'Missing Information'
    };

    const model = new ExceptionModel(
      data.batchId,
      data.batchName,
      data.documentId,
      data.errorType,
      data.errorDetails,
      data.fieldsWithException
    );

    model.exceptionId = exceptionId.toString();

    if (data.errorDetails) {
      model.fieldsWithExceptionStr.push(data.errorDetails);
    }

    if (data.fieldsWithException) {
      data.fieldsWithException.forEach((element: IExceptionField) => {
        model.fieldsWithExceptionStr.push(
          `${element.name} - ${element.value} - ${element.exception}`
        );
      });
    }

    for (const [key, value] of Object.entries(errorTypeObj)) {
      if (
        data.errorType &&
        value.trim().toLowerCase() === data.errorType.trim().toLowerCase()
      ) {
        model.errorTypeCd = +key;
      }
    }

    return model;
  }

  public fieldsWithExceptionStr: string[] = [];
  public errorTypeCd: ERROR_TYPE;
  public exceptionId: string;

  constructor(
    public batchId: number,
    public batchName: string,
    public documentId: string,
    public errorType: string,
    public errorDetails: string,
    public fieldsWithException: IExceptionField[]
  ) {}
}

export interface IExceptionField {
  name: string;
  value: string;
  exception: string;
}

export enum EXCEPTION_WARNING_MSG {
  EXCEPTION_NOLONGER_EXISTS = 1,
  EXCEPTION_PERMISSION_INVALID = 2,
  EXCEPTION_NOLONGER_EXISTS_WITH_USERINFO = 3,
  EXCEPTION_FILE_PROBLEM = 1000,
  EXCEPTION_FILE_TYPE = 1001,
  EXCEPTION_FILE_SIZE = 1002,
  EXCEPTION_FILE_RESOLUTION = 1003,
  EXCEPTION_FILE_UNKNOWN_ERROR = 1004
}

export enum ERROR_TYPE {
  WRONG_INFORMATION = 1,
  IMAGE_ISSUE,
  DUPLICATE_BATCH,
  MISSING_INFORMATION
}

// Method to parse the Batch unresolved exceptions list response model.
// This methods add the exception type code property.
export const ParseBatchExceptionsListResponseModel = (
  response: IBatchExceptionsListResponseModel,
  domSanitizer?: DomSanitizer
): IBatchExceptionsListResponseModel => {
  const errorTypeObj = {
    1: 'Wrong information',
    2: 'Poor image quality',
    3: 'Duplicate batch',
    4: 'Missing information'
  };

  return {
    count: response.count,
    summary: response.summary.map((exception: IBatchExceptionSummaryModel) => {
      const formattedException: IBatchExceptionSummaryModel = { ...exception };
      for (const [key, value] of Object.entries(errorTypeObj)) {
        if (
          exception.exceptionType &&
          value.trim().toLowerCase() ===
            exception.exceptionType.trim().toLowerCase()
        ) {
          formattedException.exceptionTypeCd = +key;
          formattedException.exceptionType =
            errorTypeObj[formattedException.exceptionTypeCd];
        }
      }

      if (domSanitizer) {
        formattedException.thumbnailAsBase64 = domSanitizer.bypassSecurityTrustUrl(
          `data:image/png;base64, ${exception.thumbnailAsBase64}`
        );
      } else {
        formattedException.thumbnailAsBase64 = `data:image/png;base64, ${exception.thumbnailAsBase64}`;
      }

      return formattedException;
    })
  };
};
