import { Component } from '@angular/core';
import {
  ModalButtonModel,
  PrimaryModalButtonModel
} from '@appRoot/-modals/models/modal-button.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  template: `
    <div modal-component [header]="header" [buttons]="buttons">
      <span class="content d-inline-block w-100 h-100">
        <div class="container-fluid">
          <div class="row">
            <div class="col">
              <p>
                {{
                  'REPLACE_DOCUMENT_RESCAN_CONFIRM_INFORMATION' | dbcpLocalize
                }}
              </p>
              <p>
                {{
                  'REPLACE_DOCUMENT_RESCAN_CONFIRM_COVER_SHEET' | dbcpLocalize
                }}
                <span class="download" (click)="onDownloadCoverSheetClick()">
                  {{
                    'REPLACE_DOCUMENT_RESCAN_CONFIRM_COVER_SHEET_LINK'
                      | dbcpLocalize
                  }}.</span
                >
              </p>
            </div>
          </div>
        </div>
      </span>
    </div>
  `,
  styles: [
    `
      .download {
        color: #4a90e2;
        cursor: pointer;
      }
    `
  ]
})
export class RescanConfirmComponent {
  public header: string = 'Confirm rescanning';
  public buttons: ModalButtonModel[] = [];
  public onDownloadCoverSheet: () => void;

  constructor(public activeModal: NgbActiveModal) {
    this.buttons = [
      new PrimaryModalButtonModel(
        'OK',
        () => {
          activeModal.close();
        },
        () => {
          return false;
        }
      ),
      new ModalButtonModel('Cancel', () => {
        activeModal.dismiss();
      })
    ];
  }

  public onDownloadCoverSheetClick() {
    this.onDownloadCoverSheet();
  }
}
