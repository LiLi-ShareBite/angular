import {
  Component,
  ViewEncapsulation,
  ElementRef,
  Renderer2,
  AfterViewInit,
  Input,
  OnInit
} from '@angular/core';
import {
  DbcpSuccessAlert,
  DbcpInfoAlert,
  DbcpErrorAlert
} from '@core/components/alert/alert.model';
import {
  ExceptionResolvedResultModel,
  RESOLVED_OUTCOME,
  ExceptionModel
} from '@appRoot/features/batch-summary/exception/exception.model';
import { AppService } from '@appRoot/app.service';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { RescanConfirmComponent } from '@appRoot/features/batch-summary/exception/+replace-document/rescan-confirm/rescan-confirm.component';
import { isNullOrUndefined } from 'util';
import { ExceptionService } from '@appRoot/features/batch-summary/exception/exception.service';

export enum RESOLVE_OPTIONS {
  Upload,
  Rescan
}

@Component({
  selector: 'dbcp-replace-document',
  templateUrl: './replace-document.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./replace-document.component.scss']
})
export class ReplaceDocumentComponent implements OnInit, AfterViewInit {
  @Input()
  public exception: ExceptionModel | null;

  public RESOLVE_OPTIONS: typeof RESOLVE_OPTIONS = RESOLVE_OPTIONS;
  public selectedResolveOption: RESOLVE_OPTIONS = RESOLVE_OPTIONS.Upload;
  public exceptionType: string;
  public showRescanInstructions: boolean = false;
  public whileRescanningInstruction = '';

  constructor(
    private appService: AppService,
    private modalService: ModalsService,
    private exceptionService: ExceptionService,
    private element: ElementRef,
    private renderer: Renderer2
  ) {}

  public ngOnInit() {
    switch (this.exception.errorTypeCd) {
      case 2:
        this.exceptionType = 'image';
        this.whileRescanningInstruction =
          'Make sure you choose the appropriate scanning profile, that the scanner glass is clean, and that the paper is feeding properly.';
        break;
      case 3:
        this.exceptionType = 'batch';
        this.whileRescanningInstruction =
          'Make sure you select the correct batch of documents that you want to scan.';
        break;
    }
  }

  public ngAfterViewInit() {
    this.onResolveOptionSelected(RESOLVE_OPTIONS.Upload);
  }

  public onResolveOptionSelected(option: RESOLVE_OPTIONS) {
    const elemBrowseButton = this.element.nativeElement.querySelector(
      '.ui-fileupload-choose'
    );
    if (option === RESOLVE_OPTIONS.Upload) {
      this.renderer.setStyle(elemBrowseButton, 'opacity', '1');
    } else {
      this.renderer.setStyle(elemBrowseButton, 'opacity', '.35');
    }
  }

  public myUploader(event) {
    if (
      this.selectedResolveOption === RESOLVE_OPTIONS.Upload &&
      !isNullOrUndefined(event.files[0])
    ) {
      this.exceptionService.$exceptionResolvedResult.next(
        new ExceptionResolvedResultModel(
          RESOLVED_OUTCOME.IN_PROGRESS,
          this.exception.exceptionId
        )
      );
      this.appService.spinner.show();
      this.exceptionService
        .uploadExceptionDocument(this.exception.exceptionId, event.files[0])
        .subscribe(
          () => {
            this.appService.spinner.hide();
            this.exceptionService.$exceptionResolvedResult.next(
              new ExceptionResolvedResultModel(
                RESOLVED_OUTCOME.SUCCESS,
                this.exception.exceptionId,
                new DbcpSuccessAlert('Successfully uploaded.')
              )
            );
          },
          (error) => {
            this.appService.spinner.hide();
            if (error.status === 917) {
              error.status = 918;
              this.exceptionService.showExceptionClosedMsg(
                this.exception.exceptionId,
                error
              );
            } else {
              this.exceptionService.$exceptionResolvedResult.next(
                new ExceptionResolvedResultModel(
                  RESOLVED_OUTCOME.FAILED,
                  this.exception.exceptionId,
                  new DbcpErrorAlert(
                    'We are unable to complete your request. Please try again.'
                  )
                )
              );
            }
          },
          () => {}
        );
    } else {
      return false;
    }
  }

  public onRescan() {
    this.exceptionService.$exceptionResolvedResult.next(
      new ExceptionResolvedResultModel(
        RESOLVED_OUTCOME.IN_PROGRESS,
        this.exception.exceptionId
      )
    );

    const confirmModal = this.modalService.openModal(RescanConfirmComponent, {
      windowClass: 'small-form-modal'
    });

    confirmModal.componentInstance.onDownloadCoverSheet = this.onDownloadCoverSheet.bind(
      this
    );

    confirmModal.result.then(
      (response: any) => {
        this.appService.spinner.show();
        this.exceptionService
          .rescanExceptionDocument(this.exception.exceptionId)
          .subscribe(
            () => {
              this.appService.spinner.hide();
              this.exceptionService.$exceptionResolvedResult.next(
                new ExceptionResolvedResultModel(
                  RESOLVED_OUTCOME.SUCCESS,
                  this.exception.exceptionId,
                  new DbcpInfoAlert('Waiting for your rescanned document.')
                )
              );
            },
            (error) => {
              this.appService.spinner.hide();
              if (error.status === 917) {
                this.exceptionService.showExceptionClosedMsg(
                  this.exception.exceptionId,
                  error
                );
              } else {
                this.exceptionService.$exceptionResolvedResult.next(
                  new ExceptionResolvedResultModel(
                    RESOLVED_OUTCOME.FAILED,
                    this.exception.exceptionId,
                    new DbcpErrorAlert(
                      'We are unable to complete your request. Please try again.'
                    )
                  )
                );
              }
            },
            () => {}
          );
      },
      () => {}
    );
  }

  public onRescanBackClick() {
    this.showRescanInstructions = false;
    setTimeout(() => {
      this.onResolveOptionSelected(RESOLVE_OPTIONS.Rescan);
    }, 0);
  }

  public onDownloadCoverSheet() {
    this.appService.spinner.show();
    this.exceptionService
      .getCoverSheetDocument(+this.exception.exceptionId)
      .subscribe(
        (response: any) => {
          if (response) {
            const url = URL.createObjectURL(
              new Blob([response], {
                type: 'application/pdf'
              })
            );
            const link: HTMLAnchorElement = document.createElement('a');
            link.href = url;
            link.setAttribute(
              'download',
              `Exception_cover_sheet_${this.exception.exceptionId}.pdf`
            );
            document.body.appendChild(link);
            link.click();
            link.remove();
          } else {
            this.exceptionService.$exceptionResolvedResult.next(
              new ExceptionResolvedResultModel(
                RESOLVED_OUTCOME.FAILED,
                this.exception.exceptionId,
                new DbcpErrorAlert(
                  'We are unable to complete your request. Please try again.'
                )
              )
            );
          }

          this.appService.spinner.hide();
        },
        (error) => {
          this.appService.spinner.hide();
          if (error.status === 917) {
            error.status = 918;
            this.exceptionService.showExceptionClosedMsg(
              this.exception.exceptionId,
              error
            );
          } else {
            this.exceptionService.$exceptionResolvedResult.next(
              new ExceptionResolvedResultModel(
                RESOLVED_OUTCOME.FAILED,
                this.exception.exceptionId,
                new DbcpErrorAlert(
                  'We are unable to complete your request. Please try again.'
                )
              )
            );
          }
        },
        () => {}
      );
  }
}
