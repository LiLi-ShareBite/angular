import { ApiService } from '@apiService';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import {
  IBatchSummaryRequestModel,
  IPaginatedResponseModel,
  BatchSummaryModel
} from '@appRoot/features/batch-summary/batch-summary.model';

const GET_BATCH_SUMMARY_API = 'api/dbcp/exceptions/summary';

@Injectable()
export class BatchSummaryService extends ApiService {
  public getBatchSummary(filters: IBatchSummaryRequestModel) {
    return new Promise((resolve, reject) => {
      this.post(GET_BATCH_SUMMARY_API, filters)
        .pipe(
          map((response: IPaginatedResponseModel) => {
            return BatchSummaryModel.parseObjToModel(response);
          })
        )
        .subscribe(
          (batchArrObj: IPaginatedResponseModel) => {
            resolve(batchArrObj);
          },
          () => {
            reject();
          },
          () => {}
        );
    });
  }
}
