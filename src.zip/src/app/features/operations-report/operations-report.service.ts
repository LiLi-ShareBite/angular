import { Injectable } from '@angular/core';
import {
  OperReportModel,
  IReportListRequestModel
} from '@appRoot/features/operations-report/operations-report.model';
import { ApiService } from '@apiService';
import * as util from 'util';
import { map } from 'rxjs/operators';

const GET_BATCH_LIST_API = 'api/dbcp/batch-count-overview-by-location';

@Injectable()
export class OperationsReportService extends ApiService {
  public getOperReportList(filters: IReportListRequestModel) {
    return new Promise((resolve, reject) => {
      this.post(GET_BATCH_LIST_API, filters)
        .pipe(
          map((response: OperReportModel[]) =>
            OperReportModel.parseObjArrToModel(response)
          )
        )
        .subscribe(
          (batchArrObj: OperReportModel[]) => {
            resolve(batchArrObj);
          },
          () => {
            reject();
          },
          () => {}
        );
    });
  }
}
