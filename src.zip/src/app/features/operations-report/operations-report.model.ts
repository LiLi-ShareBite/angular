import * as moment from 'moment';
import {
  CompanyModel,
  LocationModel
} from '@core/components/main-filters/main-filters.model';

export class OperReportModel {
  public static parseObjArrToModel(objArr: OperReportModel[]) {
    return objArr.map((obj) => {
      const model = new OperReportModel(
        obj.locationId,
        obj.location,
        obj.batchesUploaded,
        obj.batchesInProcess,
        obj.batchesDelivered,
        obj.batchesWithException,
        obj.dateCreated
          ? moment(obj.dateCreated).format('MM/DD/YYYY HH:mm')
          : '',
        moment(obj.dateDelivered).format('MM/DD/YYYY HH:mm'),
        obj.notes
      );
      return model;
    });
  }

  constructor(
    public locationId: number,
    public location: string,
    public batchesUploaded: number,
    public batchesInProcess: number,
    public batchesDelivered: number,
    public batchesWithException: string,
    public dateCreated: string,
    public dateDelivered: string,
    public notes: string
  ) {}
}

export class UserDetailAppModel {
  constructor(
    public role: USER_ROLE,
    public company: CompanyModel,
    public sites: LocationModel[]
  ) {}
}

export interface IReportListRequestModel {
  companyId: number;
  siteIds: number[];
  dateCreatedFilter: {
    utcStartDate: Date;
    utcEndDate: Date;
  };
}

export enum USER_ROLE {
  SYSTEM_ADMIN,
  ADMIN,
  MANAGER,
  USER
}
