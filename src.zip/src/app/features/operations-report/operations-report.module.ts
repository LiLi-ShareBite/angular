import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { OperationsReportComponent } from '@appRoot/features/operations-report/operations-report.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { OPERATIONS_REPORT_ROUTES } from '@appRoot/features/operations-report/operations-report.routes';
import { OperationsReportService } from '@appRoot/features/operations-report/operations-report.service';
import { TableModule } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';
import { ModalsModule } from '@appRoot/-modals';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { DropdownModule } from 'primeng/dropdown';
import { RoleGuard } from '@core/guards/role.guard';

@NgModule({
  declarations: [OperationsReportComponent],
  exports: [OperationsReportComponent],
  imports: [
    CommonModule,
    FormsModule,
    DropdownModule,
    ModalsModule,
    TableModule,
    TooltipModule,
    BaseControlModule,
    RouterModule.forChild(OPERATIONS_REPORT_ROUTES)
  ],
  providers: [OperationsReportService, RoleGuard],
  entryComponents: [],
  bootstrap: [OperationsReportComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class OperationsReportModule {}
