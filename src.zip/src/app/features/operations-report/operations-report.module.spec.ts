import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OperationsReportModule } from './operations-report.module';
import { OperationsReportComponent } from './operations-report.component';

describe('OperationsReportModule', () => {
  let operationsReportModule: OperationsReportModule;

  beforeEach(() => {
    operationsReportModule = new OperationsReportModule();
  });

  it('should create an instance', () => {
    expect(operationsReportModule).toBeTruthy();
  });
});
