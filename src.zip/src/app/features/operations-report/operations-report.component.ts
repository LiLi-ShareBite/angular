import { Component, OnInit, ViewChild } from '@angular/core';
import { OperationsReportService } from '@appRoot/features/operations-report/operations-report.service';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { IMainFiltersModel } from '@core/components/main-filters/main-filters.model';
import { MainFiltersComponent } from '@core/components/main-filters/main-filters.component';
import {
  OperReportModel,
  IReportListRequestModel
} from '@appRoot/features/operations-report/operations-report.model';
import { Table } from 'primeng/components/table/table';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { LocalizePipe } from '@core/pipes/localize.pipe';

@Component({
  selector: '[dbcp-operations-report]',
  templateUrl: './operations-report.component.html',
  styleUrls: ['./operations-report.component.scss']
})
export class OperationsReportComponent implements OnInit {
  public OperationsReportTbCols: any[];
  public reports: OperReportModel[];

  @ViewChild('MainFiltersComponent', { static: false })
  public reportsListDt: MainFiltersComponent;

  private operReportRequestFilter: IReportListRequestModel = {
    companyId: null,
    siteIds: [],
    dateCreatedFilter: null
  };

  constructor(
    private modalsService: ModalsService,
    private mainService: MainService,
    private appService: AppService,
    private operReportService: OperationsReportService
  ) {}

  public ngOnInit() {
    this.OperationsReportTbCols = [
      {
        field: 'location',
        header: LocalizePipe.Instance.transform('OPERATIONS_REPORT_LOCATION')
      },
      {
        field: 'batchesUploaded',
        header: LocalizePipe.Instance.transform('OPERATIONS_REPORT_RECEIVED')
      },
      {
        field: 'batchesInProcess',
        header: LocalizePipe.Instance.transform('OPERATIONS_REPORT_PROCESSING')
      },
      {
        field: 'batchesWithException',
        header: LocalizePipe.Instance.transform('OPERATIONS_REPORT_EXCEPTIONS')
      },
      {
        field: 'batchesDelivered',
        header: LocalizePipe.Instance.transform('OPERATIONS_REPORT_DELIVERED')
      }
    ];
  }

  public onMainFiltersError(msg: string) {
    // Display error message.
    this.mainService.errorAlertSubject$.next();
  }

  public onMainFiltersValues(filters: IMainFiltersModel) {
    this.getReportsList(filters);
  }

  private getReportsList(filters?: IMainFiltersModel) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      this.reports = [];

      if (filters) {
        // No siteIds specify in Operation Report view
        this.operReportRequestFilter.companyId = filters.company
          ? filters.company.id
          : null;
        this.operReportRequestFilter.siteIds = filters.locations
          ? filters.locations.map((item) => item.id)
          : [];

        if (filters.timeFrame) {
          this.operReportRequestFilter.dateCreatedFilter = {
            utcStartDate: filters.timeFrame.startDt,
            utcEndDate: filters.timeFrame.endDt
          };
        } else {
          this.operReportRequestFilter.dateCreatedFilter = null;
        }
      }

      this.operReportService
        .getOperReportList(this.operReportRequestFilter)
        .then(
          (response: OperReportModel[]) => {
            this.reports = response;
            this.appService.spinner.hide();
            resolve();
          },
          () => {
            // Show error message
            this.appService.spinner.hide();
            reject();
          }
        );
    });
  }
}
