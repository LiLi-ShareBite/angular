import { Routes } from '@angular/router';
import { RoleGuard } from '@core/guards/role.guard';
import { USER_ROLE } from '@appRoot/features/user-management/user.model';
import { OperationsReportComponent } from '@appRoot/features/operations-report/operations-report.component';

export const OPERATIONS_REPORT_ROUTES: Routes = [
  {
    path: '',
    component: OperationsReportComponent,
    data: {
      currentFeature: 'Operations_Report'
    }
  }
];
