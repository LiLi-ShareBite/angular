import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { OperationsReportComponent } from './operations-report.component';
import { OperationsReportService } from './operations-report.service';
import { By } from '@angular/platform-browser';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { SentenceCasePipe } from '@core/pipes/sentence-case.pipe';
import { Injectable } from '@angular/core';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { ModalsService } from '@appRoot/-modals/modals.service';

@Component({
  templateUrl: './operations-report.component.html'
})
@Component({
  templateUrl: ''
})
@Injectable()
class MockComponent {}

class OperationsReportServiceStub {
  public getOperReportList() {}
}

describe('Component: OperationsReportComponent', () => {
  let component: OperationsReportComponent;
  let service: OperationsReportService;
  let fixture: ComponentFixture<OperationsReportComponent>;

  let dElem: DebugElement;
  let elem: HTMLElement;

  beforeEach(() => {
    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        RouterTestingModule.withRoutes([
          {
            path: 'http://localhost:4200/#/operations-report',
            component: MockComponent
          }
        ])
      ],
      declarations: [
        OperationsReportComponent,
        MockComponent,
        LocalizePipe,
        SentenceCasePipe
      ],
      providers: [
        {
          provide: OperationsReportService,
          useClass: OperationsReportServiceStub
        },
        { provide: AppService },
        { provide: MainService },
        { provide: DeviceDetectorService },
        { provide: ModalsService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(OperationsReportComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    service = fixture.debugElement.injector.get(OperationsReportService);

    dElem = fixture.debugElement;
    elem = dElem.nativeElement;
  });

  it('OperationsReportComponent should be created', () => {
    expect(dElem).not.toBe(null);
    expect(elem).toBeDefined();
  });

  it('All component objects are initialized', () => {
    expect(component.ngOnInit).toBeDefined();
  });

  it('Main filters are defined ', () => {
    expect(component.onMainFiltersValues).toBeDefined();
  });

  it('Error can be triggered when main filter encounter issue ', () => {
    expect(component.onMainFiltersError).toBeDefined();
  });

  it('Main filters created', () => {
    const constMainFilters = elem.querySelector('dbcp-main-filters');
    expect(constMainFilters).toBeDefined();
  });

  it('Overview list table created', () => {
    const contPTable = elem.querySelector('p-table');
    expect(contPTable).toBeDefined();
  });

  it('Overview list table should return total record number', () => {
    const element = dElem.query(By.css('container-fluid.p-table.totalRecords'));
    expect(element).toBeDefined();
  });

  it('Overview list table should return table columns number', () => {
    const element = dElem.query(By.css('container-fluid.p-table.columns'));
    expect(element).toBeDefined();
  });

  it('Overview list table should return table rows number', () => {
    const element = dElem.query(By.css('container-fluid.p-table.rows'));
    expect(element).toBeDefined();
  });

  it('Overview list reports should be valid after service call with mock filter values', () => {
    fixture.whenStable().then(() => {
      fixture.detectChanges();
    });
    expect(elem.textContent).toBeDefined(component.reports);
  });
});
