import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { SentenceCasePipe } from '@core/pipes/sentence-case.pipe';
import { Injectable } from '@angular/core';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { BreadCrumbService } from '@core/components/bread-crumb/bread-crumb.service';
import { UploadBatchComponent } from '@appRoot/features/create-batch/upload-batch/upload-batch.component.ts';
import { UploadBatchService } from '@appRoot/features/create-batch/upload-batch/upload-batch.service.ts';

@Component({
  templateUrl: './upload-batch.component.html'
})
@Injectable()
class MockComponent {}

class UploadBatchServiceStub {
  public uploadBatchDocument() {}
}

describe('Component: UploadBatchComponent', () => {
  let component: UploadBatchComponent;
  let service: UploadBatchService;
  let fixture: ComponentFixture<UploadBatchComponent>;

  let dElem: DebugElement;
  let elem: HTMLElement;
  let localizePipe: LocalizePipe;
  let sentenceCasePipe: SentenceCasePipe;
  let pipeSpy: jasmine.Spy;
  let sentencePipeSpy: jasmine.Spy;
  let serviceSpy: jasmine.Spy;

  beforeEach(() => {
    localizePipe = new LocalizePipe();
    sentenceCasePipe = new SentenceCasePipe();

    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        RouterTestingModule.withRoutes([
          {
            path: 'http://localhost:4200/#/create-batch/upload-batch',
            component: MockComponent
          }
        ])
      ],
      declarations: [
        UploadBatchComponent,
        MockComponent,
        LocalizePipe,
        SentenceCasePipe
      ],
      providers: [
        { provide: UploadBatchService, useClass: UploadBatchServiceStub },
        { provide: AppService },
        { provide: MainService },
        { provide: BreadCrumbService },
        { provide: DeviceDetectorService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    pipeSpy = spyOn(LocalizePipe.prototype, 'transform');

    sentencePipeSpy = spyOn(SentenceCasePipe.prototype, 'transform');

    // create component and test fixture
    fixture = TestBed.createComponent(UploadBatchComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    service = fixture.debugElement.injector.get(UploadBatchService);

    serviceSpy = spyOn(service, 'uploadBatchDocument').and.callFake(() => {
      return new Promise((resolve, reject) => {
        resolve();
      });
    });

    dElem = fixture.debugElement;
    elem = dElem.nativeElement;
  });

  it('UploadBatchComponent should be created', () => {
    expect(dElem).not.toBe(null);
    expect(elem).toBeDefined();
  });

  it('All component objects are initialized', () => {
    expect(component.ngOnInit).toBeDefined();
  });

  it('Sub filters are defined ', () => {
    expect(component.onSubFilterValues).toBeDefined();
  });

  it('Error can be triggered when sub filter encounter issue ', () => {
    expect(component.onSubFilterError).toBeDefined();
  });

  it('Sub filters created', () => {
    const contSubFilters = elem.querySelector('dbcp-sub-filter');
    expect(contSubFilters).toBeDefined();
  });

  it('Sub filter should display organization and location', () => {
    const element = dElem.query(By.css('container-fluid.dbcp-sub-filter'));
    expect(element).toBeDefined();
  });

  it('Batch upload service uploadBatchDocument called', () => {
    expect(service.uploadBatchDocument).toBeDefined();
  });
});
