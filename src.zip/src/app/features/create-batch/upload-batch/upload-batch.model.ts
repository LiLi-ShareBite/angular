export class UploadSucceedResponseModel {
  public batchName: string;
  public dateCreatedUtc: string;
  public pageCount: number;
}

export enum RESOLVED_OUTCOME {
  SUCCESS,
  FAILED,
  NA,
  IN_PROGRESS
}

export enum ERROR_TYPE {
  WRONG_INFORMATION = 1,
  IMAGE_ISSUE,
  DUPLICATE_BATCH,
  MISSING_INFORMATION
}
