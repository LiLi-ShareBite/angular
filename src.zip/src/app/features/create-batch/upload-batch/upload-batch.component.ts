import { Component, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { BreadCrumbService } from '@core/components/bread-crumb/bread-crumb.service';
import { ISubFilterModel } from '@appRoot/features/create-batch/upload-batch/sub-filter/sub-filter.model';
import { UploadBatchService } from '@appRoot/features/create-batch/upload-batch/upload-batch.service';
import { UploadSucceedResponseModel } from '@appRoot/features/create-batch/upload-batch/upload-batch.model';
import { isNullOrUndefined } from 'util';
import { DbcpErrorAlert } from '@core/components/alert/alert.model';

@Component({
  selector: '[dbcp-upload-batch]',
  templateUrl: './upload-batch.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./upload-batch.component.scss']
})
export class UploadBatchComponent {
  public maxCharCount: number = 256;
  public batchNotes: string = '';
  public charsLeft: number = this.maxCharCount;
  public siteId: string;
  public uploadedFiles: any[] = [];
  public file: File;
  public uploadSucceedResponse: UploadSucceedResponseModel;
  public errorAlert: DbcpErrorAlert = null;
  private breadCrumb;
  private showErrMsg: string = '';

  private uploadBatchFilter = {
    companyId: null,
    siteIds: []
  };

  constructor(
    private appService: AppService,
    private mainService: MainService,
    private router: Router,
    private route: ActivatedRoute,
    private uploadBatchService: UploadBatchService,
    private breadCrumbService: BreadCrumbService
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  // tslint:disable-next-line:use-lifecycle-interface
  public ngOnInit(filters: ISubFilterModel) {
    this.breadCrumb = [
      {
        label: LocalizePipe.Instance.transform('CREATE_BATCH_TITLE'),
        enabled: true,
        url: `/create-batch`
      },
      {
        label: LocalizePipe.Instance.transform('CREATE_BATCH_UPLOAD_TITLE'),
        enabled: false
      }
    ];
    setTimeout(() => {
      this.breadCrumbService.setBreadCrumb(this.breadCrumb);
    }, 0);

    this.getSubFilter(filters);
  }

  public onSubFilterValues(filters: ISubFilterModel) {
    this.getSubFilter(filters);
  }

  public onSubFilterError(msg: string) {
    // Display error message.
    this.mainService.errorAlertSubject$.next();
  }

  public changed() {
    this.charsLeft = this.maxCharCount - this.batchNotes.length;
  }

  public onUploadBatch(event, batchUpload) {
    this.errorAlert = null;
    // One file selection allowed in UI
    if (
      !isNullOrUndefined(this.uploadedFiles[0]) &&
      !isNullOrUndefined(this.uploadBatchFilter.siteIds)
    ) {
      this.siteId = this.uploadBatchFilter.siteIds[0];
      this.appService.spinner.show();
      if (this.batchNotes === '') {
        this.batchNotes = 'N/A';
      }
      this.uploadBatchService
        .uploadBatchDocument(
          this.siteId,
          this.batchNotes,
          this.uploadedFiles[0]
        )
        .subscribe(
          (resp: UploadSucceedResponseModel) => {
            this.uploadSucceedResponse = resp;
            this.appService.spinner.hide();
            this.router.navigate([
              'create-batch/upload-confirmation',
              this.uploadedFiles[0].name,
              this.uploadSucceedResponse.dateCreatedUtc
            ]);
          },
          (error) => {
            this.uploadedFiles = [];
            this.appService.spinner.hide();
            batchUpload.clear();
            if (error.status === 917) {
              this.assignErrMsg(
                parseInt(error.error.stringKey, 10),
                error.error.stringVariables[0]
              );
              this.errorAlert = new DbcpErrorAlert(this.showErrMsg, true);
            } else {
              this.errorAlert = new DbcpErrorAlert(
                LocalizePipe.Instance.transform('CREATE_BATCH_ERROR_OTHER'),
                true
              );
            }
          },
          () => {}
        );
    }
  }

  public myUploader(event) {
    this.errorAlert = null;
    for (const file of event.files) {
      this.uploadedFiles.push(file);
    }
  }

  private getSubFilter(filters?: ISubFilterModel) {
    if (filters) {
      this.uploadBatchFilter.companyId = filters.company
        ? filters.company.id
        : null;
      this.uploadBatchFilter.siteIds = filters.location
        ? [filters.location.id]
        : [];
    }
  }

  private assignErrMsg(stringKey: number, stringVariables: string) {
    switch (stringKey) {
      case 1000:
        this.showErrMsg = LocalizePipe.Instance.transform(
          'CREATE_BATCH_ERROR_0',
          stringVariables
        );
        break;
      case 1001:
        this.showErrMsg = LocalizePipe.Instance.transform(
          'CREATE_BATCH_ERROR_1'
        );
        break;
      case 1002:
        this.showErrMsg = LocalizePipe.Instance.transform(
          'CREATE_BATCH_ERROR_2',
          stringVariables
        );
        break;
      case 1003:
        this.showErrMsg = LocalizePipe.Instance.transform(
          'CREATE_BATCH_ERROR_3',
          stringVariables
        );
        break;
      case 1004:
        this.showErrMsg = LocalizePipe.Instance.transform(
          'CREATE_BATCH_ERROR_4',
          stringVariables
        );
        break;
    }
  }
}
