import { Injectable } from '@angular/core';
import { ApiService } from '@apiService';
import { HttpClient } from '@angular/common/http';
import { AppService } from '@appRoot/app.service';
import { Router } from '../../../../../node_modules/@angular/router';

const POST_UPLOAD_BATCH_API = 'api/dbcp/batch';

@Injectable()
export class UploadBatchService extends ApiService {
  constructor(
    private httpClient: HttpClient,
    private appService: AppService,
    private router: Router
  ) {
    super(httpClient);
  }

  public uploadBatchDocument(siteId: string, notes: string, fileToUpload: any) {
    const formData = new FormData();
    formData.append('siteId', siteId);
    formData.append('notes', notes);
    formData.append('file', fileToUpload);
    return this.post(POST_UPLOAD_BATCH_API, formData);
  }
}
