import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: '[dbcp-upload-batch-confirmation]',
  templateUrl: './upload-confirmation.component.html',
  styleUrls: ['./upload-confirmation.component.scss']
})
export class UploadConfirmationComponent implements OnInit {
  public fileName: string;
  public createDate: string;
  public formatDate: string;
  public formatTime: string;
  public batchCategoryId: string;
  public notesCategoryId: string;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private datePipe: DatePipe
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  public ngOnInit() {
    this.fileName = this.route.snapshot.paramMap.get('fileName');
    this.createDate = this.route.snapshot.paramMap.get('createDate').toString();
    this.formatDate = this.datePipe.transform(this.createDate, 'MMMM d, y');
    this.formatTime = this.datePipe.transform(this.createDate, 'h:mm a');
    this.batchCategoryId = '0'; // Return to batch list page with none specified ID "0"
    this.notesCategoryId = '0';
  }
}
