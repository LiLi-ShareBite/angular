import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {
  ISubFilterModel,
  LocationModel,
  CompanyModel,
  BATCH_CAPTURE_TYPE
} from '@appRoot/features/create-batch/upload-batch/sub-filter/sub-filter.model';
import * as moment from 'moment';
import { SubFilterService } from '@appRoot/features/create-batch/upload-batch/sub-filter/sub-filter.service';
import { ActivatedRoute } from '@angular/router';
import {
  UserAppModel,
  USER_ROLE
} from '@appRoot/features//user-management/user.model';
import { AppService } from '@appRoot/app.service';

@Component({
  selector: 'dbcp-sub-filter',
  templateUrl: './sub-filter.component.html',
  styleUrls: ['./sub-filter.component.scss']
})
export class SubFilterComponent implements OnInit {
  public companyOptions: CompanyModel[] = [];
  public locationOptions: LocationModel[] = [];
  public USER_ROLE: typeof USER_ROLE = USER_ROLE;

  public currentUser: UserAppModel;
  public selectedCompany: CompanyModel = null;
  public selectedLocation: LocationModel = null;
  public currentFeatureName: string;

  @Output()
  public onSubFilterValues = new EventEmitter<ISubFilterModel>();

  @Output()
  public onSubFilterError = new EventEmitter<string>();

  private feature: string = 'BatchUpload';

  constructor(
    private route: ActivatedRoute,
    private appService: AppService,
    private subFilterService: SubFilterService
  ) {
    this.currentFeatureName = this.route.snapshot.data.currentFeature;

    this.appService.currentUserSubject.subscribe(
      (user: UserAppModel) => {
        this.currentUser = user;
      },
      () => {
        this.currentUser = null;
      }
    );
  }

  public ngOnInit() {
    this.loadCompanyAndLocationFilter();
  }

  public onCompanyOptionChange() {
    this.locationOptions = [];
    this.selectedLocation = null;
    this.subFilterService.SelectedFiltersValue = null;

    this.getLocationFilters().then(
      () => {
        this.updateFilters();
      },
      (error) => {
        this.throwFiltersError(error);
      }
    );
  }

  public onLocationOptionChange() {
    this.updateFilters();
  }

  private loadCompanyAndLocationFilter() {
    this.companyOptions = [];
    this.locationOptions = [];
    this.selectedCompany = null;
    this.selectedLocation = null;

    this.getCompanyFilters().then(() => {
      this.getLocationFilters().then(() => {
        this.updateFilters();
      });
    });
  }

  private getCompanyFilters() {
    this.appService.spinner.show();
    return new Promise((resolve, reject) => {
      this.subFilterService.getCompanies(this.feature).then(
        (companies: CompanyModel[]) => {
          this.companyOptions = companies;
          if (
            this.subFilterService.SelectedFiltersValue &&
            this.subFilterService.SelectedFiltersValue.company
          ) {
            this.selectedCompany = this.subFilterService.SelectedFiltersValue.company;
            this.appService.spinner.hide();
            resolve();
          } else if (this.companyOptions && this.companyOptions.length) {
            this.selectedCompany = this.companyOptions[0];
            this.appService.spinner.hide();
            resolve();
          } else {
            // Display error message.
            this.appService.spinner.hide();
            this.throwFiltersError('Display error message.');
            reject();
          }
        },
        (error) => {
          // Display error message.
          this.appService.spinner.hide();
          this.throwFiltersError(error);
          reject();
        }
      );
    });
  }

  private getLocationFilters() {
    this.appService.spinner.show();
    return new Promise((resolve, reject) => {
      this.subFilterService
        .getSites(this.selectedCompany.id, this.feature)
        .then(
          (locations: LocationModel[]) => {
            this.locationOptions = locations;
            if (
              this.subFilterService.SelectedFiltersValue &&
              this.subFilterService.SelectedFiltersValue.location
            ) {
              this.selectedLocation = this.subFilterService.SelectedFiltersValue.location;
              this.appService.spinner.hide();
              resolve();
            } else if (this.locationOptions && this.locationOptions.length) {
              this.selectedLocation = this.locationOptions[0];
              this.appService.spinner.hide();
              resolve();
            } else {
              // Display error message.
              this.appService.spinner.hide();
              this.throwFiltersError('Display error message.');
              reject();
            }
          },
          (error) => {
            // Display error message.
            this.appService.spinner.hide();
            this.throwFiltersError(error);
            reject();
          }
        );
    });
  }

  private updateFilters() {
    this.subFilterService.SelectedFiltersValue = {
      company: this.selectedCompany,
      location: this.selectedLocation
    };

    this.onSubFilterValues.emit(this.subFilterService.SelectedFiltersValue);
  }

  private throwFiltersError(error) {
    if (typeof error === 'string') {
      this.onSubFilterError.emit(error);
    } else {
      this.onSubFilterError.emit(error.message);
    }
  }
}
