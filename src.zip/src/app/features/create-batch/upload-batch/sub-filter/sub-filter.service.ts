import { Injectable } from '@angular/core';
import { ApiService } from '@apiService';
import * as util from 'util';
import {
  ISubFilterModel,
  LocationModel,
  CompanyModel
} from '@appRoot/features/create-batch/upload-batch/sub-filter/sub-filter.model';
import { map } from 'rxjs/operators';

const POST_DISTRIBUTED_COMPANIES_API =
  'api/dbum/organization-management/companies';
const POST_DISTRIBUTED_SITES_API =
  'api/dbum/organization-management/companies/%s/sites';

@Injectable()
export class SubFilterService extends ApiService {
  private _selectedFilter: ISubFilterModel = null;

  public get SelectedFiltersValue(): ISubFilterModel {
    return this._selectedFilter;
  }

  public set SelectedFiltersValue(value: ISubFilterModel) {
    this._selectedFilter = value;
  }

  public resetMainFilters() {
    this.SelectedFiltersValue = {
      company: null,
      location: null
    };
  }

  public getCompanies(feature: string) {
    return new Promise((resolve, reject) => {
      this.post(POST_DISTRIBUTED_COMPANIES_API, { feature })
        .pipe(map((response) => response as CompanyModel[]))
        .subscribe(
          (companies: CompanyModel[]) => {
            resolve(companies);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  public getSites(companyId: number, feature: string) {
    return new Promise((resolve, reject) => {
      this.post(util.format(POST_DISTRIBUTED_SITES_API, companyId), { feature })
        .pipe(map((response) => response as LocationModel[]))
        .subscribe(
          (sites: LocationModel[]) => {
            resolve(sites);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
}
