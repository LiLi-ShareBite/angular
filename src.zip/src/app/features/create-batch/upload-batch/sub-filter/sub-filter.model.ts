export class CompanyModel {
  constructor(
    public id: number,
    public name: string,
    public description: string
  ) {}
}

export class LocationModel {
  constructor(
    public id: number,
    public name: string,
    public description: string,
    public batchCaptureType: BATCH_CAPTURE_TYPE
  ) {}
}

export interface ISelectedCompanyLocation {
  company: CompanyModel;
  location: LocationModel;
}

export interface ISubFilterModel {
  company: CompanyModel;
  location: LocationModel;
}

export enum BATCH_CAPTURE_TYPE {
  DISTRIBUTED = 1,
  OPERATIONAL = 2,
  BOTH = 3
}
