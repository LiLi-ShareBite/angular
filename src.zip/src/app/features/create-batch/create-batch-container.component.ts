import { Component } from '@angular/core';

@Component({
  templateUrl: './create-batch-container.component.html'
})
export class CreateBatchContainerComponent {}
