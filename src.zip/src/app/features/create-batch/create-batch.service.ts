import { Injectable } from '@angular/core';
import { ApiService } from '@apiService';

@Injectable()
export class CreateBatchService extends ApiService {}
