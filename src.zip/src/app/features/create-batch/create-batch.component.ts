import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CreateBatchService } from '@appRoot/features/create-batch/create-batch.service';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { IMainFiltersModel } from '@core/components/main-filters/main-filters.model';
import { MainFiltersComponent } from '@core/components/main-filters/main-filters.component';
import { Table } from 'primeng/components/table/table';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { LocalizePipe } from '@core/pipes/localize.pipe';

@Component({
  selector: '[dbcp-create-batch]',
  templateUrl: './create-batch.component.html',
  styleUrls: ['./create-batch.component.scss']
})
export class CreateBatchComponent implements OnInit {
  @ViewChild('MainFiltersComponent', { static: false })
  public reportsListDt: MainFiltersComponent;

  constructor(
    private modalsService: ModalsService,
    private mainService: MainService,
    private appService: AppService,
    private uploadBatchService: CreateBatchService,
    private router: Router
  ) {}

  public ngOnInit() {}

  public onMainFiltersError(msg: string) {
    // Display error message.
    this.mainService.errorAlertSubject$.next();
  }

  public onMainFiltersValues(filters: IMainFiltersModel) {}

  public onChooseFilePage() {
    this.router.navigate(['/create-batch/upload-batch']);
  }
}
