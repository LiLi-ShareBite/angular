import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateBatchModule } from './create-batch.module';

describe('CreateBatchModule', () => {
  let createBatchModule: CreateBatchModule;

  beforeEach(() => {
    createBatchModule = new CreateBatchModule();
  });

  it('should create an instance', () => {
    expect(createBatchModule).toBeTruthy();
  });
});
