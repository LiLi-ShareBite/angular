import { Routes } from '@angular/router';
import { RoleGuard } from '@core/guards/role.guard';
import { USER_ROLE } from '@appRoot/features/user-management/user.model';
import { CreateBatchComponent } from '@appRoot/features/create-batch/create-batch.component';
import { CreateBatchContainerComponent } from '@appRoot/features/create-batch/create-batch-container.component';
import { UploadBatchComponent } from './upload-batch/upload-batch.component';
import { UploadConfirmationComponent } from '@appRoot/features/create-batch/upload-batch/upload-confirmation/upload-confirmation.component';

export const CREATE_BATCH_ROUTES: Routes = [
  {
    path: '',
    component: CreateBatchContainerComponent,
    children: [
      {
        path: '',
        component: CreateBatchComponent
      },
      {
        path: 'upload-batch',
        component: UploadBatchComponent,
        data: {
          currentFeature: 'Upload_Batch'
        }
      },
      {
        path: 'upload-confirmation/:fileName/:createDate',
        component: UploadConfirmationComponent
      }
    ]
  },
  {
    path: '',
    redirectTo: '/overview',
    pathMatch: 'full'
  }
];
