import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CreateBatchComponent } from '@appRoot/features/create-batch/create-batch.component';
import { CreateBatchContainerComponent } from '@appRoot/features/create-batch/create-batch-container.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CREATE_BATCH_ROUTES } from '@appRoot/features/create-batch/create-batch.routes';
import { CreateBatchService } from '@appRoot/features/create-batch/create-batch.service';
import { TableModule } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';
import { ModalsModule } from '@appRoot/-modals';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { DropdownModule } from 'primeng/dropdown';
import { RoleGuard } from '@core/guards/role.guard';
import { UploadBatchComponent } from '@appRoot/features/create-batch/upload-batch/upload-batch.component';
import { UploadBatchService } from '@appRoot/features/create-batch/upload-batch/upload-batch.service';
import { FileUploadModule } from 'primeng/fileupload';
import { SubFilterComponent } from '@appRoot/features/create-batch/upload-batch/sub-filter/sub-filter.component';
import { SubFilterService } from '@appRoot/features/create-batch/upload-batch/sub-filter/sub-filter.service';
import { UploadConfirmationComponent } from '@appRoot/features/create-batch/upload-batch/upload-confirmation/upload-confirmation.component';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [
    CreateBatchComponent,
    UploadBatchComponent,
    CreateBatchContainerComponent,
    SubFilterComponent,
    UploadConfirmationComponent
  ],
  exports: [CreateBatchComponent],
  imports: [
    CommonModule,
    FormsModule,
    DropdownModule,
    ModalsModule,
    TableModule,
    TooltipModule,
    FileUploadModule,
    BaseControlModule,
    RouterModule.forChild(CREATE_BATCH_ROUTES)
  ],
  providers: [
    CreateBatchService,
    RoleGuard,
    UploadBatchService,
    SubFilterService,
    DatePipe
  ],
  entryComponents: [],
  bootstrap: [CreateBatchComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class CreateBatchModule {}
