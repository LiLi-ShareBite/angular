import { Routes } from '@angular/router';
import { MainComponent } from '@appRoot/features/main.component';
import { OverviewComponent } from '@appRoot/features/overview/overview.component';
import { RoleGuard } from '@core/guards/role.guard';
import { USER_ROLE } from '@appRoot/features/user-management/user.model';

export const MAIN_ROUTES: Routes = [
  {
    path: '',
    component: MainComponent,
    children: [
      {
        path: 'overview',
        component: OverviewComponent,
        canActivate: [RoleGuard],
        data: {
          expectedRole: [
            USER_ROLE.SYSTEM_ADMIN,
            USER_ROLE.ADMIN,
            USER_ROLE.USER
          ]
        }
      },
      {
        path: 'create-batch',
        loadChildren: () =>
          import('./create-batch').then((m) => m.CreateBatchModule),
        canActivate: [RoleGuard],
        data: {
          expectedRole: [USER_ROLE.SYSTEM_ADMIN, USER_ROLE.ADMIN]
        }
      },
      {
        path: 'batch-list',
        loadChildren: () =>
          import('./batch-list').then((m) => m.BatchListModule),
        canActivate: [RoleGuard],
        data: {
          expectedRole: [
            USER_ROLE.SYSTEM_ADMIN,
            USER_ROLE.ADMIN,
            USER_ROLE.USER
          ]
        }
      },
      {
        path: 'batch-summary',
        loadChildren: () =>
          import('./batch-summary').then((m) => m.BatchSummaryModule),
        canActivate: [RoleGuard],
        data: {
          expectedRole: [
            USER_ROLE.SYSTEM_ADMIN,
            USER_ROLE.ADMIN,
            USER_ROLE.USER
          ]
        }
      },
      {
        path: 'operations-report',
        loadChildren: () =>
          import('./operations-report').then((m) => m.OperationsReportModule),
        canActivate: [RoleGuard],
        data: {
          expectedRole: [USER_ROLE.SYSTEM_ADMIN, USER_ROLE.ADMIN]
        }
      },
      {
        path: '',
        redirectTo: 'overview'
      }
    ]
  }
];
