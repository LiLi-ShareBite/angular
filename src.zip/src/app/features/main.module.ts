import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { MainComponent } from '@appRoot/features/main.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MAIN_ROUTES } from '@appRoot/features/main.routes';
import { OverviewComponent } from '@appRoot/features/overview/overview.component';
import { GraphsComponent } from '@appRoot/features/overview/graphs/graphs.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MainService } from '@appRoot/features/main.service';
import { FormsModule } from '@angular/forms';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { BreadCrumbService } from '@core/components/bread-crumb/bread-crumb.service';
import { OverviewService } from '@appRoot/features/overview/overview.service';
import { GraphsService } from '@appRoot/features/overview/graphs/graphs.service';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { RoleGuard } from '@core/guards/role.guard';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { ButtonModule } from 'primeng/button';
import { ChartModule } from 'primeng/chart';

@NgModule({
  declarations: [MainComponent, OverviewComponent, GraphsComponent],
  exports: [MainComponent, OverviewComponent, GraphsComponent],
  imports: [
    CommonModule,
    OverlayPanelModule,
    NgxSpinnerModule,
    FormsModule,
    ButtonModule,
    BaseControlModule,
    NgbModalModule,
    RouterModule.forChild(MAIN_ROUTES),
    ChartModule
  ],
  entryComponents: [],
  providers: [
    MainService,
    BreadCrumbService,
    OverviewService,
    GraphsService,
    RoleGuard,
    ModalsService
  ],
  bootstrap: [MainComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class MainModule {}
