import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import {
  BATCH_CATEGORY,
  NOTES_CATEGORY
} from '@appRoot/features/batch-list/batch.model';
import {
  UserAppModel,
  USER_ROLE
} from '@appRoot/features/user-management/user.model';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { AppIdleService } from '@appRoot/app-idle.service';
import {
  DbcpErrorAlert,
  DbcpSuccessAlert
} from '@core/components/alert/alert.model';
import { isNull } from 'util';
import { LocalizePipe } from '@core/pipes/localize.pipe';

@Component({
  selector: '[dbcp-main]',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent {
  public selectedBatchCat: number = BATCH_CATEGORY.NONE;
  public selectedNotesCat: number = NOTES_CATEGORY.ALL;
  public isBatchListActiveUrl: boolean = false;
  public currentUser: UserAppModel;
  public USER_ROLE: typeof USER_ROLE = USER_ROLE;
  public title: string;
  public routerUrl: string;

  public errorAlert: DbcpErrorAlert = null;
  public successAlert: DbcpSuccessAlert = null;

  constructor(
    private appService: AppService,
    private appIdleService: AppIdleService,
    private mainService: MainService,
    private router: Router
  ) {
    this.appIdleService.watch();
    this.routerUrl = router.url;

    this.mainService.errorAlertSubject$.subscribe((errorMsg: string) => {
      if (isNull(errorMsg)) {
        this.errorAlert = null;
      } else {
        errorMsg = errorMsg || LocalizePipe.Instance.transform('SERVER_ERROR');
        this.errorAlert = new DbcpErrorAlert(errorMsg, true);
      }
      this.appService.spinner.hide();
    });

    this.mainService.successAlertSubject$.subscribe((successMsg: string) => {
      if (isNull(successMsg)) {
        this.successAlert = null;
      } else {
        successMsg = successMsg || 'Success';
        this.successAlert = new DbcpSuccessAlert(successMsg, true);
      }
      this.appService.spinner.hide();
    });

    this.appService.currentUserSubject.subscribe(
      (user: UserAppModel) => {
        this.currentUser = user;
      },
      () => {
        this.currentUser = null;
      }
    );

    this.mainService.currentBatchCategorySubject$.subscribe(
      (category: number) => {
        setTimeout(() => {
          this.selectedBatchCat = category;
        }, 0);
      }
    );

    this.router.events.subscribe((navigationEnd: NavigationEnd) => {
      if (navigationEnd instanceof NavigationEnd) {
        const routerUrl = this.router.url;
        this.errorAlert = null;
        if (routerUrl && routerUrl.indexOf('batch-list') !== -1) {
          this.isBatchListActiveUrl = true;
        } else {
          this.isBatchListActiveUrl = false;
        }
      }
    });
  }
}
