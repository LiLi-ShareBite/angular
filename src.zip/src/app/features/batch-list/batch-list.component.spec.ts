import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component, DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { BatchListComponent } from './batch-list.component';
import { BatchService } from './batch-list.service';
import { By } from '@angular/platform-browser';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { SentenceCasePipe } from '@core/pipes/sentence-case.pipe';
import { Injectable } from '@angular/core';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';

@Component({
  templateUrl: './batch-list.component.html'
})
@Component({
  templateUrl: ''
})
@Injectable()
class MockComponent {}

class BatchServiceStub {
  public getBatches(IBatchListRequestModel) {}

  public getStatusFilters(IStatusFiltersRequestModel) {}
}

const batchListRequest = {
  companyId: 10004,
  siteIds: [10006],
  statusFilter: 0,
  dateCreatedFilter: {
    utcStartDate: '2019-04-10T23:20:50.071Z',
    utcEndDate: '2019-04-10T23:20:50.071Z'
  },
  offset: 0,
  pageSize: 10,
  batchCaptureType: 1,
  batchId: null,
  scannerId: null,
  userId: null,
  notesFilter: null,
  sortColumns: null
};

const statusFiltersRequest = {
  companyId: 10004,
  siteIds: [10006],
  statusFilter: 0,
  dateCreatedFilter: {
    utcStartDate: '2019-04-10T23:20:50.071Z',
    utcEndDate: '2019-04-10T23:20:50.071Z'
  }
};

const paginatedResponse = {
  totalBatchCount: 0,
  batches: []
};

const batchListSettingsResponse = {
  batchCaptureType: 1,
  statusFilters: []
};

describe('Component: BatchListComponent', () => {
  let component: BatchListComponent;
  let service: BatchService;
  let fixture: ComponentFixture<BatchListComponent>;

  let dElem: DebugElement;
  let elem: HTMLElement;
  let localizePipe: LocalizePipe;
  let sentenceCasePipe: SentenceCasePipe;
  let pipeSpy: jasmine.Spy;
  let sentencePipeSpy: jasmine.Spy;
  let serviceSpy: jasmine.Spy;

  beforeEach(() => {
    localizePipe = new LocalizePipe();
    sentenceCasePipe = new SentenceCasePipe();

    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        RouterTestingModule.withRoutes([
          // { path: 'http://localhost:4200/exception', component: MockComponent }
        ])
      ],
      declarations: [
        BatchListComponent,
        MockComponent,
        LocalizePipe,
        SentenceCasePipe
      ],
      providers: [
        { provide: BatchService, useClass: BatchServiceStub },
        { provide: AppService },
        { provide: MainService },
        { provide: DeviceDetectorService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    pipeSpy = spyOn(LocalizePipe.prototype, 'transform');

    sentencePipeSpy = spyOn(SentenceCasePipe.prototype, 'transform');

    // create component and test fixture
    fixture = TestBed.createComponent(BatchListComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    service = fixture.debugElement.injector.get(BatchService);

    serviceSpy = spyOn(service, 'getBatches').and.callFake(() => {
      return new Promise((resolve, reject) => {
        resolve(paginatedResponse);
      });
    });

    serviceSpy = spyOn(service, 'getStatusFilters').and.callFake(() => {
      return new Promise((resolve) => {
        resolve(batchListSettingsResponse);
      });
    });

    dElem = fixture.debugElement;
    elem = dElem.nativeElement;
  });

  it('BatchListComponent should be created', () => {
    expect(dElem).not.toBe(null);
    expect(elem).toBeDefined();
  });

  it('All component objects are initialized', () => {
    expect(component.ngOnInit).toBeDefined();
  });

  it('Main filters are defined ', () => {
    expect(component.onMainFiltersValues).toBeDefined();
  });

  it('Error can be triggered when main filter encounter issue ', () => {
    expect(component.onMainFiltersError).toBeDefined();
  });

  it('Main filters created', () => {
    const contMainFilters = elem.querySelector('dbcp-main-filters');
    expect(contMainFilters).toBeDefined();
  });

  it('Batch list table created', () => {
    const contPTable = elem.querySelector('p-table');
    expect(contPTable).toBeDefined();
  });

  it('Batch list table should return total record number', () => {
    const element = dElem.query(By.css('container-fluid.p-table.totalRecords'));
    expect(element).toBeDefined();
  });

  it('Batch list table should return table columns number', () => {
    const element = dElem.query(By.css('container-fluid.p-table.columns'));
    expect(element).toBeDefined();
  });

  it('Batch list table should return table rows number', () => {
    const element = dElem.query(By.css('container-fluid.p-table.rows'));
    expect(element).toBeDefined();
  });

  it('Batch list record should return 0 after service call with mock filter values', () => {
    expect(paginatedResponse.totalBatchCount).toEqual(0);
  });

  it('Batch list array should be empty after service call with mock filter values', () => {
    expect(paginatedResponse.batches).toEqual([]);
  });

  it('Batch capture type of batch list settings should be 1 after service call with mock filter values', () => {
    expect(batchListSettingsResponse.batchCaptureType).toEqual(1);
  });
});
