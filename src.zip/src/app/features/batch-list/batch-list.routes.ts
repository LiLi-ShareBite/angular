import { Routes } from '@angular/router';
import { BatchListComponent } from '@appRoot/features/batch-list/batch-list.component';
import { RouterWrapperComponent } from '@core/components/router-wrapper/router-wrapper.component';

export const BATCH_LIST_ROUTES: Routes = [
  {
    path: ':bcId/:notesId',
    component: RouterWrapperComponent,
    children: [
      {
        path: '',
        component: BatchListComponent,
        data: {
          currentFeature: 'Batch_List'
        }
      }
    ]
  },
  {
    path: '',
    redirectTo: '/overview',
    pathMatch: 'full'
  }
];
