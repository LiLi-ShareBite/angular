import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BatchListComponent } from '@appRoot/features/batch-list/batch-list.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BATCH_LIST_ROUTES } from '@appRoot/features/batch-list/batch-list.routes';
import { BatchService } from '@appRoot/features/batch-list/batch-list.service';
import { TableModule } from 'primeng/table';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { DropdownModule } from 'primeng/dropdown';
import { TooltipModule } from 'primeng/tooltip';
import { DeviceDetectorModule } from 'ngx-device-detector';

@NgModule({
  declarations: [BatchListComponent],
  exports: [BatchListComponent],
  imports: [
    CommonModule,
    FormsModule,
    TableModule,
    DropdownModule,
    TooltipModule,
    BaseControlModule,
    RouterModule.forChild(BATCH_LIST_ROUTES),
    DeviceDetectorModule.forRoot()
  ],
  providers: [BatchService],
  entryComponents: [],
  bootstrap: [BatchListComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class BatchListModule {}
