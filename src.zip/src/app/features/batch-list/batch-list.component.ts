import { Component, OnInit, ViewChild } from '@angular/core';
import { BatchService } from '@appRoot/features/batch-list/batch-list.service';
import {
  BatchModel,
  IBatchListRequestModel,
  BATCH_CATEGORY,
  BatchListSettingsResponse,
  StatusPairing,
  IStatusFiltersRequestModel,
  CUSTOMER_CAPTURE_TYPE,
  IPaginatedResponseModel,
  ColumnFilterOptions,
  TableSortColumns,
  NOTES_CATEGORY,
  BATCH_SORT_COLUMN_CATEGORY
} from '@appRoot/features/batch-list/batch.model';
import { Router, ActivatedRoute } from '@angular/router';
import { IMainFiltersModel } from '@core/components/main-filters/main-filters.model';
import { Table } from 'primeng/components/table/table';
import { LazyLoadEvent } from 'primeng/components/common/lazyloadevent';
import { AppService } from '@appRoot/app.service';
import { MainService } from '@appRoot/features/main.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { IDynamicPaginationOption } from '@core/components/dynamic-pagination/dynamic-pagination.model';

@Component({
  selector: '[dbcp-batch-list]',
  templateUrl: './batch-list.component.html',
  styleUrls: ['./batch-list.component.scss']
})
export class BatchListComponent implements OnInit {
  public batches: BatchModel[];
  public batchesTbCols: any[];
  public selectedBatches: BatchModel[];
  public statusFilterOptions: ColumnFilterOptions[] = [];
  public selectedStatusFilter: ColumnFilterOptions = null;
  public allStatusesUnprocessed: StatusPairing[];
  public captureTypeInteger: number;
  public totalBatchCount: number;
  public first: number = 1;
  public visibleBatchTable: boolean = true;
  public rowCount: number = 10;
  public activePageSizeOptions: number = 10;
  public msgSearchResult: string = '';
  public pageSizeModel: IDynamicPaginationOption[];

  @ViewChild('batchListDt', { static: false })
  public batchListDt: Table;

  private batchCd: string;

  private batchListRequestFilter: IBatchListRequestModel = {
    companyId: null,
    siteIds: [],
    statusFilter: BATCH_CATEGORY.NONE,
    dateCreatedFilter: null,
    offset: null,
    pageSize: null,
    batchCaptureType: null,
    batchId: null,
    notesFilter: NOTES_CATEGORY.ALL,
    scannerId: null,
    userId: null,
    sortColumns: null,
    accountNumber: null
  };

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private appService: AppService,
    private mainService: MainService,
    private deviceDetectorService: DeviceDetectorService,
    private batchService: BatchService // private exceptionService: ExceptionService
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.batches = [];
    this.selectedBatches = [];
  }

  public ngOnInit() {
    this.batchCd = this.route.snapshot.paramMap.get('bcId');

    this.mainService.currentBatchCategorySubject$.next(+this.batchCd);

    this.batchesTbCols = [];

    this.statusFilterOptions = [
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_NONE'),
        null,
        BATCH_CATEGORY.NONE
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_UPLOADED'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_UPLOADED'),
        BATCH_CATEGORY.DELIVERED
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESS'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESS'),
        BATCH_CATEGORY.WITHEXCEPTIONS
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSSCAN'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSSCAN'),
        BATCH_CATEGORY.INPROCESS
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSPREP'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSPREP'),
        BATCH_CATEGORY.INPROCESSSCAN
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSSECTION'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSSECTION'),
        BATCH_CATEGORY.INPROCESSPREP
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSINDEX'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSINDEX'),
        BATCH_CATEGORY.INPROCESSSECTION
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSQC'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_INPROCESSQC'),
        BATCH_CATEGORY.INPROCESSINDEX
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_DELIVERED'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_DELIVERED'),
        BATCH_CATEGORY.INPROCESSQC
      ),
      new ColumnFilterOptions(
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_WITHEXCEPTIONS'),
        LocalizePipe.Instance.transform('BATCH_LIST_STATUS_WITHEXCEPTIONS'),
        BATCH_CATEGORY.UPLOADED
      )
    ];

    if (this.batchListDt) {
      this.setCustomBatchStatusFilterConstraint();
    }
  }

  public onMainFiltersValues(filters: IMainFiltersModel) {
    this.updateVisibility();
    this.adjustPageSize(10);
    this.getCustomerTypeInfo(filters).then(() => {
      this.adjustBatchTableColumnsAndStatuses().then(() => {
        this.selectedStatusFilter = this.statusFilterOptions.find((el) => {
          return +el.batchCd === +this.batchCd;
        });
        if (!this.selectedStatusFilter) {
          this.router.navigate(['/batch-list', 0, NOTES_CATEGORY.ALL]);
          return;
        }

        this.getBatchList(filters);
        this.updateVisibility();
      });
    });
  }

  public onMainFiltersError(msg: string) {
    // Display error message.
    this.batches = [];
    this.selectedBatches = [];
    this.mainService.errorAlertSubject$.next();
  }

  public onBatchStatusFilterChange() {
    this.mainService.currentBatchCategorySubject$.next(
      this.selectedStatusFilter.batchCd
    );

    this.router.navigate([
      '/batch-list',
      this.selectedStatusFilter.batchCd,
      NOTES_CATEGORY.ALL
    ]);
  }

  public clearScannerID(): void {
    this.batchListRequestFilter.scannerId = '';
  }

  public clearUserID(): void {
    this.batchListRequestFilter.userId = '';
  }

  public onDyPaginationValue(pageSizeModel: IDynamicPaginationOption) {
    this.adjustPageSize(pageSizeModel.pageSize);
  }

  // This function grabs the batches on initial load and instantiates the batchListRequestFilters for subsequent calls to get more batches
  private getBatchList(filters?: IMainFiltersModel) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      this.batches = [];
      this.selectedBatches = [];

      if (filters) {
        this.batchListRequestFilter.companyId = filters.company
          ? filters.company.id
          : null;
        this.batchListRequestFilter.siteIds = filters.locations.length
          ? filters.locations.map((item) => item.id)
          : [];

        if (filters.timeFrame) {
          this.batchListRequestFilter.dateCreatedFilter = {
            utcStartDate: filters.timeFrame.startDt,
            utcEndDate: filters.timeFrame.endDt
          };
        } else {
          this.batchListRequestFilter.dateCreatedFilter = null;
        }
        this.batchListRequestFilter.accountNumber = filters.accountNumber;
      }

      this.batchListRequestFilter.statusFilter = this.selectedStatusFilter
        ? this.selectedStatusFilter.batchCd
        : 0;
      this.batchListRequestFilter.offset = 0;
      this.batchListRequestFilter.pageSize = 10;
      this.batchListRequestFilter.batchCaptureType = this.captureTypeInteger;
      this.batchListRequestFilter.scannerId = null;
      this.batchListRequestFilter.userId = null;
      this.batchListRequestFilter.notesFilter = NOTES_CATEGORY.ALL;
      this.batchListRequestFilter.sortColumns = null;

      this.batchService
        .getBatches(this.batchListRequestFilter)
        .then((response: IPaginatedResponseModel) => {
          this.batches = response.batches;
          this.totalBatchCount = response.totalBatchCount;
          this.appService.spinner.hide();
          if (this.batchListRequestFilter.accountNumber) {
            this.msgSearchResult = LocalizePipe.Instance.transform(
              'BATCH_LIST_ACCOUNT_NUMBER_SEARCH_RESULTS',
              `${this.totalBatchCount}`,
              `${this.batchListRequestFilter.accountNumber}`
            );
          } else {
            this.msgSearchResult = '';
          }
          resolve();
        })
        .catch((e) => {
          this.appService.spinner.hide();
          console.log('There was an error');
          console.log(e);
        });
    });
  }

  private loadMoreBatches(event: LazyLoadEvent) {
    if (this.batchListRequestFilter.companyId === null || event.first === 1) {
      return;
    }
    this.getBatchesCustomWindow(event.first, event.rows, event);
  }

  private adjustPageSize(pageSize: number) {
    if (pageSize === this.activePageSizeOptions) {
      return;
    }
    if (pageSize === 0) {
      this.rowCount = this.totalBatchCount;
    } else {
      this.rowCount = pageSize;
    }
    this.activePageSizeOptions = pageSize;
    this.getBatchesCustomWindow(0, pageSize);
  }

  /* This function is necessary when adjusting the pageSize because the table will otherwise retain
     the previously set pageSize */
  private updateVisibility(): void {
    this.visibleBatchTable = false;
    // Fixing for B012-1505, add in 0.1 second for table header display in full size within IE
    if (
      this.deviceDetectorService.browser.toLowerCase().trim() === 'ie' &&
      this.deviceDetectorService.browser_version.toLowerCase().trim() === '11.0'
    ) {
      setTimeout(() => (this.visibleBatchTable = true), 100);
    } else {
      setTimeout(() => (this.visibleBatchTable = true), 0);
    }
  }

  private getEventSortOrderBoolean(eventValue: number) {
    // Sort order as number, 1 for asc and -1 for dec
    if (eventValue === 1) {
      return true;
    } else {
      return false;
    }
  }

  private getBatchesCustomWindow(
    offset: number,
    pageSize: number,
    event?: LazyLoadEvent
  ) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      this.batches = [];
      this.selectedBatches = [];

      this.batchListRequestFilter.offset = offset;
      this.batchListRequestFilter.pageSize = pageSize;
      this.batchListRequestFilter.batchCaptureType = this.captureTypeInteger;
      if (event) {
        this.batchListRequestFilter.batchId =
          'batchId' in event.filters ? event.filters.batchId.value : null;
        this.batchListRequestFilter.scannerId =
          'scannerId' in event.filters ? event.filters.scannerId.value : null;
        this.batchListRequestFilter.userId =
          'userId' in event.filters ? event.filters.userId.value : null;
        this.batchListRequestFilter.sortColumns = event.sortField
          ? [
              {
                batchSortColumn: this.batchesTbCols.find(
                  (obj: any) => obj.field === event.sortField
                ).columnID,
                isAscending: this.getEventSortOrderBoolean(event.sortOrder)
              }
            ]
          : null;
      }
      this.batchService
        .getBatches(this.batchListRequestFilter)
        .then((response: IPaginatedResponseModel) => {
          this.batches = response.batches;
          this.totalBatchCount = response.totalBatchCount;
          this.appService.spinner.hide();
          resolve();
        })
        .catch((e) => {
          this.appService.spinner.hide();
          console.log('There was an error');
          console.log(e);
        });
    });
  }

  private getCustomerTypeInfo(filters?: IMainFiltersModel) {
    return new Promise((resolve, reject) => {
      this.appService.spinner.show();
      if (filters) {
        let timeFrame;
        if (filters.timeFrame) {
          timeFrame = {
            utcStartDate: filters.timeFrame.startDt,
            utcEndDate: filters.timeFrame.endDt
          };
        } else {
          timeFrame = null;
        }
        const statusFiltersRequest: IStatusFiltersRequestModel = {
          companyId: filters.company ? filters.company.id : null,
          siteIds: filters.locations
            ? filters.locations.map((item) => item.id)
            : [],
          dateCreatedFilter: timeFrame,
          accountNumber: filters.accountNumber
        };
        this.batchService
          .getStatusFilters(statusFiltersRequest)
          .then(
            (captureTypeAndStatuses: BatchListSettingsResponse) => {
              this.allStatusesUnprocessed =
                captureTypeAndStatuses.statusFilters;
              this.captureTypeInteger = captureTypeAndStatuses.batchCaptureType;
              this.appService.spinner.hide();
              resolve();
            },
            (error) => {
              // TODO: Add some error handling here
              reject();
            }
          )
          .catch((e) => {
            console.log(e);
          });
      }
    });
  }

  private createStatusFilterOptions() {
    this.statusFilterOptions = [];
    for (const el in this.allStatusesUnprocessed) {
      if (this.allStatusesUnprocessed.hasOwnProperty(el)) {
        if (this.allStatusesUnprocessed[el].id === BATCH_CATEGORY.NONE) {
          this.statusFilterOptions.push(
            new ColumnFilterOptions(
              LocalizePipe.Instance.transform(
                `BATCH_LIST_STATUS_${
                  BATCH_CATEGORY[this.allStatusesUnprocessed[el].id]
                }`
              ),
              null,
              this.allStatusesUnprocessed[el].id
            )
          );
        } else {
          this.statusFilterOptions.push(
            new ColumnFilterOptions(
              LocalizePipe.Instance.transform(
                `BATCH_LIST_STATUS_${
                  BATCH_CATEGORY[this.allStatusesUnprocessed[el].id]
                }`
              ),
              LocalizePipe.Instance.transform(
                `BATCH_LIST_STATUS_${
                  BATCH_CATEGORY[this.allStatusesUnprocessed[el].id]
                }`
              ),
              this.allStatusesUnprocessed[el].id
            )
          );
        }
      }
    }
  }

  private adjustBatchTableColumnsAndStatuses() {
    this.createStatusFilterOptions();
    return new Promise((resolve, reject) => {
      let tbColsArr;
      tbColsArr = [
        new TableSortColumns(
          'batchName',
          LocalizePipe.Instance.transform('BATCH_LIST_BATCH_NAME'),
          BATCH_SORT_COLUMN_CATEGORY.BATCHNAME
        ),
        new TableSortColumns(
          'status',
          LocalizePipe.Instance.transform('BATCH_LIST_STATUS'),
          BATCH_SORT_COLUMN_CATEGORY.STATUS
        ),
        new TableSortColumns(
          'pageCount',
          LocalizePipe.Instance.transform('BATCH_LIST_PAGE_COUNT'),
          BATCH_SORT_COLUMN_CATEGORY.PAGECOUNT
        ),
        new TableSortColumns(
          'dateCreated',
          LocalizePipe.Instance.transform(
            'BATCH_LIST_DATE_CREATED_EASTERN_TIME'
          ),
          BATCH_SORT_COLUMN_CATEGORY.DATECREATED
        ),
        new TableSortColumns(
          'dateDelivered',
          LocalizePipe.Instance.transform(
            'BATCH_LIST_DATE_DELIVERED_EASTERN_TIME'
          ),
          BATCH_SORT_COLUMN_CATEGORY.DATEDELIVERED
        )
      ];
      if (this.captureTypeInteger !== CUSTOMER_CAPTURE_TYPE.OPERATIONAL) {
        tbColsArr.splice(
          3,
          0,
          new TableSortColumns(
            'scannerId',
            LocalizePipe.Instance.transform('BATCH_LIST_SCANNER_ID'),
            BATCH_SORT_COLUMN_CATEGORY.SCANNERID
          )
        );
        tbColsArr.splice(
          4,
          0,
          new TableSortColumns(
            'userId',
            LocalizePipe.Instance.transform('BATCH_LIST_USER_ID'),
            BATCH_SORT_COLUMN_CATEGORY.USERID
          )
        );
      }
      this.batchesTbCols = tbColsArr;
      resolve();
    });
  }

  private setCustomBatchStatusFilterConstraint() {
    const filterConstraints: any = this.batchListDt.filterConstraints;
    filterConstraints.statusFilter = (value, filter: any): boolean => {
      if (filter === undefined || filter === null || filter === '') {
        return true;
      }

      if (value === undefined || value === null || !value.length) {
        return false;
      }

      const splitValArr = value.split('-');

      const rowStatusValue: string = splitValArr[0];
      const rowExceptionId: string = splitValArr[1];

      if (
        filter === this.statusFilterOptions[4].value &&
        +rowExceptionId === 0
      ) {
        return true;
      } else if (
        rowStatusValue
          .trim()
          .toLowerCase()
          .indexOf(filter.trim().toLowerCase()) !== -1
      ) {
        let result = true;
        switch (filter) {
          case this.statusFilterOptions[1].value:
            if (+rowExceptionId === 0) {
              result = true;
            } else {
              result = false;
            }
            break;
          case this.statusFilterOptions[2].value:
            if (+rowExceptionId !== 0) {
              result = true;
            } else {
              result = false;
            }
            break;
          default:
            result = true;
        }
        return result;
      }
      return false;
    };
  }
}
