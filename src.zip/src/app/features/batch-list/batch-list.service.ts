import { ApiService } from '@apiService';
import {
  BatchModel,
  IBatchListRequestModel,
  BatchListSettingsResponse,
  IStatusFiltersRequestModel,
  IPaginatedResponseModel
} from '@appRoot/features/batch-list/batch.model';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';

const GET_BATCH_LIST_API = 'api/dbcp/batches';
const GET_STATUS_FILTERS_API = 'api/dbcp/batch-list-settings';

@Injectable()
export class BatchService extends ApiService {
  public getBatches(filters: IBatchListRequestModel) {
    return new Promise((resolve, reject) => {
      this.post(GET_BATCH_LIST_API, filters)
        .pipe(
          map((response: IPaginatedResponseModel) => {
            return BatchModel.parseObjToModel(response);
          })
        )
        .subscribe(
          (batchArrObj: IPaginatedResponseModel) => {
            resolve(batchArrObj);
          },
          () => {
            reject();
          },
          () => {}
        );
    });
  }

  public getStatusFilters(filters: IStatusFiltersRequestModel) {
    return new Promise((resolve, reject) => {
      this.post(GET_STATUS_FILTERS_API, filters)
        .pipe(map((response) => response as BatchListSettingsResponse))
        .subscribe(
          (reply: BatchListSettingsResponse) => {
            resolve(reply);
          },
          (err) => {
            reject();
          },
          () => {}
        );
    });
  }
}
