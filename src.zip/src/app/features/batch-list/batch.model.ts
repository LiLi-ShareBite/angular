import * as moment from 'moment';

export class BatchModel {
  public static parseObjToModel(obj: IPaginatedResponseModel) {
    return {
      totalBatchCount: obj.totalBatchCount,
      batches: obj.batches.map((batch) => {
        const model = new BatchModel(
          batch.exceptionId,
          batch.batchId,
          batch.batchName,
          batch.status,
          batch.location,
          batch.scannerId,
          batch.userId,
          batch.pageCount,
          batch.dateCreated
            ? moment(batch.dateCreated).format('MM/DD/YYYY HH:mm')
            : '',
          batch.dateDelivered
            ? moment(batch.dateDelivered).format('MM/DD/YYYY HH:mm')
            : '',
          batch.accountNumber
        );

        model.statusFilterConstraintValue = `${batch.status}-${batch.exceptionId}`;
        return model;
      })
    };
  }

  private statusFilterConstraintValue: string = '';
  private formattedBatchName: string;

  constructor(
    public exceptionId: string,
    public batchId: number,
    public batchName: string,
    public status: string,
    public location: string,
    public scannerId: string,
    public userId: string,
    public pageCount: number,
    public dateCreated: string,
    public dateDelivered: string,
    public accountNumber: string
  ) {}
}

export interface IPaginatedResponseModel {
  totalBatchCount: number;
  batches: BatchModel[];
}

export interface IBatchListRequestModel {
  companyId: number;
  siteIds: number[];
  statusFilter: BATCH_CATEGORY;
  dateCreatedFilter: {
    utcStartDate: Date;
    utcEndDate: Date;
  };
  offset: number;
  pageSize: number;
  batchCaptureType: number;
  batchId: string;
  scannerId: string;
  userId: string;
  notesFilter: NOTES_CATEGORY;
  sortColumns: SortColumnInstructions[];
  accountNumber: string;
}

export interface IStatusFiltersRequestModel {
  companyId: number;
  siteIds: number[];
  dateCreatedFilter: {
    utcStartDate: Date;
    utcEndDate: Date;
  };
  accountNumber: string;
}

export class ColumnFilterOptions {
  constructor(
    public label: string,
    public value: string,
    public batchCd: BATCH_CATEGORY
  ) {}
}

export class TableSortColumns {
  constructor(
    public field: string,
    public header: string,
    public columnID: BATCH_SORT_COLUMN_CATEGORY
  ) {}
}
export class SortColumnInstructions {
  constructor(public batchSortColumn: number, public isAscending: boolean) {}
}
export class StatusPairing {
  constructor(public id: number, public name: string) {}
}
export class BatchListSettingsResponse {
  constructor(
    public batchCaptureType: number,
    public statusFilters: StatusPairing[]
  ) {}
}

export enum BATCH_CATEGORY {
  NONE = 0,
  UPLOADED = 1,
  INPROCESS = 2,
  INPROCESSSCAN = 20001,
  INPROCESSPREP = 20002,
  INPROCESSSECTION = 20004,
  INPROCESSINDEX = 20008,
  INPROCESSQC = 20016,
  DELIVERED = 4,
  WITHEXCEPTIONS = 8
}

export enum NOTES_CATEGORY {
  ALL = 0,
  MISSINGINFORMATION = 1,
  WRONGINFORMATION = 2,
  POORIMAGEQUALITY = 3,
  DUPLICATEBATCH = 4
}

export enum BATCH_SORT_COLUMN_CATEGORY {
  BATCHID = 0,
  BATCHNAME = 1,
  STATUS = 2,
  SCANNERID = 3,
  USERID = 4,
  PAGECOUNT = 5,
  DATECREATED = 6,
  DATEDELIVERED = 7,
  NOTES = 8
}

export enum CUSTOMER_CAPTURE_TYPE {
  DISTRIBUTED = 1,
  OPERATIONAL = 2,
  BOTH = 3
}
