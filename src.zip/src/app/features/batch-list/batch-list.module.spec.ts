import { BatchListModule } from './batch-list.module';

describe('BatchListModule', () => {
  let batchListModule: BatchListModule;

  beforeEach(() => {
    batchListModule = new BatchListModule();
  });

  it('should create an instance', () => {
    expect(batchListModule).toBeTruthy();
  });
});
