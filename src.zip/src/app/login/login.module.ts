import { NgModule, NO_ERRORS_SCHEMA, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from '@appRoot/login/login.component';
import { Routes, RouterModule } from '@angular/router';
import { BaseControlModule } from '@core/modules/base-controls.module';
import { LoginService } from '@appRoot/login/login.service';

const LOGIN_ROUTES: Routes = [{ path: '', component: LoginComponent }];

@NgModule({
  declarations: [LoginComponent],
  exports: [LoginComponent],
  imports: [
    CommonModule,
    BaseControlModule,
    RouterModule.forChild(LOGIN_ROUTES)
  ],
  entryComponents: [],
  providers: [],
  bootstrap: [],
  schemas: [NO_ERRORS_SCHEMA]
})
export class LoginModule {
  public static forRoot(): ModuleWithProviders {
    return {
      ngModule: LoginModule,
      providers: [LoginService]
    };
  }
}
