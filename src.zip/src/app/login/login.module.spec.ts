import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginModule } from './login.module';
import { LoginComponent } from './login.component';

describe('LoginModule', () => {
  let loginModule: LoginModule;

  beforeEach(() => {
    loginModule = new LoginModule();
  });

  it('should create an instance', () => {
    expect(loginModule).toBeTruthy();
  });
});
