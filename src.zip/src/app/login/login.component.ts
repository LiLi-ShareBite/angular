import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { LoginService } from './login.service';
import { AppService } from '@appRoot/app.service';
import { LOGIN_RESULT } from '@appRoot/login/login.model';
import {
  UserAppModel,
  USER_ROLE
} from '@appRoot/features/user-management/user.model';
import { IHomeApp } from '@appRoot/app.model';

@Component({
  selector: '[dbcp-login]',
  template: `
    <div>Redirecting to SSO App...</div>
  `
})
export class LoginComponent implements OnInit {
  private returnUrl: string;

  constructor(
    private loginService: LoginService,
    private appService: AppService,
    private router: Router
  ) {
    this.router.events.subscribe((navigationEnd: NavigationEnd) => {
      if (navigationEnd instanceof NavigationEnd) {
        this.appService.spinner.hide();
      }
    });
  }

  public async ngOnInit() {
    this.appService.spinner.show();
    localStorage.removeItem('dbcpUserLoginStatus');
    localStorage.removeItem('dbcpUserName');
    this.appService.currentUserSubject.next(null);

    this.returnUrl = this.loginService.getReturnUrl();

    const ssoApp: IHomeApp = await this.appService.getHomeApp();

    try {
      const userSessionStatus: boolean = await this.appService.getUserSessionStatus();
      if (userSessionStatus) {
        const currentUser: UserAppModel = await this.appService.getCurrentUser();
        try {
          await this.appService.checkIfUserHasPermission();
        } catch (err) {
          window.location.href = `https://${ssoApp.url}/#/settings`;
        }

        this.loginService.userLoginStatusSubject.next(LOGIN_RESULT.SUCCEEDED);
        localStorage.setItem(
          'dbcpUserLoginStatus',
          LOGIN_RESULT.SUCCEEDED.toString()
        );
        this.loginService.redirectLoggedInUserByRole(
          currentUser,
          this.returnUrl
        );
      } else {
        // Redirect to SSO App
        window.location.href = `https://${ssoApp.url}/#/?appReturnUrl=${window.location.origin}`;
      }
    } catch (e) {
      // Redirect to SSO App
      window.location.href = `https://${ssoApp.url}/#/?appReturnUrl=${window.location.origin}`;
    }
  }
}
