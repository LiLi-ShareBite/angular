import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from '@apiService';
import { HttpClient } from '@angular/common/http';
import { isNullOrUndefined } from 'util';
import { Router } from '@angular/router';

import { LOGIN_RESULT } from '@appRoot/login/login.model';
import {
  UserAppModel,
  USER_ROLE
} from '@appRoot/features/user-management/user.model';
import { AppService } from '@appRoot/app.service';

const POST_LOG_OUT_API = 'api/dbum/authentication/logout';

@Injectable()
export class LoginService extends ApiService {
  public userLoginStatusSubject = new BehaviorSubject<LOGIN_RESULT>(
    LOGIN_RESULT.LOCKED
  );

  constructor(
    private httpClient: HttpClient,
    private router: Router,
    private appService: AppService
  ) {
    super(httpClient);
  }

  public logout() {
    this.post(POST_LOG_OUT_API).subscribe(() => {
      this.appService.spinner.hide();
      location.replace(`/#/login?returnUrl=${encodeURI(this.getReturnUrl())}`);
    });
  }

  public isUserLoggedIn() {
    if (isNullOrUndefined(localStorage.getItem('dbcpUserLoginStatus'))) {
      return LOGIN_RESULT.LOCKED;
    } else {
      return LOGIN_RESULT.SUCCEEDED;
    }
  }

  public redirectLoggedInUserByRole(user: UserAppModel, returnUrl: string) {
    switch (user.detail.role) {
      case USER_ROLE.KNOWLEDGE_WORKER_ADMIN:
      case USER_ROLE.KNOWLEDGE_WORKER:
      case USER_ROLE.OPERATIONS_ADMIN:
        this.router.navigate(['/operations-report']);
        return false;
        break;
      case USER_ROLE.USER:
        if (returnUrl.indexOf('/batch-list') !== -1) {
          this.router.navigateByUrl(returnUrl);
        } else {
          this.router.navigate(['/overview']);
        }
        return false;
        break;
      case USER_ROLE.ADMIN:
        if (
          returnUrl.indexOf('/create-batch') !== -1 ||
          returnUrl.indexOf('/batch-list') !== -1 ||
          returnUrl.indexOf('/operations-report') !== -1
        ) {
          this.router.navigateByUrl(returnUrl);
        } else {
          this.router.navigate(['/overview']);
        }
        return false;
        break;
      default:
        this.router.navigateByUrl(returnUrl);
    }
  }

  public getReturnUrl() {
    let url = this.router.url;

    if (this.router.routerState.snapshot.root.queryParams.returnUrl) {
      url = this.router.routerState.snapshot.root.queryParams.returnUrl;
    }

    if (
      isNullOrUndefined(url) ||
      url === '/login' ||
      url === '/duo' ||
      url === '/'
    ) {
      url = '/overview';
    }

    return url;
  }
}
