import { Injectable } from '@angular/core';
import { ApiService } from '@apiService';
import { BehaviorSubject } from 'rxjs';
import { UserAppModel } from '@appRoot/features/user-management/user.model';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpClient } from '@angular/common/http';
import { LOGIN_RESULT } from '@appRoot/login/login.model';
import { IHomeApp, CurrentUserAppsModel } from '@appRoot/app.model';

const GET_APP_VERSION_API = 'api/dbcp/system-version';
const GET_SESSION_ACTIVE_STATUS_API = 'api/dbum/session/is-session-active';
const GET_CURRENT_USER_API = 'api/dbum/session/current-user';
const GET_HOME_APP_INFO = 'api/dbum/settings/home';
const GET_CURRENT_USER_HAS_PERMISSION = 'api/dbcp/has-permission';
const GET_CURRENT_USER_APPS = 'api/dbum/session/current-user/apps';

@Injectable()
export class AppService extends ApiService {
  public currentUserSubject = new BehaviorSubject<UserAppModel>(null);
  public onUserTimeoutStatus$ = new BehaviorSubject<boolean>(false);

  constructor(
    private httpClient: HttpClient,
    public spinner: NgxSpinnerService
  ) {
    super(httpClient);
  }

  public getAppVersion() {
    return new Promise((resolve, reject) => {
      this.spinner.show();
      this.get(GET_APP_VERSION_API).subscribe(
        (response: any) => {
          if (response && response.Version) {
            localStorage.setItem('dbcpAppVersion', response.Version);
            this.spinner.hide();
            resolve();
          } else {
            localStorage.setItem('dbcpAppVersion', '');
            this.spinner.hide();
            resolve();
          }
          sessionStorage.setItem('isUserSessionStatus', 'success');
        },
        () => {
          sessionStorage.setItem('isUserSessionStatus', 'failure');
          console.log('Error in getUserSessionStatus');
          this.spinner.hide();
        }
      );
    });
  }

  public getUserSessionStatus(): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.spinner.show();
      this.get(GET_SESSION_ACTIVE_STATUS_API).subscribe(
        (response: any) => {
          if (response && response.isSessionActive) {
            localStorage.setItem(
              'dbcpUserLoginStatus',
              LOGIN_RESULT.SUCCEEDED.toString()
            );
            this.spinner.hide();
            resolve(true);
          } else {
            this.spinner.hide();
            resolve(false);
          }
          sessionStorage.setItem('isUserSessionStatus', 'success');
        },
        () => {
          sessionStorage.setItem('isUserSessionStatus', 'failure');
          console.log('Error in getUserSessionStatus');
          this.spinner.hide();
        }
      );
    });
  }

  public getCurrentUser(): Promise<UserAppModel> {
    return new Promise((resolve, reject) => {
      this.spinner.show();
      this.get(GET_CURRENT_USER_API).subscribe(
        (user: UserAppModel) => {
          this.currentUserSubject.next(user);
          this.spinner.hide();
          resolve(user);
        },
        () => {
          this.currentUserSubject.next(null);
          this.spinner.hide();
          reject('Unable to retrieve current user information');
        }
      );
    });
  }

  public getHomeApp(): Promise<IHomeApp> {
    return new Promise((resolve, reject) => {
      this.spinner.show();
      this.get(GET_HOME_APP_INFO).subscribe(
        (app: IHomeApp) => {
          resolve(app);
        },
        () => {
          this.currentUserSubject.next(null);
          this.spinner.hide();
          reject('Unable to retrieve home app info');
        }
      );
    });
  }

  public checkIfUserHasPermission = (): Promise<any> => {
    return this.get(GET_CURRENT_USER_HAS_PERMISSION).toPromise();
  };

  public getCurrentUserApps(): Promise<CurrentUserAppsModel> {
    return new Promise((resolve, reject) => {
      this.spinner.show();
      this.get(GET_CURRENT_USER_APPS).subscribe(
        (apps: CurrentUserAppsModel) => {
          resolve(apps);
        },
        () => {
          this.currentUserSubject.next(null);
          this.spinner.hide();
          reject('Unable to retrieve current user apps info');
        }
      );
    });
  }
}
