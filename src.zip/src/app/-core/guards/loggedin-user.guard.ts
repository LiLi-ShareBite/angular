import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from '@angular/router';
import { Injectable } from '@angular/core';
import { LoginService } from '@appRoot/login/login.service';
import { LOGIN_RESULT } from '@appRoot/login/login.model';

@Injectable()
export class OnlyLoggedInUserGuard implements CanActivate {
  constructor(private loginService: LoginService, private router: Router) {}

  public canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ) {
    const isCurrentUserLoggedIn =
      +this.loginService.isUserLoggedIn() === LOGIN_RESULT.SUCCEEDED;
    const isCurrentUrlLoginPage = state.url.indexOf('/login') >= 0;
    const xor = Number(isCurrentUserLoggedIn) ^ Number(isCurrentUrlLoginPage);

    if (xor === 1) {
      return true;
    }

    if (!isCurrentUrlLoginPage) {
      this.router.navigate(['/login'], {
        queryParams: { returnUrl: state.url }
      });
    } else {
      this.router.navigate([state.url]);
    }
    return false;
  }
}
