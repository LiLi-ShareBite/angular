import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { Injectable } from '@angular/core';
import { LoginService } from '@appRoot/login/login.service';
import { UserAppModel } from '@appRoot/features/user-management/user.model';
import { AppService } from '@appRoot/app.service';
import { LOGIN_RESULT } from '@appRoot/login/login.model';

@Injectable()
export class RoleGuard implements CanActivate {
  private currentUser: UserAppModel;

  constructor(
    public loginService: LoginService,
    private appService: AppService,
    private router: Router
  ) {
    this.appService.currentUserSubject.subscribe(
      (user: UserAppModel) => {
        this.currentUser = user;
      },
      () => {
        this.currentUser = null;
      }
    );
  }

  public canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | Promise<boolean> {
    const expectedRole = route.data.expectedRole;
    if (this.loginService.isUserLoggedIn() === LOGIN_RESULT.SUCCEEDED) {
      if (this.currentUser) {
        if (this.validateActivation(expectedRole, this.currentUser)) {
          return true;
        } else {
          this.loginService.logout();
        }
      } else {
        // get current user details
        return this.appService.getCurrentUser().then(
          (user: UserAppModel) => {
            if (this.validateActivation(expectedRole, this.currentUser)) {
              return true;
            } else {
              this.loginService.logout();
              return false;
            }
          },
          () => {
            this.loginService.logout();
            return false;
          }
        );
      }
    } else {
      this.router.navigate(['/login']);
    }
    return false;
  }

  private validateActivation(expectedRole, user: UserAppModel) {
    if (expectedRole.indexOf(user.detail.role) !== -1) {
      return true;
    } else {
      return false;
    }
  }
}
