import { ErrorHandler, Injector, Injectable } from '@angular/core';
import { timer } from 'rxjs';
import { UnauthorizedError } from '@core/errors/unauthorized.error';
import { LoginService } from '@appRoot/login/login.service';
import { AppService } from '@appRoot/app.service';
import { LOGIN_RESULT } from '@appRoot/login/login.model';

@Injectable()
export class GlobalErrorHandler extends ErrorHandler {
  constructor(private injector: Injector, private appService: AppService) {
    super();
  }

  public handleError(error: any) {
    this.appService.spinner.hide();
    timer().subscribe(() => {
      super.handleError(error);
    });

    if (error instanceof UnauthorizedError || error.errorCode === 401) {
      this.handleUnauthorizedError();
      return;
    }
  }

  private handleUnauthorizedError() {
    this.appService.spinner.hide();
    const loginService = this.injector.get(LoginService);
    loginService.userLoginStatusSubject.next(LOGIN_RESULT.FAILED);
    loginService.logout();
  }
}
