import { ApiService } from '@appRoot/-core/services/api.service';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

describe('Services: CoreComponents', () => {
  let apiService: ApiService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiService],
      imports: [HttpClientTestingModule]
    });

    // We inject our service (which imports the HttpClient) and the Test Controller
    httpTestingController = TestBed.get(HttpTestingController);
    apiService = TestBed.get(ApiService);
  });

  it('ApiService should be created', () => {
    expect(apiService).toBeTruthy();
  });

  it('A callback method performing custom clean-up was defined.', () => {
    expect(apiService.ngOnDestroy).toBeTruthy();
  });
});
