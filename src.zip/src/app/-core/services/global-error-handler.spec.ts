import { GlobalErrorHandler } from '@appRoot/-core/services/global-error-handler';
import { Injector } from '@angular/core';
import { AppService } from '@appRoot/app.service';

describe('Global-error-handler_Services: CoreComponents', () => {
  let globalErrorHandler: GlobalErrorHandler;
  /* tslint:disable */
  let injector: Injector;
  let appService: AppService;

  beforeEach(() => {
    globalErrorHandler = new GlobalErrorHandler(injector, appService);
  });

  it('globalErrorHandler error handle function defined', () => {
    expect(globalErrorHandler.handleError).toBeDefined();
  });
});
