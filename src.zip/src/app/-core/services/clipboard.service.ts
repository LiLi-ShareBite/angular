import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { isNullOrUndefined } from 'util';

@Injectable()
export class ClipboardService {
  private tempTextArea: HTMLTextAreaElement | undefined;

  constructor(@Inject(DOCUMENT) private document: any) {}

  public copy(content: string) {
    if (isNullOrUndefined(this.tempTextArea)) {
      this.tempTextArea = this.createTempTextArea(this.document);
      this.document.body.appendChild(this.tempTextArea);
    }
    this.tempTextArea.value = content;
    return this.copyFromElement(this.tempTextArea);
  }

  private createTempTextArea(doc: Document): HTMLTextAreaElement {
    let ta: HTMLTextAreaElement;
    ta = doc.createElement('textarea');
    ta.style.height = '0px';
    ta.style.left = '-100px';
    ta.style.top = '-100px';
    ta.style.width = '0px';
    ta.style.opacity = '0';
    ta.style.position = 'fixed';
    return ta;
  }

  private copyFromElement(targetElem: HTMLTextAreaElement): boolean {
    try {
      this.selectElement(targetElem);
      const content = this.copyText();
      return content;
    } catch (error) {
      console.log(`Copy to clipboard failed. Error: ${error}`);
      return false;
    } finally {
      this.document.body.removeChild(this.tempTextArea);
      this.tempTextArea = undefined;
    }
  }

  private selectElement(targetElem: HTMLTextAreaElement): number | undefined {
    targetElem.select();
    targetElem.setSelectionRange(0, targetElem.value.length);
    return targetElem.value.length;
  }

  private copyText(): boolean {
    return this.document.execCommand('copy');
  }
}
