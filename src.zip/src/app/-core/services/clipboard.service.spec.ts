import { ClipboardService } from '@appRoot/-core/services/clipboard.service';
import { any } from 'prop-types';

describe('ClipboardServices: CoreComponents', () => {
  let clipboardService: ClipboardService;

  beforeEach(() => {
    clipboardService = new ClipboardService(any);
  });

  it('ClipboardService copy function defined', () => {
    expect(clipboardService.copy).toBeDefined();
  });
});
