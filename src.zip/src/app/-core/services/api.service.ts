import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subscriber, Subscription } from 'rxjs';
import { UnauthorizedError } from '@appRoot/-core/errors/unauthorized.error';
import { OnDestroy, Injectable } from '@angular/core';
import { environment } from 'environments/environment';

enum REQUEST_TYPE {
  GET,
  POST,
  PUT,
  PATCH,
  DELETE
}

@Injectable()
export abstract class ApiService implements OnDestroy {
  private _subscribers: Array<Subscriber<any>> = [];
  private _subscriptions: Subscription[] = [];

  constructor(private _http: HttpClient) {}

  public ngOnDestroy(): void {
    const service = this,
      subscriptions = service._subscriptions,
      subscribers = service._subscribers;

    for (const subscription of subscriptions) {
      if (!subscription.closed) {
        subscription.unsubscribe();
      }
    }

    for (const subscriber of subscribers) {
      if (!subscriber.closed) {
        subscriber.unsubscribe();
      }
    }
  }

  public getAntiCsrfToken(): string {
    const cookieName: string = `dbcp_csrf_token=`;
    const decodedCookie: string = decodeURIComponent(document.cookie);
    const ca: string[] = decodedCookie.split(';');

    for (let i = 0; i < ca.length; i++) {
      let c: string = ca[i];
      while (c.charAt(0) === ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(cookieName) === 0) {
        const result = c.substring(cookieName.length, c.length);
        return result;
      }
    }
    return '';
  }

  protected get<R, P extends any, O extends any>(
    url: string,
    params?: P,
    options?: O
  ): Observable<R> {
    return this._sendRequest(REQUEST_TYPE.GET, url, null, params, options);
  }

  protected post<R, D extends any, P extends any>(
    url: string,
    data?: D,
    params?: P
  ): Observable<R> {
    return this._sendRequest(REQUEST_TYPE.POST, url, data, params);
  }

  protected put<R, D extends any, P extends any>(
    url: string,
    data?: D,
    params?: P
  ): Observable<R> {
    return this._sendRequest(REQUEST_TYPE.PUT, url, data, params);
  }

  protected patch<R, D extends any, P extends any>(
    url: string,
    data?: D,
    params?: P
  ): Observable<R> {
    return this._sendRequest(REQUEST_TYPE.PATCH, url, data, params);
  }

  protected delete<R, P extends any>(url: string, params?: P): Observable<R> {
    return this._sendRequest(REQUEST_TYPE.DELETE, url, null, params);
  }

  protected showLoadError() {
    const alert: any = window.document.querySelector('.load-alert');
    if (alert) {
      alert.classList.toggle('hide-alert');
    }
  }

  private _sendRequest<R, D extends any, P extends any, O extends any>(
    type: REQUEST_TYPE,
    url: string,
    data?: D,
    params?: P,
    httpOptions?: O
  ) {
    const service = this;
    let options = {} as any;

    url = this.getAPIUrl(url);

    let headers = new HttpHeaders();

    const csrfToken = this.getAntiCsrfToken();
    headers = headers.set('CSRF-Token', csrfToken);

    options.headers = headers;

    if (httpOptions) {
      options = { ...options, ...httpOptions };
    }

    return Observable.create((subscriber: Subscriber<ArrayBuffer>) => {
      if (params) {
        const requestParams: { [key: string]: any } = {};

        for (const paramName in params) {
          if (params.hasOwnProperty(paramName)) {
            requestParams[paramName] = params[paramName];
          }
        }

        options.params = requestParams;
      }

      let request: Observable<ArrayBuffer>;

      if (type === REQUEST_TYPE.GET) {
        request = service._http.get(url, options);
      } else if (type === REQUEST_TYPE.POST) {
        request = service._http.post(url, data, options);
      } else if (type === REQUEST_TYPE.PUT) {
        request = service._http.put(url, data, options);
      } else if (type === REQUEST_TYPE.PATCH) {
        request = service._http.patch(url, data, options);
      } else if (type === REQUEST_TYPE.DELETE) {
        request = service._http.delete(url, options);
      } else {
        const errMsg = 'Unknown error in ApiService.ts';
        throw new Error(errMsg);
      }

      const subscription = request.subscribe(
        (response: ArrayBuffer) => {
          subscriber.next(response);
        },
        (error: Response) => {
          service._handleError(error);
          subscriber.error(error);
        },
        () => {
          subscriber.complete();
        }
      );

      service._subscribers.push(subscriber);
      service._subscriptions.push(subscription);
    });
  }

  private _handleError(error: Response | any): any {
    this.showLoadError();
    if (error.status === 401) {
      throw new UnauthorizedError(error.statusMessage, error.status);
    }
  }

  private getAPIUrl(url: string) {
    if (environment.environment_name === 'local') {
      return (url = `api_v1/${url}`);
    } else {
      return url;
    }
  }
}
