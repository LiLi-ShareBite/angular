import { BaseError } from '@appRoot/-core/errors/base.error';

export class UnauthorizedError extends BaseError {
  constructor(message: string = '', public errorCode = 401) {
    super(message, errorCode);
  }
}
