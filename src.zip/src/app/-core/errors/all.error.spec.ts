import { BaseError } from '@appRoot/-core/errors/base.error';
import { UnauthorizedError } from '@appRoot/-core/errors/unauthorized.error';

describe('Component: Errors', () => {
  let baseErr: BaseError;
  let unauthorizedErr: UnauthorizedError;

  beforeEach(() => {
    baseErr = new BaseError();
    unauthorizedErr = new UnauthorizedError();
  });

  it('Template should create error name', () => {
    expect(baseErr.name).toBeDefined();
  });

  it('Template should create error message', () => {
    expect(baseErr.message).toBeDefined();
  });

  it('Error code should be digital number', () => {
    expect(baseErr.errorCode).toEqual(0);
  });

  it('Unauthorized error code should be number 401', () => {
    expect(unauthorizedErr.errorCode).toEqual(401);
  });
});
