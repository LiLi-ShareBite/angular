import { EqualValidatorDirective } from './equal-validator.directive';
import { Component } from '@angular/core';
import { TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

// create a component that uses the directive
@Component({
  selector: 'test-component',
  template: ''
})
class TestComponent {}

describe('Equal_Validator_Directive: CoreComponents', () => {
  let equalValidatorDirective: EqualValidatorDirective;

  it('Directive equal validator should be defined', () => {
    expect(equalValidatorDirective.validate).toBeDefined();
  });

  beforeEach(() => {
    equalValidatorDirective = new EqualValidatorDirective();

    // create a module that declared
    TestBed.configureTestingModule({
      declarations: [TestComponent, EqualValidatorDirective]
    });
  });
  // add the template(that contains directive) to the component, can be handled dynamically by overwriting the template in test
  it('Should be able to test directive', async(() => {
    TestBed.overrideComponent(TestComponent, {
      set: {
        template: '<div dbcp-equal-validator></div>'
      }
    });
    // compile the component, and query it using By.directive. At the very end, to get a directive instance using the injector
    TestBed.compileComponents().then(() => {
      const fixture = TestBed.createComponent(TestComponent);
      const directiveEl = fixture.debugElement.query(
        By.directive(EqualValidatorDirective)
      );
      expect(directiveEl).toBeDefined();

      const directiveInstance = directiveEl.injector.get(
        EqualValidatorDirective
      );
      expect(directiveInstance.validate).toBeTruthy();
    });
  }));
});
