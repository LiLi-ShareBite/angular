import { Validator, NG_VALIDATORS, AbstractControl } from '@angular/forms';
import { Directive, Input } from '@angular/core';

@Directive({
  selector: '[dbcp-equal-validator]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: EqualValidatorDirective,
      multi: true
    }
  ]
})
export class EqualValidatorDirective implements Validator {
  @Input('dbcp-equal-validator')
  private equalValidator: string;

  public validate(control: AbstractControl): { [key: string]: any } | null {
    const controlToCompare = control.parent.get(this.equalValidator);

    if (controlToCompare) {
      if (control && control.value !== controlToCompare.value) {
        return {
          notEqual: true
        };
      }
    } else if (this.equalValidator) {
      if (control.value !== this.equalValidator) {
        return {
          notEqual: true
        };
      }
    }
    return null;
  }
}
