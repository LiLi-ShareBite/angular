import { TestBed, ComponentFixture } from '@angular/core/testing';
import { FooterComponent } from './footer.component';
import { DebugElement } from '@angular/core';
import { LocalizePipe } from '@core/pipes/localize.pipe';

describe('Component: FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;
  let localizePipe: LocalizePipe;
  let dElem: DebugElement;
  let elem: HTMLElement;
  let pipeSpy: jasmine.Spy;

  beforeEach(() => {
    localizePipe = new LocalizePipe();

    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      declarations: [FooterComponent, LocalizePipe]
    });

    pipeSpy = spyOn(LocalizePipe.prototype, 'transform');

    // create component and test fixture
    fixture = TestBed.createComponent(FooterComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    dElem = fixture.debugElement;
    elem = dElem.nativeElement;
  });

  it('should create component', () => {
    expect(dElem).not.toBe(null);
    expect(elem).toBeDefined();
  });
});
