import { Component } from '@angular/core';

@Component({
  selector: 'dbcp-footer',
  template: `
    <footer>
      <div class="container-fluid">
        <div class="row">
          <div class="col-12 col-md-3 text-center text-md-left">
            <small>{{ 'FOOTER_COPYRIGHT' | dbcpLocalize }}</small>
          </div>
          <div class="col d-none d-md-block"></div>
          <div class="col-12 col-md-2 col-xl-1 text-center text-md-right">
            <small
              ><a
                href="https://www.databankimx.com/privacy-policy-and-gdpr/"
                target="_blank"
                >{{ 'FOOTER_PRIVACY_POLICY' | dbcpLocalize }}</a
              ></small
            >
          </div>
          <div
            *ngIf="appVersion"
            class="col-12 col-md-2 col-xl-1 text-center text-md-right"
          >
            <small>v {{ appVersion }}</small>
          </div>
        </div>
      </div>
    </footer>
  `,
  styles: [
    `
      footer {
        border-top: 1px solid #dde3e6;
      }
    `,
    `
      a {
        color: inherit !important;
      }
    `,
    `
      small {
        font-size: 70%;
      }
    `
  ]
})
export class FooterComponent {
  public appVersion: string;

  constructor() {
    this.appVersion = localStorage.getItem('dbcpAppVersion');
  }
}
