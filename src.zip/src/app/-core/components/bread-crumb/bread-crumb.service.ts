import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

export interface IBreadCrumbItem {
  label: string;
  enabled: boolean;
  url?: string;
}

@Injectable()
export class BreadCrumbService {
  public crumbs$: Observable<IBreadCrumbItem[]>;
  private crumbs: Subject<IBreadCrumbItem[]>;
  private navItem: IBreadCrumbItem[];

  constructor() {
    this.navItem = [];
    this.crumbs = new Subject<IBreadCrumbItem[]>();
    this.crumbs$ = this.crumbs.asObservable();
  }

  public get length(): number {
    return this.navItem.length;
  }

  public setBreadCrumb(items: IBreadCrumbItem[]) {
    this.navItem.length = 0;
    this.navItem = items;
    this.crumbs.next(this.navItem);
  }

  public appendBreadCrumb(items: IBreadCrumbItem[]) {
    this.navItem[this.navItem.length - 1].enabled = true;
    this.navItem.push(...items);
    this.crumbs.next(this.navItem);
  }

  public clearBreadcrumbNavItem(
    startNavItem: number,
    totalNavItem: number = 1
  ) {
    const temp = [...this.navItem];
    temp.splice(startNavItem, totalNavItem);
    this.setBreadCrumb(temp);
  }

  public clear() {
    this.navItem.length = 0;
  }
}
