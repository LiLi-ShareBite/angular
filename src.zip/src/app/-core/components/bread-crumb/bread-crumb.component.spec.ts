import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import {
  IBreadCrumbItem,
  BreadCrumbService
} from '@core/components/bread-crumb/bread-crumb.service';
import { TestBed, inject, async } from '@angular/core/testing';
import { BreadCrumbComponent } from './bread-crumb.component';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { Location, CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { Injectable } from '@angular/core';

@Component({
  template: `
    <li
      class="breadcrumb-item"
      *ngIf="crumb.enabled; else txtLinkItem"
      [routerLink]="[crumb.url]"
    >
      {{ crumb.label }}
    </li>
  `
})
@Component({
  template: ''
})
@Injectable()
class MockComponent {}

describe('component: BreadCrumbComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        RouterTestingModule.withRoutes([
          { path: 'http://localhost:4200', component: MockComponent }
        ])
      ],
      declarations: [BreadCrumbComponent, MockComponent],
      providers: [BreadCrumbService],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  it('URL should be defined', async(
    inject([Router, Location], (router: Router, location: Location) => {
      const fixture = TestBed.createComponent(BreadCrumbComponent);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(location.path()).toBeDefined();
      });
    })
  ));
});

describe('Service: BreadCrumbService', () => {
  let service: BreadCrumbService;

  beforeEach(() => {
    service = new BreadCrumbService();
  });

  it('setBreadCrumb should be created', () => {
    const obj: IBreadCrumbItem = {
      label: 'batches',
      enabled: true,
      url: '/batch-list/'
    };
    expect(service.setBreadCrumb).toBeTruthy();
  });

  it('appendBreadCrumb should be created', () => {
    const obj: IBreadCrumbItem = {
      label: 'overview',
      enabled: true,
      url: '/overview/'
    };
    expect(service.appendBreadCrumb).toBeTruthy();
  });

  it('BreadcrumbNavItem should be cleared', () => {
    expect(service.clearBreadcrumbNavItem.length).toEqual(1);
  });
});
