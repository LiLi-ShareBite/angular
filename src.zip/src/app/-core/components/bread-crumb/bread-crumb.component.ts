import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {
  IBreadCrumbItem,
  BreadCrumbService
} from '@core/components/bread-crumb/bread-crumb.service';

@Component({
  selector: 'dbcp-breadcrumb',
  template: `
    <div>
      <ol class="breadcrumb mb-0">
        <ng-container *ngFor="let crumb of crumbs$ | async">
          <li
            class="breadcrumb-item"
            *ngIf="crumb.enabled; else txtLinkItem"
            [routerLink]="[crumb.url]"
          >
            {{ crumb.label }}
          </li>
          <ng-template #txtLinkItem>
            <li class="breadcrumb-item">
              {{ crumb.label }}
            </li>
          </ng-template>
        </ng-container>
      </ol>
    </div>
  `,
  styles: [
    `
      .breadcrumb {
        background-color: transparent !important;
      }

      .breadcrumb-item {
        cursor: pointer !important;
        font-size: 14px;
      }

      .breadcrumb-item + .breadcrumb-item:before {
        content: '>';
      }

      .breadcrumb > li:not(:last-child) {
        color: #4a90e2 !important;
      }

      .breadcrumb > li:last-child {
        cursor: default !important;
      }
    `
  ]
})
export class BreadCrumbComponent implements OnInit {
  public crumbs$: Observable<IBreadCrumbItem[]>;

  constructor(private breadcrumb: BreadCrumbService) {}

  public ngOnInit() {
    this.crumbs$ = this.breadcrumb.crumbs$;
  }
}
