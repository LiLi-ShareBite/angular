import { Component, Input, Output, EventEmitter } from '@angular/core';
import { IDbcpAlert } from '@core/components/alert/alert.model';

@Component({
  selector: 'dbcp-alert',
  template: `
    <div
      class="alert d-flex align-items-center"
      [ngClass]="_alert.myClass"
      role="alert"
    >
      <span class="fa mr-2 align-middle" [ngClass]="_alert.myIcon"></span>
      <span class="align-middle text-left dbcp-alert">{{
        _alert.message
      }}</span>
      <button
        type="button"
        *ngIf="_alert.isDismissable"
        (click)="onClose()"
        class="close"
        data-dismiss="alert"
        aria-label="Close"
      >
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  `,
  styles: [
    `
      .dbcp-alert {
        flex-grow: 1;
      }

      button {
        cursor: pointer !important;
      }

      .dbcp-alert-success {
        background-color: #f5feea !important;
        color: #5cb85c !important;
        border-color: #5cb85c !important;
      }

      .dbcp-alert-danger {
        color: #ab1a0f !important;
        background-color: #ffcbc8 !important;
        border-color: #ab1a0f !important;
      }

      .dbcp-alert-info {
        color: #004085 !important;
        background-color: #cce5ff !important;
        border-color: #004085 !important;
      }

      .close {
        color: inherit !important;
        opacity: 1 !important;
      }
    `
  ]
})
export class AlertComponent {
  @Input('alert')
  public _alert: IDbcpAlert;

  // tslint:disable-next-line:no-output-rename
  @Output('close')
  public close: EventEmitter<any> = new EventEmitter();

  constructor() {}

  public onClose() {
    this.close.emit(true);
  }
}
