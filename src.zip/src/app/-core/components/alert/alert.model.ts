enum DBCP_ALERT {
  Success,
  Info,
  Error
}

export interface IDbcpAlert {
  message: string;
  myClass: string;
  myIcon: string;
  type?: DBCP_ALERT;
  isDismissable?: boolean;
}

export class DbcpSuccessAlert implements IDbcpAlert {
  public get myClass() {
    return 'alert-success dbcp-alert-success';
  }

  public get myIcon() {
    return 'far fa-check-circle fa-4x';
  }

  public get type() {
    return DBCP_ALERT.Success;
  }

  constructor(public message: string, public isDismissable: boolean = false) {}
}

export class DbcpInfoAlert implements IDbcpAlert {
  public get myClass() {
    return 'alert-info dbcp-alert-info';
  }

  public get myIcon() {
    return 'far fa-clock fa-4x';
  }

  public get type() {
    return DBCP_ALERT.Info;
  }

  constructor(public message: string, public isDismissable: boolean = false) {}
}

export class DbcpErrorAlert implements IDbcpAlert {
  public get myClass() {
    return 'alert-danger dbcp-alert-danger';
  }

  public get myIcon() {
    return 'fas fa-exclamation-triangle fa-4x';
  }

  public get type() {
    return DBCP_ALERT.Error;
  }

  constructor(public message: string, public isDismissable: boolean = false) {}
}
