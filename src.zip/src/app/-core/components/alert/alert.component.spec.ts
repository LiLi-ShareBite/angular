import { TestBed, ComponentFixture } from '@angular/core/testing';
import { AlertComponent } from './alert.component';
import { DebugElement } from '@angular/core';

describe('Component: AlertComponent', () => {
  let component: AlertComponent;
  let fixture: ComponentFixture<AlertComponent>;

  let dElem: DebugElement;
  let elem: HTMLElement;

  beforeEach(() => {
    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      declarations: [AlertComponent]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(AlertComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    dElem = fixture.debugElement;
    elem = dElem.nativeElement;
  });

  it('should create component', () => {
    expect(dElem).not.toBe(null);
    expect(elem).toBeDefined();
  });

  it('Close emmitter should be defined', () => {
    expect(component.close).toBeTruthy();
  });

  it('Close button should be created', () => {
    const contButton = elem.querySelector('button');
    expect(contButton).toBeDefined();
  });

  it('Alert icon and message should be created', () => {
    const contSpan = elem.querySelector('span');
    expect(contSpan).toBeDefined();
  });
});
