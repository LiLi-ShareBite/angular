export class CompanyModel {
  constructor(
    public id: number,
    public name: string,
    public description: string
  ) {}
}

export class LocationModel {
  constructor(
    public id: number,
    public name: string,
    public description: string
  ) {}
}

export interface ITimeFrameOption {
  id: number;
  value: string;
}

export interface ISelectedCompanyLocation {
  company: CompanyModel;
  locations: LocationModel[];
}

export interface IMainFiltersModel {
  company: CompanyModel;
  locations: LocationModel[];
  timeFrame?: ITimeFrameModel;
  accountNumber?: string;
}

export interface ITimeFrameModel {
  option: ITimeFrameOption;
  startDt: Date;
  endDt: Date;
}

export const timeFrameOptions: ITimeFrameOption[] = [
  // {id: 0, value: 'All'},
  { id: 1, value: 'Past week' },
  { id: 2, value: 'Past month' },
  { id: 3, value: 'Custom dates' }
];
