import { Injectable } from '@angular/core';
import { ApiService } from '@apiService';
import * as util from 'util';
import {
  IMainFiltersModel,
  LocationModel,
  CompanyModel
} from '@core/components/main-filters/main-filters.model';
import { map } from 'rxjs/operators';

const GET_COMPANIES_API = 'api/dbum/organization-management/companies';
const GET_SITES_API = 'api/dbum/organization-management/companies/%s/sites';

@Injectable()
export class MainFiltersService extends ApiService {
  private _selectedFilter: IMainFiltersModel = null;

  public get SelectedFiltersValue(): IMainFiltersModel {
    return this._selectedFilter;
  }

  public set SelectedFiltersValue(value: IMainFiltersModel) {
    this._selectedFilter = value;
  }

  public resetMainFilters() {
    this.SelectedFiltersValue = {
      company: null,
      locations: [],
      timeFrame: null,
      accountNumber: null
    };
  }

  public getCompanies() {
    return new Promise((resolve, reject) => {
      this.get(GET_COMPANIES_API)
        .pipe(map((response) => response as CompanyModel[]))
        .subscribe(
          (companies: CompanyModel[]) => {
            resolve(companies);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  public getSites(companyId: number) {
    return new Promise((resolve, reject) => {
      this.get(util.format(GET_SITES_API, companyId))
        .pipe(map((response) => response as LocationModel[]))
        .subscribe(
          (sites: LocationModel[]) => {
            resolve(sites);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
}
