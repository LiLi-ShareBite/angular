import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {
  ITimeFrameOption,
  CompanyModel,
  LocationModel,
  timeFrameOptions,
  IMainFiltersModel,
  ITimeFrameModel
} from '@core/components/main-filters/main-filters.model';
import * as moment from 'moment';
import { MainFiltersService } from '@core/components/main-filters/main-filters.service';
import { ActivatedRoute, Router } from '@angular/router';
import {
  UserAppModel,
  USER_ROLE
} from '@appRoot/features//user-management/user.model';
import { AppService } from '@appRoot/app.service';

@Component({
  selector: 'dbcp-main-filters',
  templateUrl: './main-filters.component.html',
  styleUrls: ['./main-filters.component.scss']
})
export class MainFiltersComponent implements OnInit {
  public timeFrameOptions: ITimeFrameOption[] = timeFrameOptions;
  public selectedTimeFrameOption: ITimeFrameOption;
  public companyOptions: CompanyModel[] = [];
  public locationOptions: LocationModel[] = [];
  public USER_ROLE: typeof USER_ROLE = USER_ROLE;

  public currentUser: UserAppModel;
  public selectedStartDt: Date = null;
  public selectedEndDt: Date = null;
  public selectedCompany: CompanyModel = null;
  public selectedLocations: LocationModel[] = [];
  public currentFeatureName: string;
  public maxEndDt: Date = null;
  public maxStartDt: Date = null;
  public minStartDt: Date = null;
  public searchAccountNumber: string = null;

  @Output()
  public onMainFiltersValues = new EventEmitter<IMainFiltersModel>();

  @Output()
  public onMainFiltersError = new EventEmitter<string>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private appService: AppService,
    private mainFiltersService: MainFiltersService
  ) {
    this.currentFeatureName = this.route.snapshot.data.currentFeature;

    this.appService.currentUserSubject.subscribe(
      (user: UserAppModel) => {
        this.currentUser = user;
      },
      () => {
        this.currentUser = null;
      }
    );

    this.maxStartDt = moment()
      .utc()
      .toDate();
    this.maxEndDt = this.maxStartDt;
    this.minStartDt = moment()
      .utc()
      .subtract(90, 'days')
      .toDate();
  }

  public onSelectTimeFrameOption(event) {
    this.selectedTimeFrameOption = event.value;
    this.onTimeFrameDateRangeFilterInit(event.value.id);
    this.updateFilters();
  }

  public ngOnInit() {
    this.loadTimeFrameFilter();
    this.loadCompanyAndLocationFilter();
  }

  public onStartDtSelect(selectedStartDt: Date) {
    this.selectedEndDt = moment()
      .utc()
      .toDate();
    // Set timeOption into Custom dates
    this.selectedTimeFrameOption = this.timeFrameOptions[2];
    // Set timeOption into Past week
    if (
      this.selectedEndDt.getFullYear() === this.selectedStartDt.getFullYear() &&
      this.selectedEndDt.getMonth() === this.selectedStartDt.getMonth() &&
      this.selectedEndDt.getDate() - this.selectedStartDt.getDate() === 7
    ) {
      this.selectedTimeFrameOption = this.timeFrameOptions[0];
    }
    // Set timeOption into Past month
    if (
      this.selectedEndDt.getFullYear() === this.selectedStartDt.getFullYear() &&
      this.selectedEndDt.getDate() === this.selectedStartDt.getDate() &&
      this.selectedEndDt.getMonth() - this.selectedStartDt.getMonth() === 1
    ) {
      this.selectedTimeFrameOption = this.timeFrameOptions[1];
    }
    this.updateFilters();
  }

  public onEndDtSelect(selectedEndDt: Date) {
    this.selectedEndDt = moment(selectedEndDt)
      .utc()
      .toDate();
    // Set timeOption into Custom dates
    if (this.selectedEndDt.toDateString() !== this.maxStartDt.toDateString()) {
      this.selectedTimeFrameOption = this.timeFrameOptions[2];
    } else {
      // Set timeOption into Past week
      if (
        this.selectedEndDt.getFullYear() ===
          this.selectedStartDt.getFullYear() &&
        this.selectedEndDt.getMonth() === this.selectedStartDt.getMonth() &&
        this.selectedEndDt.getDate() - this.selectedStartDt.getDate() === 7
      ) {
        this.selectedTimeFrameOption = this.timeFrameOptions[0];
      }
      // Set timeOption into Past month
      if (
        this.selectedEndDt.getFullYear() ===
          this.selectedStartDt.getFullYear() &&
        this.selectedEndDt.getDate() === this.selectedStartDt.getDate() &&
        this.selectedEndDt.getMonth() - this.selectedStartDt.getMonth() === 1
      ) {
        this.selectedTimeFrameOption = this.timeFrameOptions[1];
      }
    }
    this.updateFilters();
  }

  public onAccountNumberSearch() {
    const numbers = /^[0-9]+$/;
    if (this.searchAccountNumber && this.searchAccountNumber.match(numbers)) {
      this.mainFiltersService.SelectedFiltersValue.accountNumber = this.searchAccountNumber;
      this.updateFilters();
    } else {
      this.clearAccountNumber();
    }
  }

  public onCompanyOptionChange() {
    this.locationOptions = [];
    this.selectedLocations = [];
    this.mainFiltersService.SelectedFiltersValue = null;
    if (this.router.routerState.snapshot.url.indexOf('/batch-list') >= 0) {
      this.router.navigate(['/batch-list', 0, 0]); // clear filters
    }
    this.getLocationFilters().then(
      () => {
        this.updateFilters();
      },
      (error) => {
        this.throwFiltersError(error);
      }
    );
  }

  public onLocationOptionChange() {
    this.updateFilters();
  }

  public clearAccountNumber() {
    this.searchAccountNumber = '';
    this.mainFiltersService.SelectedFiltersValue.accountNumber = '';
    this.updateFilters();
  }

  private loadTimeFrameFilter() {
    if (
      this.mainFiltersService.SelectedFiltersValue &&
      this.mainFiltersService.SelectedFiltersValue.timeFrame
    ) {
      this.selectedTimeFrameOption = this.mainFiltersService.SelectedFiltersValue.timeFrame.option;
      this.selectedStartDt = this.mainFiltersService.SelectedFiltersValue.timeFrame.startDt;
      this.selectedEndDt = this.mainFiltersService.SelectedFiltersValue.timeFrame.endDt;
    } else {
      // set default selection time frame into custom date option
      this.selectedTimeFrameOption = this.timeFrameOptions[2];
      this.onTimeFrameDateRangeFilterInit(3);
    }
  }

  private loadCompanyAndLocationFilter() {
    this.companyOptions = [];
    this.locationOptions = [];
    this.selectedCompany = null;
    this.selectedLocations = [];

    this.getCompanyFilters().then(() => {
      this.getLocationFilters().then(() => {
        this.updateFilters();
      });
    });
  }

  private getCompanyFilters() {
    this.appService.spinner.show();
    return new Promise((resolve, reject) => {
      this.mainFiltersService.getCompanies().then(
        (companies: CompanyModel[]) => {
          this.companyOptions = companies;
          if (
            this.mainFiltersService.SelectedFiltersValue &&
            this.mainFiltersService.SelectedFiltersValue.company
          ) {
            this.selectedCompany = this.mainFiltersService.SelectedFiltersValue.company;
            this.appService.spinner.hide();
            resolve();
          } else if (this.companyOptions && this.companyOptions.length) {
            this.selectedCompany = this.companyOptions[0];
            this.appService.spinner.hide();
            resolve();
          } else {
            // Display error message.
            this.appService.spinner.hide();
            this.throwFiltersError('Display error message.');
            reject();
          }
        },
        (error) => {
          // Display error message.
          this.appService.spinner.hide();
          this.throwFiltersError(error);
          reject();
        }
      );
    });
  }

  private getLocationFilters() {
    this.appService.spinner.show();
    return new Promise((resolve, reject) => {
      this.mainFiltersService.getSites(this.selectedCompany.id).then(
        (locations: LocationModel[]) => {
          this.locationOptions = locations;
          if (
            this.mainFiltersService.SelectedFiltersValue &&
            this.mainFiltersService.SelectedFiltersValue.locations.length
          ) {
            this.selectedLocations = this.mainFiltersService.SelectedFiltersValue.locations;
            this.appService.spinner.hide();
            resolve();
          } else if (this.locationOptions && this.locationOptions.length) {
            this.selectedLocations = [this.locationOptions[0]];
            this.appService.spinner.hide();
            resolve();
          } else {
            // Display error message.
            this.appService.spinner.hide();
            this.throwFiltersError('Display error message.');
            reject();
          }
        },
        (error) => {
          // Display error message.
          this.appService.spinner.hide();
          this.throwFiltersError(error);
          reject();
        }
      );
    });
  }

  private updateFilters() {
    let selectedTimeFrameFilter: ITimeFrameModel = null;

    selectedTimeFrameFilter = {
      option: this.selectedTimeFrameOption,
      startDt: this.selectedStartDt,
      endDt: this.selectedEndDt
    };

    this.mainFiltersService.SelectedFiltersValue = {
      company: this.selectedCompany,
      locations: this.selectedLocations,
      timeFrame: selectedTimeFrameFilter,
      accountNumber: this.searchAccountNumber
    };

    this.onMainFiltersValues.emit(this.mainFiltersService.SelectedFiltersValue);
  }

  private throwFiltersError(error) {
    if (typeof error === 'string') {
      this.onMainFiltersError.emit(error);
    } else {
      this.onMainFiltersError.emit(error.message);
    }
  }

  private onTimeFrameDateRangeFilterInit(id: number) {
    switch (id) {
      case 0:
        this.selectedStartDt = null;
        this.selectedEndDt = null;
        break;
      case 1:
        this.selectedStartDt = moment()
          .utc()
          .subtract(7, 'days')
          .toDate();
        this.selectedEndDt = moment()
          .utc()
          .toDate();
        break;
      case 2:
        this.selectedStartDt = moment()
          .utc()
          .subtract(1, 'months')
          .toDate();
        this.selectedEndDt = moment()
          .utc()
          .toDate();
        break;
      case 3:
        this.selectedStartDt = moment()
          .utc()
          .subtract(7, 'days')
          .toDate();
        this.selectedEndDt = moment()
          .utc()
          .toDate();
        break;
    }
  }
}
