export interface IDynamicPaginationOption {
  rows: number;
  pageSize: number;
}
