import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { IDynamicPaginationOption } from '@core/components/dynamic-pagination/dynamic-pagination.model';

@Component({
  selector: 'dbcp-dynamic-pagination',
  template: `
    <ul id="menu" class="list-unstyled mb-0">
      <li class="d-inline">
        <span
          *ngIf="_totalCount > 50"
          [ngClass]="
            activePageSizeOptions === 10
              ? 'active-page-selected'
              : 'not-current-active-page-size'
          "
          (click)="adjustPageSize(rows, 10)"
          >10 /
        </span>
      </li>
      <li *ngFor="let pageSize of pageSizes" class="d-inline">
        <span
          [ngClass]="
            activePageSizeOptions === pageSize
              ? 'active-page-selected'
              : 'not-current-active-page-size'
          "
          (click)="adjustPageSize(rows, pageSize)"
        >
          <span *ngIf="pageSize !== 0">{{ pageSize }} / </span>
          <span *ngIf="pageSizes.length === 1">&nbsp;</span>
          <span *ngIf="pageSize === 0">
            {{ 'DYNAMIC_PAGINATION_ALL' | dbcpLocalize }}
          </span>
          <span *ngIf="pageSizes.length === 1">&nbsp;</span>
        </span>
      </li>
    </ul>
  `,
  styles: [
    `
      .active-page-selected {
        font-weight: bold;
        color: #000000;
      }
      .not-current-active-page-size:hover {
        cursor: pointer;
      }
      .not-current-active-page-size {
        color: #3366bb;
      }
    `
  ]
})
export class ComputePageSizeComponent implements OnInit, OnChanges {
  public rows: number = 0;
  public pageSizes: number[] = [];
  public activePageSizeOptions: number = 10;

  @Input('totalCount')
  public _totalCount: number;

  @Output()
  public onDyPaginationValue = new EventEmitter<IDynamicPaginationOption>();

  private count: number = 0;

  public ngOnInit() {
    this.getPageSize(this._totalCount);
    this.adjustPageSize(0, 10);
  }

  public ngOnChanges() {
    this.activePageSizeOptions = 10;
    this.getPageSize(this._totalCount);
  }

  public adjustPageSize(rows, pageSize) {
    this.activePageSizeOptions = pageSize;
    this.onDyPaginationValue.emit({ rows, pageSize });
  }

  private getPageSize(totalCount) {
    if (totalCount <= 50) {
      this.rows = 10;
    } else if (totalCount <= 100) {
      this.rows = 25;
    } else if (totalCount <= 300) {
      this.rows = 50;
    } else if (totalCount <= 400) {
      this.rows = 75;
    } else {
      this.rows = 100;
    }

    const counter = Math.floor(totalCount / this.rows);
    this.pageSizes = [
      ...Array.from(Array(counter).keys()).map((i) => (i + 1) * this.rows)
    ];

    this.pageSizes = this.pageSizes.slice(0, 4); // limit the range size into max 4
    this.pageSizes.push(0); // add display all case
  }
}
