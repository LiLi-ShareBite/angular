import { Pipe, PipeTransform } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Pipe({
  name: 'dbcpSentenceCase'
})
export class SentenceCasePipe implements PipeTransform {
  constructor() {}

  public transform(value: any) {
    if (isNullOrUndefined(value)) {
      return '';
    }

    if (typeof value === 'string') {
      const valueArr = value.split(' ');
      if (valueArr.length === 0) {
        return '';
      } else {
        valueArr.forEach((val, index) => {
          if (index === 0 && val.length) {
            valueArr[
              index
            ] = `${val[0].toString().toUpperCase()}${val
              .toString()
              .substr(1, val.length)}`;
          } else {
            valueArr[index] = val.toString().toLowerCase();
          }
        });
      }
      return valueArr.join(' ').trim();
    } else {
      return value;
    }
  }
}
