import { Pipe, PipeTransform } from '@angular/core';
import * as util from 'util';
import { isNullOrUndefined } from 'util';

const LOCALIZE_RESOURCES = [];

@Pipe({
  name: 'dbcpLocalize'
})
export class LocalizePipe implements PipeTransform {
  public static Instance: LocalizePipe;

  public static readonly specificLanguageMap = {
    'en-US': 'en',
    'ko-KR': 'ko',
    'fr-FR': 'fr',
    'it-IT': 'it',
    'de-DE': 'de',
    'nl-NL': 'nl',
    'es-ES': 'es',
    'ja-JP': 'ja',
    'zh-Hans': 'zh-CN',
    'zh-SG': 'zh-CN',
    'zh-HK': 'zh-TW',
    'zh-Hant': 'zh-TW',
    'zh-MO': 'zh-TW'
  };

  public static getClientLocale(): string {
    const navigator = window.navigator as any,
      language: string = navigator.languages
        ? navigator.languages.length > 0
          ? navigator.languages[0]
          : navigator.language || navigator.userLanguage
        : navigator.language || navigator.userLanguage;

    const specificLang = this.specificLanguageMap[language];

    return isNullOrUndefined(specificLang) ? language : specificLang;
  }

  private i18n: any;

  constructor() {
    const pipe = this;

    if (LocalizePipe.Instance) {
      return LocalizePipe.Instance;
    }

    pipe.i18n = (window as any).$.i18n;
    pipe.i18n.properties({
      name: ['Resources'].concat(
        LOCALIZE_RESOURCES.map((path) => path + '/Resources')
      ),
      path: 'assets/lang/',
      language: LocalizePipe.getClientLocale(),
      mode: 'map',
      checkAvailableLanguages: true,
      callback: () => {}
    });

    LocalizePipe.Instance = pipe;
  }

  public transform(localizeKey: string = '', ...params: string[]): string {
    const pipe = this,
      keyParamsMatch = localizeKey.match(/%/g),
      keyParamsCount = isNullOrUndefined(keyParamsMatch)
        ? 0
        : keyParamsMatch.length;
    params = params || [];
    if (keyParamsCount > 0) {
      localizeKey = util.format(localizeKey, params.splice(keyParamsCount));
    }

    let localizeValue = pipe.i18n.map[localizeKey];

    for (const param of params) {
      localizeValue = util.format(localizeValue, param);
    }

    return isNullOrUndefined(localizeValue) ? localizeKey : localizeValue;
  }
}
