import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dbcpTextTruncate'
})
export class TextTruncatePipe implements PipeTransform {
  constructor() {}

  public transform(text: string, maxLength: number) {
    return text.length > maxLength ? `${text.substr(0, maxLength)}...` : text;
  }
}
