import { inject } from '@angular/core/testing';
import { TextTruncatePipe } from './text-truncate.pipe';
import { LocalizePipe } from './localize.pipe';
import { SentenceCasePipe } from './sentence-case.pipe';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';

// Unit test on TextTruncatePipe
describe('Pipe: TextTruncatePipe', () => {
  let textTruncatePipe: TextTruncatePipe;

  beforeEach(() => {
    textTruncatePipe = new TextTruncatePipe();
  });

  it('Keep original string when string not exceed max length', () => {
    expect(textTruncatePipe.transform('Databank Custom Portal', 22)).toBe(
      'Databank Custom Portal'
    );
  });

  it('Truncated the string by adding ... when string exceeds max length', () => {
    expect(textTruncatePipe.transform('Databank Custom Portal', 8)).toBe(
      'Databank...'
    );
  });
});

// Unit test on LocalizePipe
describe('Pipe: LocalizePipe', () => {
  let localizePipe: LocalizePipe;

  beforeEach(() => {
    localizePipe = new LocalizePipe();
  });

  it('Localization string pipe transforms stringID into string in Resource.properties file', () => {
    expect(localizePipe.transform('TEST_SPEC_STRING')).toBe('Test Spec String');
  });

  it('Strings with multiple parameters should transform succeed', () => {
    expect(
      localizePipe.transform('EXCEPTION_NOLONGER_EXISTS_WITH_USERINFO')
    ).toBe(
      'This exception has been resolved or discarded by %s %s (%s) and no longer exists.'
    );
  });
});

// Unit test on SentenceCasePipe
describe('Pipe: SentenceCasePipe', () => {
  let sentenceCasePipe: SentenceCasePipe;

  beforeEach(() => {
    sentenceCasePipe = new SentenceCasePipe();
  });

  it('Control the string length is Zero case', () => {
    expect(sentenceCasePipe.transform('')).toBe('');
  });

  it('Format the strings into sentence format', () => {
    expect(sentenceCasePipe.transform('Databank Custom Portal')).toBe(
      'Databank custom portal'
    );
  });
});

// Unit test on SafeUrlPipe
describe('Pipe: SafeUrlPipe', () => {
  let sanitizer: DomSanitizer;

  /** Marks an url as explicitly trusted. */
  function trustUrl(url: string): SafeResourceUrl {
    return sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  beforeEach(inject([DomSanitizer], (ds: DomSanitizer) => {
    sanitizer = ds;
  }));

  it('Check an URL by pass trust security resource.', () => {
    expect(
      sanitizer.bypassSecurityTrustHtml('http://localhost:4200')
    ).toBeTruthy();
  });
});
