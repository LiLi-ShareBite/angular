import { BaseControlModule } from './base-controls.module';

describe('BaseControlModule', () => {
  let baseControlModule: BaseControlModule;

  beforeEach(() => {
    baseControlModule = new BaseControlModule();
  });

  it('should create an instance', () => {
    expect(baseControlModule).toBeTruthy();
  });
});
