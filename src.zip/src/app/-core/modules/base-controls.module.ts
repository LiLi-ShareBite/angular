import { NgModule, ModuleWithProviders } from '@angular/core';
import { SafeUrlPipe } from '@core/pipes/safe-url.pipe';
import { AlertComponent } from '@core/components/alert/alert.component';
import { CommonModule } from '@angular/common';
import { BreadCrumbComponent } from '@core/components/bread-crumb/bread-crumb.component';
import { RouterModule } from '@angular/router';
import { FooterComponent } from '@core/components/footer/footer.component';
import { EqualValidatorDirective } from '@core/directives/equal-validator.directive';
import { ClipboardService } from '@core/services/clipboard.service';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { FormsModule } from '@angular/forms';
import { MainFiltersComponent } from '@core/components/main-filters/main-filters.component';
import { MainFiltersService } from '@core/components/main-filters/main-filters.service';
import { CalendarModule } from 'primeng/calendar';
import { SentenceCasePipe } from '@core/pipes/sentence-case.pipe';
import { TextTruncatePipe } from '@core/pipes/text-truncate.pipe';
import { LocalizePipe } from '@core/pipes/localize.pipe';
import { NumberDirective } from '@core/directives/numbers-only.directive';
import { TooltipModule } from 'primeng/tooltip';
import { ComputePageSizeComponent } from '@core/components/dynamic-pagination/dynamic-pagination.component';
import { RouterWrapperComponent } from '@core/components/router-wrapper/router-wrapper.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    CalendarModule,
    DropdownModule,
    MultiSelectModule,
    TooltipModule
  ],
  declarations: [
    SafeUrlPipe,
    SentenceCasePipe,
    TextTruncatePipe,
    LocalizePipe,
    AlertComponent,
    BreadCrumbComponent,
    FooterComponent,
    MainFiltersComponent,
    EqualValidatorDirective,
    NumberDirective,
    ComputePageSizeComponent,
    RouterWrapperComponent
  ],
  providers: [],
  exports: [
    SafeUrlPipe,
    SentenceCasePipe,
    TextTruncatePipe,
    LocalizePipe,
    AlertComponent,
    BreadCrumbComponent,
    FooterComponent,
    MainFiltersComponent,
    EqualValidatorDirective,
    NumberDirective,
    ComputePageSizeComponent,
    RouterWrapperComponent
  ]
})
export class BaseControlModule {
  public static forRoot(): ModuleWithProviders {
    return {
      ngModule: BaseControlModule,
      providers: [ClipboardService, MainFiltersService]
    };
  }
}
