import { Injectable } from '@angular/core';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { LoginService } from '@appRoot/login/login.service';
import { AppService } from '@appRoot/app.service';
import { LOGIN_RESULT } from './login/login.model';
import {
  UserAppModel,
  USER_ROLE
} from '@appRoot/features/user-management/user.model';

@Injectable()
export class AppIdleService {
  constructor(
    private idle: Idle,
    private appService: AppService,
    private loginService: LoginService
  ) {
    try {
      if (this.loginService.isUserLoggedIn() === LOGIN_RESULT.SUCCEEDED) {
        this.appService.currentUserSubject.subscribe((user: UserAppModel) => {
          if (user && user.detail.role === USER_ROLE.KNOWLEDGE_WORKER_ADMIN) {
            this.configureIdleWatchSettings(14370);
          } else {
            this.configureIdleWatchSettings(870);
          }
        });
      }
    } catch (ex) {
      console.log(ex);
    }
  }

  public watch() {
    this.idle.watch();
  }

  private configureIdleWatchSettings(idleSeconds: number) {
    this.idle.setIdle(idleSeconds);
    this.idle.setTimeout(30);
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    this.idle.onTimeout.subscribe(() => {
      this.appService.onUserTimeoutStatus$.next(true);
      this.loginService.logout();
    });
    this.idle.onInterrupt.subscribe(() => {
      this.appService.onUserTimeoutStatus$.next(false);
    });
    this.watch();
  }
}
