import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import {
  ModalButtonModel,
  PrimaryModalButtonModel
} from '@appRoot/-modals/models/modal-button.model';
import { isNullOrUndefined } from 'util';

@Component({
  template: `
    <div
      modal-component
      [header]="header"
      [buttons]="buttons"
      [showDismissBtn]="showDismissBtn"
    >
      <span class="content" [innerHtml]="message"></span>
    </div>
  `,
  encapsulation: ViewEncapsulation.None,
  styles: [``]
})
export class MessageModalComponent implements OnInit {
  public header: string;
  public message: string;
  public showDismissBtn = false;
  public buttons: ModalButtonModel[] = [];

  public onPrimaryBtnClick: () => Promise<any>;
  public onCancelBtnClick: () => Promise<any>;
  public primaryBtnText: string;
  public cancelBtnText: string;

  constructor(public activeModal: NgbActiveModal) {}

  public ngOnInit() {
    if (this.primaryBtnText) {
      this.buttons.push(
        new PrimaryModalButtonModel(this.primaryBtnText, () => {
          if (isNullOrUndefined(this.onPrimaryBtnClick)) {
            this.activeModal.close();
          } else {
            this.onPrimaryBtnClick().then((data) => {
              this.activeModal.close(data);
            });
          }
        })
      );
    }

    if (this.cancelBtnText) {
      this.buttons.push(
        new ModalButtonModel(this.cancelBtnText, () => {
          if (isNullOrUndefined(this.onCancelBtnClick)) {
            this.activeModal.dismiss();
          } else {
            this.onCancelBtnClick().then(() => {
              this.activeModal.dismiss();
            });
          }
        })
      );
    }
  }
}
