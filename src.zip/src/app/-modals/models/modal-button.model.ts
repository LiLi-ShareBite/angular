export class ModalButtonModel {
  public primary = false;

  constructor(
    public title: string = '',
    public click: () => void = () => {},
    public disabled: () => boolean = () => {
      return false;
    }
  ) {}
}

export class PrimaryModalButtonModel extends ModalButtonModel {
  public primary = true;
}
