import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModalsComponent } from '@appRoot/-modals/modals.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ConfirmModalComponent } from '@appRoot/-modals/modals-confirmation.component';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { ButtonModule } from 'primeng/button';
import { MessageModalComponent } from '@appRoot/-modals/modals-message.component';
import { BaseControlModule } from '@core/modules/base-controls.module';

@NgModule({
  declarations: [ModalsComponent, ConfirmModalComponent, MessageModalComponent],
  imports: [
    CommonModule,
    FormsModule,
    ButtonModule,
    BaseControlModule,
    NgbModule
  ],
  exports: [ModalsComponent],
  providers: [ModalsService],
  entryComponents: [
    ModalsComponent,
    ConfirmModalComponent,
    MessageModalComponent
  ]
})
export class ModalsModule {}
