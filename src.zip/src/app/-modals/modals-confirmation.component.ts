import { Component, ViewEncapsulation } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import {
  ModalButtonModel,
  PrimaryModalButtonModel
} from '@appRoot/-modals/models/modal-button.model';
import { LocalizePipe } from '@core/pipes/localize.pipe';

@Component({
  template: `
    <div
      modal-component
      [header]="header"
      [buttons]="buttons"
      [showDismissBtn]="showDismissBtn"
    >
      <span class="content" [innerHtml]="message"></span>
    </div>
  `,
  encapsulation: ViewEncapsulation.None,
  styles: [``]
})
export class ConfirmModalComponent {
  public header: string;
  public message: string;
  public showDismissBtn = false;
  public buttons: ModalButtonModel[] = [];

  constructor(public activeModal: NgbActiveModal) {
    this.buttons = [
      new PrimaryModalButtonModel(
        LocalizePipe.Instance.transform('MODAL_CONFIRMATION_OK'),
        () => {
          activeModal.close();
        }
      ),
      new ModalButtonModel(
        LocalizePipe.Instance.transform('MODAL_CONFIRMATION_CANCEL'),
        () => {
          activeModal.dismiss();
        }
      )
    ];
  }
}
