import { Component, Input } from '@angular/core';
import { ModalButtonModel } from '@appRoot/-modals/models/modal-button.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DbcpErrorAlert } from '@core/components/alert/alert.model';
import { ModalsService } from '@appRoot/-modals/modals.service';
import { isNull } from 'util';
import { LocalizePipe } from '@core/pipes/localize.pipe';

@Component({
  selector: '[modal-component]',
  templateUrl: './modals.component.html',
  styleUrls: ['./modals.component.scss']
})
export class ModalsComponent {
  @Input('header')
  public _header: string;

  @Input('showDismissBtn')
  public _showDismissBtn: boolean = true;

  @Input('buttons')
  public _buttons: ModalButtonModel[] = [];

  public errorAlert: DbcpErrorAlert = null;

  constructor(
    public activeModal: NgbActiveModal,
    private modalsService: ModalsService
  ) {
    this.modalsService.errorAlertSubject$.subscribe((errorMsg: string) => {
      if (isNull(errorMsg)) {
        this.errorAlert = null;
      } else {
        errorMsg = errorMsg || LocalizePipe.Instance.transform('SERVER_ERROR');
        this.errorAlert = new DbcpErrorAlert(errorMsg, true);
      }
    });
  }
}
