import { Injectable, Type } from '@angular/core';
import { ConfirmModalComponent } from '@appRoot/-modals/modals-confirmation.component';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { MessageModalComponent } from '@appRoot/-modals/modals-message.component';
import { Subject } from 'rxjs';

@Injectable()
export class ModalsService {
  public errorAlertSubject$ = new Subject<string>();
  constructor(private modalService: NgbModal) {}

  public openModal(formContent: Type<any>, options: NgbModalOptions = {}) {
    const service = this,
      modal = service.modalService.open(
        formContent,
        Object.assign(
          {
            backdrop: 'static',
            keyboard: false,
            size: 'lg'
          },
          options
        )
      );
    return modal;
  }

  public openConfirmModal(header: string, message: string) {
    const service = this,
      modal = service.modalService.open(ConfirmModalComponent, {
        backdrop: 'static',
        keyboard: false,
        size: 'lg'
      });
    modal.componentInstance.header = header;
    modal.componentInstance.message = message;

    return modal.result;
  }

  public openMessageModal(options: NgbModalOptions = {}) {
    const service = this,
      modal = service.modalService.open(
        MessageModalComponent,
        Object.assign(
          {
            backdrop: 'static',
            keyboard: false,
            size: 'lg'
          },
          options
        )
      );
    return modal;
  }

  public closeModal() {
    this.modalService.dismissAll();
  }
}
