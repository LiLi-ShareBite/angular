import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

import 'bootstrap';

if (environment.environment_name === 'production') {
  enableProdMode();

  // B012-2298 Disable fullstory in dev environment
  const fullStoryScriptNode = document.createElement('script');
  fullStoryScriptNode.src = environment.fullstory;
  document.getElementsByTagName('head')[0].appendChild(fullStoryScriptNode);
}

platformBrowserDynamic().bootstrapModule(AppModule);
