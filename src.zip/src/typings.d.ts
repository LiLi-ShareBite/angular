/* SystemJS module definition */
declare var module: NodeModule;

interface NodeModule {
    id: string;
}

interface ObjectConstructor {
    update<M>(target: M, source: M): M;
}

interface DateConstructor {
    fromUTCString(val: string): Date;
}
