export const environment = {
  BROWSERSLIST: ' "> 1%","last 2 versions"',
  fullstory: './assets/analytics/fullstory-prod.js',
  environment_name: 'production'
};
